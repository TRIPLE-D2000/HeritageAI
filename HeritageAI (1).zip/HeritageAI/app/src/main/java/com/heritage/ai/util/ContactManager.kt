package com.heritage.ai.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Normalizer
import javax.inject.Inject
import javax.inject.Singleton

data class ContactResult(
    val id: String,
    val name: String,
    /** Best number to use (a mobile number if the contact has one). */
    val phoneNumber: String,
    val photoUri: String?,
    /** Every number saved for this contact. */
    val numbers: List<String> = emptyList(),
    /** How well the name matched the query (100 = exact). */
    val score: Int = 0
)

sealed class ContactLookup {
    data class Found(val contact: ContactResult) : ContactLookup()
    data class Ambiguous(val options: List<ContactResult>) : ContactLookup()
    object NotFound : ContactLookup()
    object NoPermission : ContactLookup()
}

/**
 * ContactManager — finds people in the phone's contacts BY NAME, so the
 * assistant can call or text "Mum" without being given a number.
 *
 * Matching happens on the device: contact names/numbers are never uploaded.
 * Only the name the model extracted from the user's request is used.
 */
@Singleton
class ContactManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
                PackageManager.PERMISSION_GRANTED

    /** Searches contacts by display name, returning up to [limit] best matches. */
    suspend fun searchContacts(query: String, limit: Int = 10): List<ContactResult> =
        withContext(Dispatchers.IO) {
            if (!hasPermission()) return@withContext emptyList()
            rank(loadAll(), query).take(limit)
        }

    /** Resolves a spoken/typed name to one contact, or reports why it couldn't. */
    suspend fun lookup(name: String): ContactLookup = withContext(Dispatchers.IO) {
        if (!hasPermission()) return@withContext ContactLookup.NoPermission
        val ranked = rank(loadAll(), name)
        when {
            ranked.isEmpty() -> ContactLookup.NotFound
            ranked.size == 1 -> ContactLookup.Found(ranked.first())
            else -> {
                val top = ranked.first().score
                val tied = ranked.filter { it.score == top }
                if (tied.size == 1) ContactLookup.Found(tied.first())
                else ContactLookup.Ambiguous(tied.take(4))
            }
        }
    }

    // ── Internals ──────────────────────────────────

    private class Row(val id: String, val name: String, val number: String, val type: Int, val photo: String?)

    private fun loadAll(): List<ContactResult> {
        val rows = mutableListOf<Row>()
        val p = ContactsContract.CommonDataKinds.Phone
        runCatching {
            context.contentResolver.query(
                p.CONTENT_URI,
                arrayOf(p.CONTACT_ID, p.DISPLAY_NAME, p.NUMBER, p.TYPE, p.PHOTO_URI),
                null, null, "${p.DISPLAY_NAME} ASC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(p.CONTACT_ID)
                val nameCol = c.getColumnIndexOrThrow(p.DISPLAY_NAME)
                val numCol = c.getColumnIndexOrThrow(p.NUMBER)
                val typeCol = c.getColumnIndexOrThrow(p.TYPE)
                val photoCol = c.getColumnIndex(p.PHOTO_URI)
                while (c.moveToNext()) {
                    val number = c.getString(numCol)?.trim().orEmpty()
                    if (number.isEmpty()) continue
                    rows += Row(
                        id = c.getString(idCol) ?: continue,
                        name = c.getString(nameCol) ?: "Unknown",
                        number = number,
                        type = c.getInt(typeCol),
                        photo = if (photoCol >= 0) c.getString(photoCol) else null
                    )
                }
            }
        }
        return rows.groupBy { it.id }.map { (id, list) ->
            val best = list.firstOrNull { it.type == p.TYPE_MOBILE } ?: list.first()
            ContactResult(
                id = id,
                name = list.first().name,
                phoneNumber = best.number,
                photoUri = list.firstNotNullOfOrNull { it.photo },
                numbers = list.map { it.number }.distinct()
            )
        }
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun rank(all: List<ContactResult>, query: String): List<ContactResult> {
        val q = normalize(query)
        if (q.isEmpty()) return emptyList()
        val qTokens = q.split(" ")
        return all.mapNotNull { contact ->
            val n = normalize(contact.name)
            val nTokens = n.split(" ")
            val score = when {
                n == q -> 100
                n.startsWith(q) -> 80
                nTokens.any { it == q } -> 70
                qTokens.all { qt -> nTokens.any { it.startsWith(qt) } } -> 60
                n.contains(q) -> 40
                else -> 0
            }
            if (score > 0) contact.copy(score = score) else null
        }.sortedWith(compareByDescending<ContactResult> { it.score }.thenBy { it.name })
    }

    /** Returns an intent that opens the dialer pre-filled with [phoneNumber]. */
    fun callIntent(phoneNumber: String): Intent =
        Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null))

    /** Returns an intent that opens the SMS app pre-filled to [phoneNumber] with [message]. */
    fun smsIntent(phoneNumber: String, message: String = ""): Intent =
        Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", phoneNumber, null)).apply {
            putExtra("sms_body", message)
        }
}
