# ════════════════════════════════════════════════════════════
# Heritage AI — ProGuard / R8 rules
# ════════════════════════════════════════════════════════════
# Applied only to release builds (see app/build.gradle.kts).
# https://developer.android.com/build/shrink-code

# ── Keep line numbers for readable crash stack traces ──
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# ── Kotlin metadata & coroutines ──
-keep class kotlin.Metadata { *; }
-keepclassmembers class kotlin.coroutines.jvm.internal.BaseContinuationImpl {
    private java.lang.Object label;
}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.flow.**Flow

# ── Hilt / Dagger ──
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.lifecycle.HiltViewModel
-keepclasseswithmembers class * {
    @dagger.hilt.android.lifecycle.HiltViewModel <init>(...);
}
-keep,allowobfuscation @interface dagger.hilt.android.AndroidEntryPoint
-keep @dagger.hilt.android.AndroidEntryPoint class * { *; }

# ── Room ──
-keep class androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }
-dontwarn androidx.room.paging.**

# ── SQLCipher ──
-keep class net.sqlcipher.** { *; }
-keep class net.sqlcipher.database.* { *; }

# ── Gson — model classes must keep field names for (de)serialization ──
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.heritage.ai.data.remote.model.** { *; }
-keep class com.heritage.ai.domain.model.** { *; }
-keep class com.heritage.ai.data.local.entity.** { *; }
-keepclassmembers,allowobfuscation class * {
  @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.google.gson.reflect.TypeToken
-keep class * extends com.google.gson.reflect.TypeToken

# ── Retrofit / OkHttp ──
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keepattributes Exceptions
-keep class retrofit2.Response

# ── WorkManager / Hilt-Work ──
-keep class androidx.hilt.work.** { *; }
-keep class * extends androidx.work.CoroutineWorker {
    <init>(...);
}
-keep class * extends androidx.work.Worker {
    <init>(...);
}

# ── Android Speech / TTS / Accessibility (framework classes, keep callbacks) ──
-keep class * extends android.accessibilityservice.AccessibilityService
-keep class * extends android.service.notification.NotificationListenerService
-keep class * extends android.app.Service

# ── Compose ──
-dontwarn androidx.compose.**
-keep class androidx.compose.runtime.** { *; }

# ── General Android ──
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod
