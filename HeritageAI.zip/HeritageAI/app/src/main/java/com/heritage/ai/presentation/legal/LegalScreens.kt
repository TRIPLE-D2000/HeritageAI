package com.heritage.ai.presentation.legal

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.heritage.ai.legal.LegalDocs

/**
 * Shows the app only after the user has accepted the CURRENT version of the
 * Terms and Privacy Policy. [acceptedVersion] is null while preferences load.
 */
@Composable
fun LegalGate(
    acceptedVersion: String?,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    content: @Composable () -> Unit
) {
    when {
        acceptedVersion == null -> Box(Modifier.fillMaxSize())
        acceptedVersion != LegalDocs.VERSION -> ConsentScreen(onAccept, onDecline)
        else -> content()
    }
}

@Composable
fun ConsentScreen(onAccept: () -> Unit, onDecline: () -> Unit) {
    var checked by remember { mutableStateOf(false) }
    var doc by remember { mutableStateOf(0) } // 1 = terms, 2 = privacy

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Welcome to Heritage AI", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Before you start, here is how Heritage AI treats your data:",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text("• Your chats and memories are stored on your phone, encrypted.", style = MaterialTheme.typography.bodyMedium)
                Text("• To answer you, your message and some context are sent to AI services (Groq, Tavily) through our server, outside Nigeria.", style = MaterialTheme.typography.bodyMedium)
                Text("• Your contact list is never uploaded. Calls and texts are made on your phone.", style = MaterialTheme.typography.bodyMedium)
                Text("• We don't sell your data and there are no ads.", style = MaterialTheme.typography.bodyMedium)
                Text("• You can delete everything any time in Settings.", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "AI can make mistakes, and it can act on your phone when you ask, so check calls and messages before confirming.",
                    style = MaterialTheme.typography.bodyMedium
                )
                TextButton(onClick = { doc = 1 }) { Text("Read the Terms of Service") }
                TextButton(onClick = { doc = 2 }) { Text("Read the Privacy Policy") }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = checked, onCheckedChange = { checked = it })
                Text(
                    "I am 18 or older and I agree to the Terms of Service and Privacy Policy.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onAccept, enabled = checked, modifier = Modifier.fillMaxWidth()) {
                Text("Accept and continue")
            }
            TextButton(onClick = onDecline, modifier = Modifier.fillMaxWidth()) {
                Text("Decline and exit")
            }
        }
    }

    when (doc) {
        1 -> LegalDocDialog("Terms of Service", LegalDocs.TERMS) { doc = 0 }
        2 -> LegalDocDialog("Privacy Policy", LegalDocs.PRIVACY) { doc = 0 }
    }
}

@Composable
fun LegalDocDialog(title: String, text: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Text(text, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
