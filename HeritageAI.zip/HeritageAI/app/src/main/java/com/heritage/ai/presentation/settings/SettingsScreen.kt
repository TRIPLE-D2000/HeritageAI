package com.heritage.ai.presentation.settings

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.data.remote.model.LLMProvider
import com.heritage.ai.data.remote.model.LLMProviders
import android.content.Context
import androidx.core.content.ContextCompat
import com.heritage.ai.service.WakeWordService
import com.heritage.ai.util.ButtonTriggerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ──────────────────────────────────────────────────
// SETTINGS VIEW MODEL
// ──────────────────────────────────────────────────

data class SettingsState(
    val apiKey: String = "",
    val selectedProvider: LLMProvider = LLMProviders.OPENAI,
    val selectedModel: String = LLMProviders.OPENAI.defaultModel,
    val temperature: Float = 0.7f,
    val userName: String = "",
    val isDarkTheme: Boolean = true,
    val followSystem: Boolean = true,
    val ttsEnabled: Boolean = true,
    val ttsSpeed: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val wakeWordEnabled: Boolean = false,
    val showFloatingBubble: Boolean = true,
    val notificationReading: Boolean = false,
    val longTermMemory: Boolean = true,
    val isSaving: Boolean = false,
    val saveSuccess: Boolean = false,
    val buttonTriggerEnabled: Boolean = true
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefs: AppPreferences,
    private val permissionHelper: com.heritage.ai.util.PermissionHelper,
    @ApplicationContext private val context: Context,
    private val buttonTriggerManager: ButtonTriggerManager
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    /** Live map of permission name → granted status, refreshed every 1.5 s. */
    private val _permissionStatus = MutableStateFlow(permissionHelper.getPermissionStatus())
    val permissionStatus: StateFlow<Map<String, Boolean>> = _permissionStatus.asStateFlow()

    init {
        // Poll permission status so the UI refreshes when the user returns from system Settings
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(1500)
                _permissionStatus.value = permissionHelper.getPermissionStatus()
            }
        }
        viewModelScope.launch {
            combine(
                prefs.llmApiKey,
                prefs.llmProviderId,
                prefs.llmModel,
                prefs.llmTemperature,
                prefs.userName
            ) { key, providerId, model, temp, name ->
                val provider = LLMProviders.ALL.find { it.id == providerId } ?: LLMProviders.OPENAI
                _state.update {
                    it.copy(
                        apiKey = key, selectedProvider = provider,
                        selectedModel = model, temperature = temp, userName = name
                    )
                }
            }.collect()
        }
        viewModelScope.launch {
            combine(prefs.isDarkTheme, prefs.followSystemTheme, prefs.ttsEnabled,
                prefs.ttsSpeed, prefs.ttsPitch) { dark, sys, tts, speed, pitch ->
                _state.update { it.copy(isDarkTheme = dark, followSystem = sys, ttsEnabled = tts, ttsSpeed = speed, ttsPitch = pitch) }
            }.collect()
        }
        viewModelScope.launch {
            combine(prefs.wakeWordEnabled, prefs.showFloatingBubble, prefs.notificationReadingEnabled, prefs.longTermMemoryEnabled) {
                    wake, bubble, notif, mem ->
                _state.update { it.copy(wakeWordEnabled = wake, showFloatingBubble = bubble, notificationReading = notif, longTermMemory = mem) }
            }.collect()
        }
    }

    fun setApiKey(key: String) = _state.update { it.copy(apiKey = key) }
    fun setUserName(name: String) = _state.update { it.copy(userName = name) }
    fun setProvider(provider: LLMProvider) = _state.update { it.copy(selectedProvider = provider, selectedModel = provider.defaultModel) }
    fun setModel(model: String) = _state.update { it.copy(selectedModel = model) }
    fun setTemperature(temp: Float) = _state.update { it.copy(temperature = temp) }
    fun setDarkTheme(dark: Boolean) = _state.update { it.copy(isDarkTheme = dark) }
    fun setFollowSystem(follow: Boolean) = _state.update { it.copy(followSystem = follow) }
    fun setTtsEnabled(v: Boolean) = _state.update { it.copy(ttsEnabled = v) }
    fun setTtsSpeed(v: Float) = _state.update { it.copy(ttsSpeed = v) }
    fun setWakeWord(v: Boolean) = _state.update { it.copy(wakeWordEnabled = v) }
    fun setButtonTrigger(v: Boolean) {
        _state.update { it.copy(buttonTriggerEnabled = v) }
        buttonTriggerManager.setEnabled(v)
    }
    fun setFloatingBubble(v: Boolean) = _state.update { it.copy(showFloatingBubble = v) }
    fun setNotificationReading(v: Boolean) = _state.update { it.copy(notificationReading = v) }
    fun setLongTermMemory(v: Boolean) = _state.update { it.copy(longTermMemory = v) }

    fun toggleWakeWordService(enable: Boolean) {
        val intent = Intent(context, WakeWordService::class.java)
        if (enable) {
            ContextCompat.startForegroundService(context, intent)
        } else {
            context.stopService(intent)
        }
    }

    fun saveAll() {
        viewModelScope.launch {
            _state.update { it.copy(isSaving = true) }
            val s = _state.value
            prefs.setApiKey(s.apiKey)
            prefs.setLLMProvider(s.selectedProvider.id, s.selectedProvider.baseUrl, s.selectedModel)
            prefs.setModel(s.selectedModel)
            prefs.setTemperature(s.temperature)
            prefs.setUserName(s.userName)
            prefs.setDarkTheme(s.isDarkTheme)
            prefs.setFollowSystem(s.followSystem)
            prefs.setTtsEnabled(s.ttsEnabled)
            prefs.setTtsSpeed(s.ttsSpeed)
            prefs.setWakeWordEnabled(s.wakeWordEnabled)
            prefs.setShowFloatingBubble(s.showFloatingBubble)
            prefs.setNotificationReadingEnabled(s.notificationReading)
            prefs.setLongTermMemoryEnabled(s.longTermMemory)
            _state.update { it.copy(isSaving = false, saveSuccess = true) }
        }
    }
}

// ──────────────────────────────────────────────────
// SETTINGS SCREEN
// ──────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val permissionStatus by viewModel.permissionStatus.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var showApiKey by remember { mutableStateOf(false) }
    var showProviderMenu by remember { mutableStateOf(false) }
    var showModelMenu by remember { mutableStateOf(false) }

    LaunchedEffect(state.saveSuccess) {
        if (state.saveSuccess) onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { viewModel.saveAll() }, enabled = !state.isSaving) {
                        if (state.isSaving) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        else Text("Save")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ── PROFILE ──
            SettingsSection("Profile") {
                SettingsTextField(
                    label = "Your name",
                    value = state.userName,
                    onValueChange = viewModel::setUserName,
                    leadingIcon = Icons.Default.Person,
                    placeholder = "e.g. Samuel"
                )
            }

            // ── AI MODEL ──
            SettingsSection("AI Model") {
                // Provider selector
                ExposedDropdownMenuBox(
                    expanded = showProviderMenu,
                    onExpandedChange = { showProviderMenu = it }
                ) {
                    OutlinedTextField(
                        value = state.selectedProvider.name,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("LLM Provider") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(showProviderMenu) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = showProviderMenu, onDismissRequest = { showProviderMenu = false }) {
                        LLMProviders.ALL.forEach { provider ->
                            DropdownMenuItem(
                                text = { Text(provider.name) },
                                onClick = {
                                    viewModel.setProvider(provider)
                                    showProviderMenu = false
                                }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Model selector
                ExposedDropdownMenuBox(
                    expanded = showModelMenu,
                    onExpandedChange = { showModelMenu = it }
                ) {
                    OutlinedTextField(
                        value = state.selectedModel,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Model") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(showModelMenu) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = showModelMenu, onDismissRequest = { showModelMenu = false }) {
                        state.selectedProvider.models.forEach { model ->
                            DropdownMenuItem(
                                text = { Text(model) },
                                onClick = { viewModel.setModel(model); showModelMenu = false }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                // API key
                OutlinedTextField(
                    value = state.apiKey,
                    onValueChange = viewModel::setApiKey,
                    label = { Text("API Key") },
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                        }
                    },
                    placeholder = { Text("sk-…") }
                )

                Spacer(Modifier.height(8.dp))

                // Temperature
                Text("Creativity: ${(state.temperature * 10).toInt() / 10f} ${if (state.temperature <= 0.5f) "(formal)" else if (state.temperature <= 0.8f) "(balanced)" else "(creative)"}", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                Slider(
                    value = state.temperature,
                    onValueChange = viewModel::setTemperature,
                    valueRange = 0f..1.0f,
                    steps = 9
                )
            }

            // ── VOICE ──
            SettingsSection("Voice & Speech") {
                // Background listening toggle — starts/stops WakeWordService
                SettingsSwitch("Background listening ('Hey Heritage')", state.wakeWordEnabled, { enabled ->
                    viewModel.setWakeWord(enabled)
                    viewModel.toggleWakeWordService(enabled)
                }, Icons.Default.RecordVoiceOver)
                if (state.wakeWordEnabled) {
                    Text(
                        "⚠ Uses more battery. Say 'Hey Heritage' to activate hands-free.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                        modifier = Modifier.padding(start = 32.dp, bottom = 4.dp)
                    )
                }
                SettingsSwitch("Volume button trigger (hold down = activate)", state.buttonTriggerEnabled, viewModel::setButtonTrigger, Icons.Default.TouchApp)
                SettingsSwitch("Text-to-speech", state.ttsEnabled, viewModel::setTtsEnabled, Icons.Default.VolumeUp)
                AnimatedVisibility(state.ttsEnabled) {
                    Column {
                        Text("Speech speed: ${(state.ttsSpeed * 10).toInt() / 10f}x", style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            modifier = Modifier.padding(top = 8.dp))
                        Slider(value = state.ttsSpeed, onValueChange = viewModel::setTtsSpeed, valueRange = 0.5f..2f)
                    }
                }
            }

            // ── APPEARANCE ──
            SettingsSection("Appearance") {
                SettingsSwitch("Follow system theme", state.followSystem, viewModel::setFollowSystem, Icons.Default.Contrast)
                AnimatedVisibility(!state.followSystem) {
                    SettingsSwitch("Dark theme", state.isDarkTheme, viewModel::setDarkTheme, Icons.Default.DarkMode)
                }
                SettingsSwitch("Floating bubble", state.showFloatingBubble, viewModel::setFloatingBubble, Icons.Default.BubbleChart)
            }

            // ── INTELLIGENCE ──
            SettingsSection("Intelligence") {
                SettingsSwitch("Long-term memory", state.longTermMemory, viewModel::setLongTermMemory, Icons.Default.Psychology)
                SettingsSwitch("Read notifications", state.notificationReading, viewModel::setNotificationReading, Icons.Default.Notifications)
            }

            // ── PERMISSIONS ──
            SettingsSection("Permissions") {
                // Live status summary chip
                val grantedCount = permissionStatus.values.count { it }
                val totalCount = permissionStatus.size
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (grantedCount == totalCount)
                        MaterialTheme.colorScheme.secondaryContainer
                    else
                        MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Text(
                        text = if (grantedCount == totalCount)
                            "✓ All $totalCount permissions granted"
                        else
                            "$grantedCount / $totalCount permissions granted — tap below to fix",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (grantedCount == totalCount)
                            MaterialTheme.colorScheme.onSecondaryContainer
                        else
                            MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                PermissionItem(
                    title = "Accessibility Service",
                    description = "Enables typing, clicking, and UI automation",
                    isGranted = permissionStatus["Accessibility service"] == true
                ) {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermissionItem(
                    title = "Notification Access",
                    description = "Lets Heritage read your notifications",
                    isGranted = permissionStatus["Notification listener"] == true
                ) {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermissionItem(
                    title = "System Overlay",
                    description = "Required for the floating bubble",
                    isGranted = permissionStatus["Overlay (bubble)"] == true
                ) {
                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermissionItem(
                    title = "Modify System Settings",
                    description = "Required to control screen brightness",
                    isGranted = permissionStatus["Modify system settings"] == true
                ) {
                    context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

// ── Helper composables ─────────────────────────────

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Surface(
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
private fun SettingsSwitch(label: String, value: Boolean, onToggle: (Boolean) -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
        Switch(checked = value, onCheckedChange = onToggle)
    }
}

@Composable
private fun SettingsTextField(label: String, value: String, onValueChange: (String) -> Unit, leadingIcon: androidx.compose.ui.graphics.vector.ImageVector, placeholder: String = "") {
    OutlinedTextField(
        value = value, onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        leadingIcon = { Icon(leadingIcon, null) },
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PermissionItem(
    title: String,
    description: String,
    isGranted: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(
                description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Live granted/denied badge
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (isGranted)
                    MaterialTheme.colorScheme.secondaryContainer
                else
                    MaterialTheme.colorScheme.errorContainer
            ) {
                Text(
                    text = if (isGranted) "✓" else "✗",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isGranted)
                        MaterialTheme.colorScheme.onSecondaryContainer
                    else
                        MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            if (!isGranted) {
                Icon(
                    Icons.Default.OpenInNew,
                    "Open",
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
}
