package com.heritage.ai.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.heritage.ai.domain.model.RoutineTrigger
import com.heritage.ai.domain.repository.RoutineRepository
import com.heritage.ai.worker.RoutineExecutionWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Fires when a time-based routine's alarm goes off.
 *
 * Hands the actual execution to [RoutineExecutionWorker] via WorkManager
 * (a BroadcastReceiver's execution window is short and unsuitable for the
 * device-command sequence a routine runs), then re-arms tomorrow's alarm
 * since AlarmManager's exact alarms are one-shot, not recurring.
 */
@AndroidEntryPoint
class RoutineAlarmReceiver : BroadcastReceiver() {

    @Inject lateinit var routineRepository: RoutineRepository
    @Inject lateinit var scheduler: RoutineScheduler

    override fun onReceive(context: Context, intent: Intent) {
        val routineId = intent.getStringExtra(EXTRA_ROUTINE_ID) ?: return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                handleAlarm(context, routineId)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun handleAlarm(context: Context, routineId: String) {
        // Enqueue the actual run regardless — WorkManager's own doWork()
        // re-checks isEnabled too, but re-reading here lets us decide
        // whether to bother rescheduling at all below.
        val routine = routineRepository.getRoutineById(routineId)

        WorkManager.getInstance(context).enqueue(
            OneTimeWorkRequestBuilder<RoutineExecutionWorker>()
                .setInputData(workDataOf(RoutineExecutionWorker.KEY_ROUTINE_ID to routineId))
                .build()
        )

        // Re-arm tomorrow's alarm only if the routine is still enabled and
        // still time-based — the user may have disabled or rescheduled it
        // since this alarm was originally set.
        if (routine != null && routine.isEnabled && routine.trigger == RoutineTrigger.TIME_BASED &&
            routine.triggerValue.isNotBlank()
        ) {
            scheduler.schedule(context, routineId, routine.triggerValue)
        }
    }

    companion object {
        const val EXTRA_ROUTINE_ID = "routine_id"
    }
}
