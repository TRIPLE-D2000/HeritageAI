package com.heritage.ai.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

data class ContactResult(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val photoUri: String?
)

/**
 * ContactManager — searches device contacts and provides intents for
 * calling, texting, or composing messages to a found contact.
 *
 * Heritage AI never sends a message autonomously without first showing
 * the user a confirmation — this class only *prepares* the intent;
 * the calling code (ChatViewModel / DeviceControlManager) is responsible
 * for surfacing a confirmation before invoking [Context.startActivity].
 */
@Singleton
class ContactManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /** Searches contacts by display name, returning up to [limit] matches. */
    suspend fun searchContacts(query: String, limit: Int = 10): List<ContactResult> =
        withContext(Dispatchers.IO) {
            val results = mutableListOf<ContactResult>()
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.PHOTO_URI
            )
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$query%")

            runCatching {
                context.contentResolver.query(uri, projection, selection, selectionArgs, null)
                    ?.use { cursor ->
                        val idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                        val nameCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                        val numberCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        val photoCol = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)

                        val seen = mutableSetOf<String>()
                        while (cursor.moveToNext() && results.size < limit) {
                            val id = cursor.getString(idCol)
                            if (id in seen) continue  // Dedupe multi-number contacts
                            seen += id
                            results += ContactResult(
                                id = id,
                                name = cursor.getString(nameCol) ?: "Unknown",
                                phoneNumber = cursor.getString(numberCol) ?: "",
                                photoUri = if (photoCol >= 0) cursor.getString(photoCol) else null
                            )
                        }
                    }
            }
            results
        }

    /** Returns an intent that opens the dialer pre-filled with [phoneNumber]. */
    fun callIntent(phoneNumber: String): Intent =
        Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))

    /** Returns an intent that opens the SMS app pre-filled to [phoneNumber] with [message]. */
    fun smsIntent(phoneNumber: String, message: String = ""): Intent =
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phoneNumber")).apply {
            putExtra("sms_body", message)
        }
}
