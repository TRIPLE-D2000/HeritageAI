package com.heritage.ai.presentation.theme

import androidx.compose.ui.graphics.Color

// ──────────────────────────────────────────────────
// HERITAGE AI — Brand Color System
// Signature: Deep Violet + Teal, cosmic intelligence
// ──────────────────────────────────────────────────

// Primary palette — Deep Heritage Violet
val HeritageViolet = Color(0xFF6B4EFF)         // Primary brand
val HeritageVioletDim = Color(0xFF9B82FF)       // Light variant
val HeritageVioletDeep = Color(0xFF4A2FD9)      // Pressed state
val HeritagePurpleContainer = Color(0xFF1E1454) // Dark container
val HeritagePurpleLight = Color(0xFFEDE7FF)     // Light container

// Secondary palette — Teal pulse (voice visualizer)
val HeritageTeal = Color(0xFF00D4B4)            // Voice active
val HeritageTealDim = Color(0xFF00A896)         // Dim teal
val HeritageTealGlow = Color(0x5500D4B4)        // Glow overlay (alpha 33%)

// Surface palette — Dark Mode
val HeritageSurfaceDark = Color(0xFF0D0B1A)     // App background dark
val HeritageSurface1Dark = Color(0xFF15132B)    // Card surface dark
val HeritageSurface2Dark = Color(0xFF1C1A35)    // Elevated surface dark
val HeritageSurface3Dark = Color(0xFF26234A)    // Highest elevation dark
val HeritageOutlineDark = Color(0xFF3D3660)     // Borders/dividers dark

// Surface palette — Light Mode
val HeritageSurfaceLight = Color(0xFFF6F4FF)    // App background light
val HeritageSurface1Light = Color(0xFFFFFFFF)   // Card surface light
val HeritageSurface2Light = Color(0xFFF0EEFF)   // Elevated surface light
val HeritageOutlineLight = Color(0xFFCAC4E0)    // Borders/dividers light

// Text colors
val HeritageTextPrimary = Color(0xFFE8E3FF)     // Primary text dark
val HeritageTextSecondary = Color(0xFF9E97C4)   // Secondary text dark
val HeritageTextTertiary = Color(0xFF6B6490)    // Hint text dark
val HeritageTextPrimaryLight = Color(0xFF1A1540) // Primary text light
val HeritageTextSecondaryLight = Color(0xFF5B547A) // Secondary text light

// Semantic colors
val HeritageSuccess = Color(0xFF4CAF82)         // Success green
val HeritageError = Color(0xFFFF6B6B)           // Error red
val HeritageWarning = Color(0xFFFFB347)         // Warning amber
val HeritageInfo = Color(0xFF64B5F6)            // Info blue

// Bubble/message colors
val HeritageBubbleUser = Color(0xFF6B4EFF)      // User message bubble
val HeritageBubbleAI = Color(0xFF1C1A35)        // AI message bubble dark
val HeritageBubbleAILight = Color(0xFFF0EEFF)   // AI message bubble light

// Voice visualizer pulse colors
val Heritage_Pulse1 = Color(0xFF6B4EFF)
val Heritage_Pulse2 = Color(0xFF00D4B4)
val Heritage_Pulse3 = Color(0xFFB388FF)
val Heritage_Pulse4 = Color(0xFF64FFDA)

// Gradient stops
val HeritageGradientStart = Color(0xFF6B4EFF)
val HeritageGradientMid = Color(0xFF9B42DB)
val HeritageGradientEnd = Color(0xFF00D4B4)

// Overlay / scrim
val HeritageScrim = Color(0xCC0D0B1A)           // 80% black for dialogs
val HeritageSeparator = Color(0x1AFFFFFF)        // 10% white separator
