package com.heritage.ai.util

import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

data class FileSearchResult(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val dateModified: Long,
    val mimeType: String
)

/**
 * FileSearchManager — searches device storage for files by name,
 * using MediaStore (the scoped-storage-compliant approach on Android
 * 10+) rather than raw filesystem traversal, which is increasingly
 * restricted by the OS.
 *
 * Searches across Downloads, Documents, Images, Video, and Audio
 * MediaStore collections in parallel-ish sequential queries.
 */
@Singleton
class FileSearchManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /**
     * Searches for files whose display name contains [query].
     * Returns up to [limit] results across all supported MediaStore collections.
     */
    suspend fun searchFiles(query: String, limit: Int = 20): List<FileSearchResult> =
        withContext(Dispatchers.IO) {
            val results = mutableListOf<FileSearchResult>()

            results += queryCollection(
                MediaStore.Files.getContentUri("external"), query, limit
            )

            results.sortedByDescending { it.dateModified }.take(limit)
        }

    /**
     * Convenience: searches only within the Downloads folder.
     */
    suspend fun searchDownloads(query: String, limit: Int = 20): List<FileSearchResult> =
        withContext(Dispatchers.IO) {
            queryCollection(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, query, limit
            )
        }

    private fun queryCollection(
        uri: android.net.Uri,
        query: String,
        limit: Int
    ): List<FileSearchResult> {
        val results = mutableListOf<FileSearchResult>()
        val projection = arrayOf(
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.MIME_TYPE
        )
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$query%")
        val sortOrder = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC LIMIT $limit"

        runCatching {
            context.contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
                ?.use { cursor ->
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    val pathCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                    val mimeCol = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)

                    while (cursor.moveToNext()) {
                        results += FileSearchResult(
                            name = cursor.getString(nameCol) ?: "Unknown",
                            path = if (pathCol >= 0) cursor.getString(pathCol) ?: "" else "",
                            sizeBytes = cursor.getLong(sizeCol),
                            dateModified = cursor.getLong(dateCol) * 1000L,
                            mimeType = if (mimeCol >= 0) cursor.getString(mimeCol) ?: "" else ""
                        )
                    }
                }
        }
        return results
    }

    /** Formats a byte count as a human-readable string (e.g. "2.4 MB"). */
    fun formatSize(bytes: Long): String {
        val units = listOf("B", "KB", "MB", "GB")
        var size = bytes.toDouble()
        var unitIndex = 0
        while (size >= 1024 && unitIndex < units.lastIndex) {
            size /= 1024
            unitIndex++
        }
        return "%.1f %s".format(size, units[unitIndex])
    }
}
