package com.heritage.ai.data.repository

import com.heritage.ai.data.local.dao.MemoryDao
import com.heritage.ai.data.local.dao.MessageDao
import com.heritage.ai.data.local.entity.toDomain
import com.heritage.ai.data.local.entity.toEntity
import com.heritage.ai.data.remote.api.LLMApi
import com.heritage.ai.data.remote.model.ApiMessage
import com.heritage.ai.data.remote.model.ChatRequest
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.domain.model.Memory
import com.heritage.ai.domain.model.MemoryCategory
import com.heritage.ai.domain.repository.MemoryRepository
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryRepositoryImpl @Inject constructor(
    private val memoryDao: MemoryDao,
    private val messageDao: MessageDao,
    private val llmApi: LLMApi,
    private val prefs: AppPreferences
) : MemoryRepository {

    private val gson = Gson()

    override fun getAllMemories(): Flow<List<Memory>> {
        return memoryDao.getAllMemories().map { it.map { entity -> entity.toDomain() } }
    }

    override suspend fun getTopMemories(limit: Int): List<Memory> {
        return memoryDao.getTopMemories(limit).map { it.toDomain() }
    }

    override fun getMemoriesByCategory(category: MemoryCategory): Flow<List<Memory>> {
        return memoryDao.getMemoriesByCategory(category.name).map { it.map { e -> e.toDomain() } }
    }

    override suspend fun searchMemories(query: String): List<Memory> {
        return memoryDao.searchMemories(query).map { it.toDomain() }
    }

    override suspend fun saveMemory(memory: Memory) {
        memoryDao.insertMemory(memory.toEntity())
    }

    override suspend fun deleteMemory(memoryId: String) {
        memoryDao.deleteMemoryById(memoryId)
    }

    override suspend fun recordAccess(memoryId: String) {
        memoryDao.recordAccess(memoryId)
    }

    /**
     * Uses the LLM to extract memorable facts from a conversation
     * and persists them as structured [Memory] objects.
     *
     * Returns the number of memories extracted.
     */
    override suspend fun extractMemoriesFromConversation(conversationId: String): Int {
        val memoryEnabled = prefs.longTermMemoryEnabled.first()
        if (!memoryEnabled) return 0

        return try {
            val messages = messageDao.getMessagesSnapshot(conversationId)
            if (messages.size < 2) return 0

            val conversationText = messages.takeLast(20).joinToString("\n") { msg ->
                "${msg.role}: ${msg.content}"
            }

            val model = prefs.llmModel.first()
            val prompt = """
Analyze this conversation and extract important personal facts about the user that are worth remembering long-term.

Return a JSON array of memory objects. Each object should have:
- "content": A clear, concise statement of the fact (e.g., "Studies Computer Engineering at Federal University")
- "category": One of: PERSONAL, PROFESSIONAL, INTERESTS, BEHAVIORAL, KNOWLEDGE, RELATIONSHIP, LOCATION, TEMPORAL
- "importance": Integer 1-10 (10 = very important personal fact, 1 = trivial detail)

Only include genuinely important, stable facts. Skip conversational filler.
Return ONLY valid JSON, no explanation.

Conversation:
$conversationText
            """.trimIndent()

            val request = ChatRequest(
                model = model,
                messages = listOf(ApiMessage(role = "user", content = prompt)),
                maxTokens = 500,
                temperature = 0.2,
                toolsDisabled = true
            )

            val response = llmApi.createChatCompletion(request)
            val content = response.body()?.choices?.firstOrNull()?.message?.content ?: return 0

            // Parse JSON response
            val jsonStr = content
                .replace("```json", "")
                .replace("```", "")
                .trim()

            val type = object : TypeToken<List<Map<String, Any>>>() {}.type
            val extracted: List<Map<String, Any>> = gson.fromJson(jsonStr, type) ?: return 0

            var count = 0
            extracted.forEach { item ->
                try {
                    val memContent = item["content"] as? String ?: return@forEach
                    val catStr = item["category"] as? String ?: "KNOWLEDGE"
                    val importance = ((item["importance"] as? Double)?.toInt()) ?: 5

                    val category = runCatching { MemoryCategory.valueOf(catStr) }
                        .getOrDefault(MemoryCategory.KNOWLEDGE)

                    val memory = Memory(
                        id = UUID.randomUUID().toString(),
                        content = memContent,
                        category = category,
                        importance = importance.coerceIn(1, 10),
                        source = conversationId,
                        createdAt = System.currentTimeMillis()
                    )
                    memoryDao.insertMemory(memory.toEntity())
                    count++
                } catch (_: Exception) { /* skip malformed memory */ }
            }
            count
        } catch (_: Exception) {
            0
        }
    }

    override suspend fun pruneOldMemories() {
        val cutoffTime = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(90)
        memoryDao.pruneStaleMemories(cutoffTime)
    }
}
