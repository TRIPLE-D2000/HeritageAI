package com.heritage.ai.legal

/**
 * LegalDocs — the Terms of Service and Privacy Policy shown in the app.
 *
 * Bump [VERSION] whenever either text changes in a meaningful way: every user
 * will then be asked to accept again (see LegalGate / AskAssistantUseCase).
 * The same text is published in /legal/*.md for the Play Store privacy-policy URL.
 */
object LegalDocs {
    const val VERSION = "2026-11-17"

    /** TODO: put your real support email here before publishing. */
    const val CONTACT_EMAIL = "REPLACE_WITH_YOUR_EMAIL"

    val PRIVACY: String = """HERITAGE AI PRIVACY POLICY
Version: 2026-11-17

1. WHO WE ARE
Heritage AI is an Android voice and chat assistant built by Daniel Damilare, an independent developer in Nigeria ("we", "us"). We are the data controller for the personal data described in this policy. Contact: $CONTACT_EMAIL

2. THE SHORT VERSION
• Your chats, memories and settings are stored on your phone, in an encrypted database.
• To answer you, your message and some context (listed in section 4) is sent over the internet to AI services.
• We do not sell your data and we do not show ads.
• You can delete everything at any time: Settings > Legal & Privacy > Delete all my data.

3. WHAT WE COLLECT AND WHY
• What you give us: messages you type or speak, your name and "about yourself" text if you add them, your settings, and an API key if you choose to use your own AI provider.
• What the app creates on your phone: conversation history, summaries, and "memories" (facts the assistant saves so it can help you better).
• Device information the app uses only when needed: the list of apps installed on your phone (so it can open them), your notifications (only when you ask about them), your contacts (so you can call or text people by name), and the Android features you switch on (see section 6).
We use this to answer you, carry out device actions you ask for, remember useful context, and keep the app working and secure.

4. WHAT LEAVES YOUR PHONE
When you send a message, the app sends it to our server (hosted on Cloudflare), which forwards it to AI providers: Groq (the language model) and, for web lookups, Tavily (search). A request can include:
• your message and recent conversation;
• your name, "about yourself" text and saved memories;
• the current date and time;
• the names of apps installed on your phone;
• your notifications, only when your message asks about notifications, alerts or messages, with numeric codes hidden.
Contacts: your contact list is never uploaded. Name matching happens on your phone. If you ask the assistant to look up a contact, the result is shown in the chat and becomes part of the conversation, so it may be sent with later messages. Delete the conversation if you do not want that.
Voice: speech-to-text uses Android's speech recognition service, which may process audio on your phone or send it to Google under Google's terms. Wake-word detection runs on your phone; that audio is not recorded or sent.
Your own AI provider: if you add your own key, requests go to that provider (for example OpenAI) under its terms and privacy policy.
International transfers: these providers operate outside Nigeria (for example in the United States), so your data is transferred internationally. By accepting this policy you agree to that transfer.
We do not intentionally store the content of your messages on our own server. Cloudflare may keep technical logs (such as time, IP address and request size), and AI providers may keep data under their own policies.

5. LEGAL BASIS
We process your data on the basis of your consent, given when you accept this policy, and to provide the service you ask for. You can withdraw consent at any time by deleting your data in Settings or uninstalling the app. Withdrawing consent does not affect processing already done.

6. PERMISSIONS
Every permission is optional, is used only for the feature it belongs to, and can be turned off in your phone settings.
• Microphone: voice questions and wake word.
• Contacts and Phone: calling and texting people by name.
• Notification access: reading notifications when you ask.
• Accessibility service: the volume-button shortcut and performing actions you ask for (such as tapping or scrolling).
• Display over other apps: the quick-answer window.
• Modify system settings: brightness control.
We do not use these permissions to collect data for any other purpose.

7. SECURITY AND STORAGE
Your conversations are stored in a database encrypted with a key kept in the Android Keystore. A personal API key you add is encrypted on your phone. Traffic to our server and to AI providers uses HTTPS. No system is perfectly secure, so please keep your phone locked and updated.

8. RETENTION
Data stays on your phone until you delete it or uninstall the app. We keep no account for you on our servers.

9. YOUR RIGHTS
Under the Nigeria Data Protection Act 2023 you have the right to access, correct, delete and restrict the use of your personal data, to object to processing, to data portability, and to withdraw consent. Most of this you can do inside the app. For anything else, email $CONTACT_EMAIL. You also have the right to complain to the Nigeria Data Protection Commission (www.ndpc.gov.ng).

10. CHILDREN
Heritage AI is not for people under 18, and we do not knowingly collect data from them. If you believe a child has used the app, contact us and we will help delete the data.

11. CHANGES
If we change this policy in a meaningful way, the app will ask you to review and accept it again.

12. CONTACT
Daniel Damilare, Nigeria. Email: $CONTACT_EMAIL
""".trimIndent()

    val TERMS: String = """HERITAGE AI TERMS OF SERVICE
Version: 2026-11-17

1. ACCEPTING THESE TERMS
By tapping "Accept and continue" or using Heritage AI you agree to these Terms and to the Privacy Policy. You must be 18 or older. If you do not agree, do not use the app.

2. THE SERVICE
Heritage AI is an AI assistant for Android that answers questions and can act on your phone when you ask. It is early-stage software provided by Daniel Damilare ("we", "us"). Features may change, break or be removed. Future paid features, if any, may have extra terms.

3. AI CAN BE WRONG
AI answers can be incorrect, incomplete or out of date. Check anything important before you rely on it. Heritage AI does not give professional medical, legal, financial or safety advice. Do not use it for emergencies: to reach emergency services, use your phone's normal dialer.

4. ACTIONS ON YOUR PHONE
When you ask, the assistant can open apps, change settings, call numbers, and prepare text messages. You authorise these actions. Voice recognition and AI can mishear or misunderstand, so check the dialer or message before you confirm. You are responsible for calls and messages made from your phone, including airtime or other charges. We are not responsible for a wrong contact, wrong number or unintended action.

5. YOUR CONTENT AND OTHER PEOPLE'S INFORMATION
You keep ownership of what you type, say or store. You allow us to process it to provide the service as described in the Privacy Policy. If you use contacts, you are responsible for using other people's information lawfully and respectfully. Do not use the app to harass, spam, deceive or threaten anyone.

6. ACCEPTABLE USE
You agree not to: break the law; use the app to harm others; try to break, overload or misuse our server or the AI services behind it; copy or reverse-engineer the app except where the law allows; or use automated means to get around any limits.

7. THIRD-PARTY SERVICES
The app depends on services we do not control, including Cloudflare, Groq, Tavily and Google speech recognition. They may change, fail or stop working, and their own terms apply to their part of the service.

8. OUR RIGHTS
The app, its name and its design belong to Daniel Damilare. We give you a personal, non-exclusive, non-transferable licence to use the app. Open-source components remain under their own licences.

9. SUSPENSION AND ENDING
You can stop using the app at any time. We may suspend or end access if these Terms are broken or to protect the service or other people.

10. NO WARRANTY
To the extent allowed by law, the app is provided "as is" and "as available", without promises that it will be accurate, uninterrupted or error-free.

11. LIMIT OF LIABILITY
To the extent allowed by law, we are not liable for indirect or consequential loss, lost data, lost profit, or loss caused by AI answers or by actions you confirm. Our total liability for any claim is limited to the amount you paid us for the app in the previous 12 months, which is nothing if the app is free. Nothing in these Terms limits liability that cannot be limited under Nigerian law.

12. GOVERNING LAW
These Terms are governed by the laws of the Federal Republic of Nigeria, and the courts of Nigeria have jurisdiction, subject to any mandatory consumer rights you have.

13. CHANGES AND CONTACT
We may update these Terms. If the change is meaningful, the app will ask you to accept the new version. Questions: $CONTACT_EMAIL
""".trimIndent()
}
