package com.heritage.ai.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * HeritageNotificationListenerService — reads notifications with user consent.
 *
 * This service is enabled ONLY when the user grants notification access in
 * Settings → Notifications → Special app access → Notification access.
 *
 * Heritage AI uses this to:
 * - Answer "What are my notifications?" voice queries
 * - Surface important alerts during routines (e.g. Study Mode awareness)
 * - Never sends notification data to any server without user confirmation
 */
class HeritageNotificationListenerService : NotificationListenerService() {

    companion object {
        var instance: HeritageNotificationListenerService? = null
            private set

        private val _incoming = MutableSharedFlow<NotificationData>(extraBufferCapacity = 32)
        val incoming = _incoming.asSharedFlow()
    }

    data class NotificationData(
        val packageName: String,
        val appName: String,
        val title: String,
        val text: String,
        val postedAt: Long
    )

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        // Skip notifications from Heritage itself
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return
        val extras = notification.extras

        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        if (title.isBlank() && text.isBlank()) return

        val appName = runCatching {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        }.getOrDefault(sbn.packageName)

        _incoming.tryEmit(
            NotificationData(
                packageName = sbn.packageName,
                appName = appName,
                title = title,
                text = text,
                postedAt = sbn.postTime
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * Returns a formatted summary of all active notifications.
     */
    fun getActiveNotificationsSummary(): String {
        val active = runCatching { activeNotifications }.getOrNull()
            ?: return "No notifications available"
        if (active.isEmpty()) return "No active notifications"

        return active
            .filter { it.packageName != packageName }
            .take(10)
            .joinToString("\n") { sbn ->
                val extras = sbn.notification.extras
                val title = extras.getCharSequence("android.title")?.toString() ?: ""
                val text = extras.getCharSequence("android.text")?.toString() ?: ""
                val appName = runCatching {
                    packageManager.getApplicationLabel(
                        packageManager.getApplicationInfo(sbn.packageName, 0)
                    ).toString()
                }.getOrDefault(sbn.packageName)
                "• [$appName] $title: $text"
            }
    }
}
