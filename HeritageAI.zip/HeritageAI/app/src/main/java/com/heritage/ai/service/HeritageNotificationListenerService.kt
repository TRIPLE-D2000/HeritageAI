package com.heritage.ai.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * HeritageNotificationListenerService — reads active notifications.
 *
 * Root cause of "says it can but then says it can't":
 * The LLM was hallucinating capability it didn't have — the service
 * was connected but getActiveNotifications() was returning empty
 * because the listener wasn't properly bound yet on first launch.
 *
 * Fix: added isServiceEnabled() check so the app now tells the LLM
 * in the system prompt whether the service is actually connected,
 * preventing it from promising something it can't deliver.
 */
class HeritageNotificationListenerService : NotificationListenerService() {

    companion object {
        var instance: HeritageNotificationListenerService? = null
            private set

        private val _incoming = MutableSharedFlow<NotificationData>(extraBufferCapacity = 32)
        val incoming = _incoming.asSharedFlow()

        /** Returns true if the notification listener is actually connected and ready. */
        fun isServiceEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            val cn = ComponentName(context, HeritageNotificationListenerService::class.java)
            return flat.contains(cn.flattenToString()) && instance != null
        }

        /** Returns true if the user has granted notification listener permission. */
        fun isPermissionGranted(context: Context): Boolean {
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            return flat.contains(context.packageName)
        }
    }

    data class NotificationData(
        val packageName: String,
        val appName: String,
        val title: String,
        val text: String,
        val postedAt: Long
    )

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
        // Request rebind so we reconnect automatically
        requestRebind(ComponentName(this, HeritageNotificationListenerService::class.java))
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return
        val extras = notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text  = extras.getCharSequence("android.text")?.toString()  ?: ""
        if (title.isBlank() && text.isBlank()) return

        val appName = runCatching {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        }.getOrDefault(sbn.packageName)

        _incoming.tryEmit(NotificationData(sbn.packageName, appName, title, text, sbn.postTime))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * Returns a formatted summary of all active notifications.
     * Called when the user asks "What are my notifications?"
     */
    fun getActiveNotificationsSummary(): String {
        // Guard: make sure we're actually connected before trying
        if (instance == null) {
            return "Notification access is not connected yet. " +
                   "Please grant Notification Access to Heritage AI in Settings, " +
                   "then restart the app."
        }

        val active = runCatching { activeNotifications }.getOrNull()
        if (active.isNullOrEmpty()) return "You have no active notifications right now."

        val filtered = active
            .filter { it.packageName != packageName }
            .filter { it.isClearable } // Skip persistent system notifications
            .take(15)

        if (filtered.isEmpty()) return "No user notifications currently active."

        return filtered.joinToString("\n") { sbn ->
            val extras = sbn.notification.extras
            val title = extras.getCharSequence("android.title")?.toString() ?: ""
            val text  = extras.getCharSequence("android.text")?.toString()  ?: ""
            val app   = runCatching {
                packageManager.getApplicationLabel(
                    packageManager.getApplicationInfo(sbn.packageName, 0)
                ).toString()
            }.getOrDefault(sbn.packageName)
            "• [$app] ${if (title.isNotBlank()) "$title: " else ""}$text"
        }
    }
}
