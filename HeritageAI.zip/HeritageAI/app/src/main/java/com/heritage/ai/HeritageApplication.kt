package com.heritage.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.heritage.ai.worker.MemoryMaintenanceWorker
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Inject

/**
 * HeritageApplication — application entry point.
 *
 * Responsibilities:
 * - Bootstraps the Hilt dependency graph (@HiltAndroidApp)
 * - Configures WorkManager with Hilt's worker factory so background
 *   workers (reminders, memory pruning) can use constructor injection
 * - Creates all notification channels up-front so services never
 *   race to create them on first use
 * - Schedules recurring maintenance jobs (memory pruning, etc.)
 */
@HiltAndroidApp
class HeritageApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    /** App-wide coroutine scope for fire-and-forget startup tasks. */
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        MemoryMaintenanceWorker.schedule(this)
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(if (BuildConfig.DEBUG_MODE) android.util.Log.DEBUG else android.util.Log.ERROR)
            .build()

    /**
     * Pre-creates all notification channels referenced by services.
     * Doing this once at startup (rather than lazily inside each service)
     * avoids duplicate-channel races and keeps channel metadata consistent.
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)

        val channels = listOf(
            NotificationChannel(
                "heritage_voice_channel", "Voice Assistant", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Active voice recognition session"; setShowBadge(false) },

            NotificationChannel(
                "heritage_wake_channel", "Wake Word Detection", NotificationManager.IMPORTANCE_MIN
            ).apply { description = "Always listening for 'Hey Heritage'"; setShowBadge(false) },

            NotificationChannel(
                "heritage_bubble_channel", "Floating Bubble", NotificationManager.IMPORTANCE_MIN
            ).apply { description = "Floating assistant bubble active"; setShowBadge(false) },

            NotificationChannel(
                "heritage_reminders_channel", "Reminders & Alarms", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Reminders and scheduled notifications"; setShowBadge(true) },

            NotificationChannel(
                "heritage_routines_channel", "Automation Routines", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Routine execution status"; setShowBadge(false) }
        )

        manager.createNotificationChannels(channels)
    }
}
