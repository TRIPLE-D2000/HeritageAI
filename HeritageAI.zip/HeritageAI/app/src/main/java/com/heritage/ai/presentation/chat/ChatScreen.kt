package com.heritage.ai.presentation.chat

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberPermissionState
import com.heritage.ai.domain.model.Conversation
import com.heritage.ai.presentation.components.*
import com.heritage.ai.presentation.theme.*
import kotlinx.coroutines.launch

// ──────────────────────────────────────────────────
// CHAT SCREEN
// ──────────────────────────────────────────────────

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    onNavigateToSettings: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToRoutines: () -> Unit,
    savedStateHandle: androidx.lifecycle.SavedStateHandle? = null,
    viewModel: ChatViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val partialVoiceText by viewModel.partialVoiceText.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val haptic = LocalHapticFeedback.current
    val keyboard = LocalSoftwareKeyboardController.current

    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    // Consume a conversation selection returned from the History screen.
    // SavedStateHandle survives process death and is the standard
    // Compose Navigation pattern for "returning a result" to a screen
    // that's still alive further down the back stack.
    val pendingConversationId = savedStateHandle
        ?.getStateFlow<String?>(com.heritage.ai.presentation.navigation.SELECTED_CONVERSATION_KEY, null)
        ?.collectAsStateWithLifecycle()
    LaunchedEffect(pendingConversationId?.value) {
        pendingConversationId?.value?.let { id ->
            viewModel.onEvent(ChatEvent.SwitchConversation(id))
            savedStateHandle.remove<String>(com.heritage.ai.presentation.navigation.SELECTED_CONVERSATION_KEY)
        }
    }

    // Auto-scroll to the latest message
    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    // Dismiss voice overlay when keyboard opens
    LaunchedEffect(uiState.inputText) {
        if (uiState.inputText.isNotBlank() && uiState.showVoiceOverlay) {
            viewModel.onEvent(ChatEvent.StopListening)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ConversationDrawer(
                conversations = uiState.conversations,
                currentId = uiState.currentConversationId,
                onNewConversation = {
                    viewModel.onEvent(ChatEvent.NewConversation)
                    scope.launch { drawerState.close() }
                },
                onSelectConversation = { id ->
                    viewModel.onEvent(ChatEvent.SwitchConversation(id))
                    scope.launch { drawerState.close() }
                },
                onDeleteConversation = { id ->
                    viewModel.onEvent(ChatEvent.DeleteConversation(id))
                },
                onNavigateToHistory = {
                    scope.launch { drawerState.close() }
                    onNavigateToHistory()
                },
                onNavigateToSettings = {
                    scope.launch { drawerState.close() }
                    onNavigateToSettings()
                },
                onNavigateToRoutines = {
                    scope.launch { drawerState.close() }
                    onNavigateToRoutines()
                }
            )
        }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // ── Main scaffold ──
            Scaffold(
                topBar = {
                    ChatTopBar(
                        userName = uiState.userName,
                        isSpeaking = uiState.assistantState.isSpeaking,
                        isOnline = uiState.isOnline,
                        onMenuClick = { scope.launch { drawerState.open() } },
                        onSettingsClick = onNavigateToSettings
                    )
                },
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.ime
            ) { paddingValues ->

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    // ── Message list ──
                    Box(modifier = Modifier.weight(1f)) {
                        if (uiState.messages.isEmpty()) {
                            WelcomeView(
                                userName = uiState.userName,
                                onSuggestionClick = { suggestion ->
                                    viewModel.onEvent(ChatEvent.SendTextMessage(suggestion))
                                }
                            )
                        } else {
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(vertical = 8.dp),
                                reverseLayout = false
                            ) {
                                items(
                                    items = uiState.messages,
                                    key = { it.id }
                                ) { message ->
                                    MessageBubble(
                                        message = message,
                                        modifier = Modifier.animateItem(
                                            fadeInSpec = tween(250),
                                            placementSpec = spring(stiffness = Spring.StiffnessMediumLow)
                                        )
                                    )
                                }

                                // Typing indicator
                                if (uiState.isLoading) {
                                    item(key = "typing") {
                                        TypingIndicator(
                                            modifier = Modifier.animateItem()
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Error snackbar
                    AnimatedVisibility(uiState.error != null) {
                        uiState.error?.let { error ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 4.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = error,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { viewModel.onEvent(ChatEvent.DismissError) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Close, "Dismiss",
                                            tint = MaterialTheme.colorScheme.onErrorContainer,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    GradientDivider()

                    // ── Input bar ──
                    ChatInputBar(
                        text = uiState.inputText,
                        isLoading = uiState.isLoading,
                        isListening = uiState.assistantState.isListening,
                        onTextChange = { viewModel.onEvent(ChatEvent.UpdateInput(it)) },
                        onSend = {
                            if (uiState.inputText.isNotBlank()) {
                                viewModel.onEvent(ChatEvent.SendTextMessage(uiState.inputText))
                                keyboard?.hide()
                            }
                        },
                        onMicClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            keyboard?.hide()
                            if (micPermission.status.isGranted) {
                                if (uiState.assistantState.isListening) {
                                    viewModel.onEvent(ChatEvent.StopListening)
                                } else {
                                    viewModel.onEvent(ChatEvent.StartListening)
                                }
                            } else {
                                micPermission.launchPermissionRequest()
                            }
                        }
                    )
                }
            }

            // ── Voice overlay (full screen) ──
            VoiceOverlay(
                isVisible = uiState.showVoiceOverlay,
                isListening = uiState.assistantState.isListening,
                partialText = partialVoiceText,
                amplitude = uiState.voiceAmplitude,
                onDismiss = { viewModel.onEvent(ChatEvent.StopListening) },
                onStartListening = { viewModel.onEvent(ChatEvent.StartListening) },
                onStopListening = { viewModel.onEvent(ChatEvent.StopListening) },
                modifier = Modifier.statusBarsPadding()
            )
        }
    }
}

// ──────────────────────────────────────────────────
// TOP BAR
// ──────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatTopBar(
    userName: String,
    isSpeaking: Boolean,
    isOnline: Boolean,
    onMenuClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "speaking_pulse")
    val speakingAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
        label = "alpha"
    )

    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Heritage logo
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(HeritageViolet, HeritageTeal), Offset.Zero, Offset.Infinite)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("H", color = Color.White, style = MaterialTheme.typography.titleSmall)
                }
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Heritage AI", style = MaterialTheme.typography.titleMedium)
                        if (!isOnline) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.errorContainer
                            ) {
                                Text(
                                    "Offline",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = if (isSpeaking) "Speaking…" else if (userName.isNotBlank()) "Hi, $userName" else "How can I help?",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(
                            alpha = if (isSpeaking) speakingAlpha else 0.55f
                        ),
                        maxLines = 1
                    )
                }
            }
        },
        navigationIcon = {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, "Open menu")
            }
        },
        actions = {
            IconButton(onClick = onSettingsClick) {
                Icon(Icons.Default.Settings, "Settings")
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            titleContentColor = MaterialTheme.colorScheme.onBackground
        )
    )
}

// ──────────────────────────────────────────────────
// INPUT BAR
// ──────────────────────────────────────────────────

@Composable
private fun ChatInputBar(
    text: String,
    isLoading: Boolean,
    isListening: Boolean,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onMicClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Text field
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Ask anything…", style = MaterialTheme.typography.bodyMedium) },
            shape = RoundedCornerShape(24.dp),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Sentences,
                imeAction = ImeAction.Send
            ),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            maxLines = 5,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
            ),
            textStyle = MaterialTheme.typography.bodyMedium.copy(
                color = MaterialTheme.colorScheme.onSurface
            )
        )

        // Mic / Send button
        val showSend = text.isNotBlank()
        AnimatedContent(
            targetState = showSend,
            transitionSpec = {
                scaleIn(tween(150)) + fadeIn(tween(150)) togetherWith
                        scaleOut(tween(100)) + fadeOut(tween(100))
            },
            label = "send_mic_toggle"
        ) { isSend ->
            if (isSend) {
                FilledIconButton(
                    onClick = onSend,
                    enabled = !isLoading,
                    modifier = Modifier.size(48.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Icon(Icons.AutoMirrored.Filled.Send, "Send", modifier = Modifier.size(20.dp))
                    }
                }
            } else {
                FilledTonalIconButton(
                    onClick = onMicClick,
                    modifier = Modifier.size(48.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = if (isListening)
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Icon(
                        if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                        "Voice input",
                        modifier = Modifier.size(22.dp),
                        tint = if (isListening)
                            MaterialTheme.colorScheme.onPrimary
                        else
                            MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ──────────────────────────────────────────────────
// WELCOME VIEW — empty state
// ──────────────────────────────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WelcomeView(
    userName: String,
    onSuggestionClick: (String) -> Unit
) {
    val greeting = if (userName.isNotBlank()) "Hello, $userName" else "Hello there"
    val suggestions = listOf(
        "What can you do?",
        "Turn on the flashlight",
        "Set an alarm for 7 AM",
        "What's the weather like?",
        "Open WhatsApp",
        "Tell me something interesting"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.weight(1f))

        // Orb
        VoiceOrb(amplitude = 0f, isListening = false, size = 90.dp)

        Spacer(Modifier.height(24.dp))

        Text(
            text = greeting,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        Text(
            text = "I'm Heritage — your AI assistant.\nHow can I help you today?",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            modifier = Modifier.padding(top = 8.dp)
        )

        Spacer(Modifier.height(40.dp))

        // Suggestion chips grid
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            suggestions.forEach { s ->
                SuggestionChip(label = s, onClick = { onSuggestionClick(s) })
            }
        }

        Spacer(Modifier.weight(1f))
    }
}

// ──────────────────────────────────────────────────
// CONVERSATION DRAWER
// ──────────────────────────────────────────────────

@Composable
private fun ConversationDrawer(
    conversations: List<Conversation>,
    currentId: String,
    onNewConversation: () -> Unit,
    onSelectConversation: (String) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToRoutines: () -> Unit
) {
    ModalDrawerSheet(
        modifier = Modifier.width(300.dp),
        drawerContainerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            listOf(HeritageViolet, HeritageTeal),
                            Offset.Zero, Offset.Infinite
                        )
                    )
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Column {
                    Text("Heritage AI", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                    Text("Your AI assistant", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.7f))
                }
            }

            // New conversation button
            NavigationDrawerItem(
                label = { Text("New conversation") },
                selected = false,
                icon = { Icon(Icons.Default.Add, null) },
                onClick = onNewConversation,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )

            GradientDivider(Modifier.padding(vertical = 8.dp))

            // Conversations list
            Text(
                "Recent",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(conversations, key = { it.id }) { conv ->
                    NavigationDrawerItem(
                        label = {
                            Text(
                                conv.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        selected = conv.id == currentId,
                        onClick = { onSelectConversation(conv.id) },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 1.dp),
                        badge = {
                            if (conv.isPinned) Icon(Icons.Default.PushPin, null, Modifier.size(14.dp))
                        }
                    )
                }
            }

            GradientDivider(Modifier.padding(vertical = 8.dp))

            // Bottom nav items
            listOf(
                Triple(Icons.Default.AutoAwesome, "Routines", onNavigateToRoutines),
                Triple(Icons.Default.History, "History", onNavigateToHistory),
                Triple(Icons.Default.Settings, "Settings", onNavigateToSettings)
            ).forEach { (icon, label, action) ->
                NavigationDrawerItem(
                    label = { Text(label) },
                    selected = false,
                    icon = { Icon(icon, null) },
                    onClick = action,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 1.dp)
                )
            }

            Spacer(Modifier.navigationBarsPadding())
        }
    }
}
