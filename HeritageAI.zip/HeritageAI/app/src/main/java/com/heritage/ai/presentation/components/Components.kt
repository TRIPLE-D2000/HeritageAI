package com.heritage.ai.presentation.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.MessageRole
import com.heritage.ai.presentation.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ──────────────────────────────────────────────────
// MESSAGE BUBBLE
// ──────────────────────────────────────────────────

@Composable
fun MessageBubble(
    message: Message,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == MessageRole.USER
    val isDark = !MaterialTheme.colorScheme.background.luminance().let { it > 0.5f }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        // AI avatar dot
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(HeritageViolet, HeritageTeal),
                            start = Offset.Zero,
                            end = Offset.Infinite
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "H",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Default
                )
            }
            Spacer(Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            // Bubble
            Surface(
                shape = RoundedCornerShape(
                    topStart = if (isUser) 20.dp else 4.dp,
                    topEnd = if (isUser) 4.dp else 20.dp,
                    bottomStart = 20.dp,
                    bottomEnd = 20.dp
                ),
                color = if (isUser)
                    MaterialTheme.colorScheme.primary
                else
                    MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = if (isUser) 0.dp else 2.dp,
                modifier = Modifier.widthIn(max = 300.dp)
            ) {
                if (message.isError) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                } else {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isUser)
                            MaterialTheme.colorScheme.onPrimary
                        else
                            MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }

            // Timestamp
            Text(
                text = formatTimestamp(message.timestamp),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }

        if (isUser) Spacer(Modifier.width(8.dp))
    }
}

private fun formatTimestamp(ts: Long): String {
    return SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ts))
}

// ──────────────────────────────────────────────────
// TYPING INDICATOR — three pulsing dots
// ──────────────────────────────────────────────────

@Composable
fun TypingIndicator(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "typing")

    Row(
        modifier = modifier
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        // AI avatar
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(HeritageViolet, HeritageTeal),
                        start = Offset.Zero,
                        end = Offset.Infinite
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text("H", color = Color.White, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))

        Surface(
            shape = RoundedCornerShape(topStart = 4.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(3) { index ->
                    val scale by infiniteTransition.animateFloat(
                        initialValue = 0.6f,
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(400, easing = EaseInOut),
                            repeatMode = RepeatMode.Reverse,
                            initialStartOffset = StartOffset(index * 130)
                        ),
                        label = "dot_$index"
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .scale(scale)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
            }
        }
    }
}

// ──────────────────────────────────────────────────
// VOICE ORB — animated ring for voice visualizer
// ──────────────────────────────────────────────────

@Composable
fun VoiceOrb(
    amplitude: Float,
    isListening: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 100.dp
) {
    val isLowRam = com.heritage.ai.presentation.theme.LocalIsLowRamDevice.current
    val infiniteTransition = rememberInfiniteTransition(label = "orb")

    val baseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOut),
            repeatMode = RepeatMode.Reverse
        ),
        label = "base_scale"
    )

    val pulseScale = 1f + (amplitude * 0.4f)
    val ringAlpha = if (isListening) 0.35f + amplitude * 0.5f else 0f

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        // Skip expensive multi-layer glow on low-RAM devices (Itel A50 etc.)
        // A single-layer core orb still looks great and avoids GPU jank.
        if (isListening && !isLowRam) {
            // Outer glow ring
            Box(
                modifier = Modifier
                    .size(size * 1.5f * pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                HeritageViolet.copy(alpha = ringAlpha * 0.5f),
                                HeritageTeal.copy(alpha = 0f)
                            )
                        )
                    )
            )
            // Mid ring
            Box(
                modifier = Modifier
                    .size(size * 1.2f * pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                HeritageTeal.copy(alpha = ringAlpha),
                                HeritageViolet.copy(alpha = 0f)
                            )
                        )
                    )
            )
        } else if (isListening) {
            // Low-RAM fallback: single subtle ring (one draw call instead of two)
            Box(
                modifier = Modifier
                    .size(size * 1.15f * pulseScale)
                    .clip(CircleShape)
                    .background(HeritageViolet.copy(alpha = ringAlpha * 0.6f))
            )
        }

        // Core orb — always rendered (cheap single draw call)
        Box(
            modifier = Modifier
                .size(size * if (isListening) baseScale else 1f)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = if (isListening)
                            listOf(HeritageViolet, HeritageTeal)
                        else
                            listOf(
                                MaterialTheme.colorScheme.surfaceVariant,
                                MaterialTheme.colorScheme.surface
                            ),
                        start = Offset.Zero,
                        end = Offset.Infinite
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "H",
                color = if (isListening) Color.White
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                fontSize = (size.value * 0.3).sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ──────────────────────────────────────────────────
// GRADIENT DIVIDER
// ──────────────────────────────────────────────────

@Composable
fun GradientDivider(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        Color.Transparent
                    )
                )
            )
    )
}

// ──────────────────────────────────────────────────
// CHIP — quick-action suggestion chips
// ──────────────────────────────────────────────────

@Composable
fun SuggestionChip(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AssistChip(
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
        modifier = modifier,
        colors = AssistChipDefaults.assistChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        border = AssistChipDefaults.assistChipBorder(
            borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
            enabled = true
        )
    )
}
