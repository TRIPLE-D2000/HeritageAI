package com.heritage.ai.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.heritage.ai.domain.model.MemoryCategory
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.MessageRole

// ──────────────────────────────────────────────────
// ROOM ENTITIES
// ──────────────────────────────────────────────────

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val messageCount: Int,
    val summary: String,
    val isPinned: Boolean,
    val tags: String  // JSON serialized list
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,
    val content: String,
    val timestamp: Long,
    val tokenCount: Int,
    val model: String,
    val isError: Boolean,
    val metadata: String  // JSON serialized map
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val content: String,
    val category: String,
    val importance: Int,
    val source: String,
    val createdAt: Long,
    val accessCount: Int,
    val lastAccessed: Long
)

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val icon: String,
    val actionsJson: String,  // JSON serialized list of RoutineAction
    val trigger: String,
    val triggerValue: String,
    val isEnabled: Boolean,
    val createdAt: Long,
    val lastRunAt: Long,
    val runCount: Int
)

// ──────────────────────────────────────────────────
// TYPE CONVERTERS for Room
// ──────────────────────────────────────────────────
class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromStringList(value: List<String>): String = gson.toJson(value)

    @TypeConverter
    fun toStringList(value: String): List<String> {
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }

    @TypeConverter
    fun fromStringMap(value: Map<String, String>): String = gson.toJson(value)

    @TypeConverter
    fun toStringMap(value: String): Map<String, String> {
        val type = object : TypeToken<Map<String, String>>() {}.type
        return gson.fromJson(value, type) ?: emptyMap()
    }
}

// ──────────────────────────────────────────────────
// ENTITY MAPPERS
// ──────────────────────────────────────────────────
fun MessageEntity.toDomain(): Message = Message(
    id = id,
    conversationId = conversationId,
    role = MessageRole.valueOf(role),
    content = content,
    timestamp = timestamp,
    tokenCount = tokenCount,
    model = model,
    isError = isError,
    metadata = Gson().fromJson(metadata, object : TypeToken<Map<String, String>>() {}.type)
        ?: emptyMap()
)

fun Message.toEntity(): MessageEntity = MessageEntity(
    id = id,
    conversationId = conversationId,
    role = role.name,
    content = content,
    timestamp = timestamp,
    tokenCount = tokenCount,
    model = model,
    isError = isError,
    metadata = Gson().toJson(metadata)
)

fun MemoryEntity.toDomain() = com.heritage.ai.domain.model.Memory(
    id = id,
    content = content,
    category = MemoryCategory.valueOf(category),
    importance = importance,
    source = source,
    createdAt = createdAt,
    accessCount = accessCount,
    lastAccessed = lastAccessed
)

fun com.heritage.ai.domain.model.Memory.toEntity() = MemoryEntity(
    id = id,
    content = content,
    category = category.name,
    importance = importance,
    source = source,
    createdAt = createdAt,
    accessCount = accessCount,
    lastAccessed = lastAccessed
)
