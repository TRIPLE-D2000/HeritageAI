package com.heritage.ai.domain.repository

import com.heritage.ai.domain.model.Conversation
import com.heritage.ai.domain.model.Memory
import com.heritage.ai.domain.model.MemoryCategory
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.Routine
import kotlinx.coroutines.flow.Flow

// ──────────────────────────────────────────────────
// CHAT REPOSITORY
// ──────────────────────────────────────────────────
interface ChatRepository {

    /** All conversations, sorted newest first. */
    fun getAllConversations(): Flow<List<Conversation>>

    /** All messages for a given conversation, sorted oldest first. */
    fun getMessages(conversationId: String): Flow<List<Message>>

    /** Snapshot of recent messages for building the API context. */
    suspend fun getRecentMessagesSnapshot(conversationId: String, limit: Int = 20): List<Message>

    /** Creates a new conversation and returns its ID. */
    suspend fun createConversation(title: String = "New Conversation"): String

    /** Saves a user or assistant message to a conversation. */
    suspend fun saveMessage(message: Message)

    /** Sends a message to the configured LLM and returns the reply. */
    suspend fun sendToLLM(
        conversationId: String,
        userMessage: String,
        contextMemories: List<Memory> = emptyList()
    ): Result<Message>

    /** Updates the conversation title. */
    suspend fun updateConversationTitle(conversationId: String, title: String)

    /** Deletes a conversation and all its messages. */
    suspend fun deleteConversation(conversationId: String)

    /** Searches messages across all conversations. */
    suspend fun searchMessages(query: String): List<Message>

    /** Generates a summary for a conversation using the LLM. */
    suspend fun generateSummary(conversationId: String): Result<String>
}

// ──────────────────────────────────────────────────
// MEMORY REPOSITORY
// ──────────────────────────────────────────────────
interface MemoryRepository {

    /** All memories, sorted by importance. */
    fun getAllMemories(): Flow<List<Memory>>

    /** Top N most important memories for context injection. */
    suspend fun getTopMemories(limit: Int = 10): List<Memory>

    /** Memories by category. */
    fun getMemoriesByCategory(category: MemoryCategory): Flow<List<Memory>>

    /** Searches memories by content. */
    suspend fun searchMemories(query: String): List<Memory>

    /** Saves or updates a memory. */
    suspend fun saveMemory(memory: Memory)

    /** Deletes a memory. */
    suspend fun deleteMemory(memoryId: String)

    /** Records that a memory was accessed (for importance weighting). */
    suspend fun recordAccess(memoryId: String)

    /** Extracts and saves memories from a conversation using the LLM. */
    suspend fun extractMemoriesFromConversation(conversationId: String): Int

    /** Prunes stale, unimportant memories. */
    suspend fun pruneOldMemories()
}

// ──────────────────────────────────────────────────
// ROUTINE REPOSITORY
// ──────────────────────────────────────────────────
interface RoutineRepository {

    fun getAllRoutines(): Flow<List<Routine>>

    fun getEnabledRoutines(): Flow<List<Routine>>

    suspend fun getRoutineById(id: String): Routine?

    suspend fun saveRoutine(routine: Routine)

    suspend fun deleteRoutine(routineId: String)

    suspend fun recordRun(routineId: String)

    suspend fun setEnabled(routineId: String, enabled: Boolean)
}
