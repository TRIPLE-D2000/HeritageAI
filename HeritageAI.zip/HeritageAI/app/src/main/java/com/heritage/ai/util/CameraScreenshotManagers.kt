package com.heritage.ai.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.core.content.FileProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * CameraManager — launches the system camera app for photo/video capture.
 *
 * Heritage AI delegates to the device's native Camera app via intent
 * rather than embedding a custom Camera2/CameraX preview, keeping the
 * permission surface minimal (CAMERA permission is requested but the
 * actual capture UI is the trusted system camera).
 */
@Singleton
class CameraManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /** Builds an intent + output URI pair for capturing a photo to app-private storage. */
    fun buildCapturePhotoIntent(): Pair<Intent, Uri> {
        val photoFile = File.createTempFile(
            "heritage_photo_${System.currentTimeMillis()}",
            ".jpg",
            context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES)
        )
        val photoUri = FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", photoFile
        )
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        return intent to photoUri
    }

    /** Builds an intent for capturing a short video clip. */
    fun buildCaptureVideoIntent(): Intent =
        Intent(MediaStore.ACTION_VIDEO_CAPTURE)

    /** Opens the system camera app directly (no capture callback needed). */
    fun openCameraApp(): Intent =
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
}

/**
 * ScreenshotManager — captures the device screen using the
 * MediaProjection API.
 *
 * Android requires explicit, per-session user consent for screen
 * capture (a system dialog shown via [MediaProjectionManager.createScreenCaptureIntent]).
 * This class holds the launcher contract result and performs the
 * actual pixel capture + PNG encoding once permission is granted.
 *
 * Usage from an Activity:
 * ```
 * val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
 *     if (result.resultCode == Activity.RESULT_OK) {
 *         screenshotManager.startCapture(result.resultCode, result.data!!)
 *     }
 * }
 * launcher.launch(screenshotManager.getCaptureIntent())
 * ```
 */
@Singleton
class ScreenshotManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val projectionManager by lazy {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
    }

    /** Returns the system intent that prompts the user for screen-capture consent. */
    fun getCaptureIntent(): Intent = projectionManager.createScreenCaptureIntent()

    /**
     * Captures a single frame of the screen after consent has been granted,
     * saving it to the Pictures/Heritage AI directory and returning its URI.
     *
     * This is a simplified single-frame capture suitable for "take a screenshot"
     * voice commands — it sets up a VirtualDisplay, grabs one frame via
     * ImageReader, then immediately tears down the projection to minimize
     * the time spent capturing (and the associated system "screen being
     * recorded" indicator).
     */
    suspend fun captureScreen(resultCode: Int, data: Intent): Uri? =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            val metrics = context.resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            val mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            val imageReader = android.media.ImageReader.newInstance(
                width, height, android.graphics.PixelFormat.RGBA_8888, 2
            )

            val virtualDisplay = mediaProjection.createVirtualDisplay(
                "HeritageScreenshot", width, height, density,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface, null, null
            )

            imageReader.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage()
                if (image != null) {
                    val uri = saveImageToGallery(image, width, height)
                    image.close()
                    virtualDisplay.release()
                    mediaProjection.stop()
                    imageReader.close()
                    if (cont.isActive) cont.resume(uri) { }
                }
            }, android.os.Handler(android.os.Looper.getMainLooper()))

            cont.invokeOnCancellation {
                runCatching { virtualDisplay.release() }
                runCatching { mediaProjection.stop() }
                runCatching { imageReader.close() }
            }
        }

    private fun saveImageToGallery(image: android.media.Image, width: Int, height: Int): Uri? {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * width

        val bitmap = android.graphics.Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, android.graphics.Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        val cropped = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, width, height)

        val filename = "Heritage_Screenshot_${System.currentTimeMillis()}.png"
        val resolver = context.contentResolver
        val contentValues = android.content.ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Heritage AI")
        }

        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        uri?.let {
            resolver.openOutputStream(it)?.use { out ->
                cropped.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
            }
        }
        bitmap.recycle()
        cropped.recycle()
        return uri
    }
}
