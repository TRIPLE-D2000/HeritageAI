package com.heritage.ai.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * PermissionHelper — a single injectable class that answers "does this app
 * currently have permission X?" without requiring a Context in every call site.
 *
 * Separating permission-status queries from permission-request UI keeps the
 * business logic (ViewModels, Repositories) free of Activity/Fragment refs.
 * The actual [ActivityResultLauncher] permission requests live in the Compose
 * screens via [rememberPermissionState] from Accompanist.
 */
@Singleton
class PermissionHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    // ── Microphone ─────────────────────────────────
    fun hasMicrophonePermission(): Boolean =
        has(Manifest.permission.RECORD_AUDIO)

    // ── Camera ─────────────────────────────────────
    fun hasCameraPermission(): Boolean =
        has(Manifest.permission.CAMERA)

    // ── Contacts ───────────────────────────────────
    fun hasContactsPermission(): Boolean =
        has(Manifest.permission.READ_CONTACTS)

    // ── Calendar ───────────────────────────────────
    fun hasCalendarReadPermission(): Boolean =
        has(Manifest.permission.READ_CALENDAR)

    fun hasCalendarWritePermission(): Boolean =
        has(Manifest.permission.WRITE_CALENDAR)

    // ── Notifications ──────────────────────────────
    fun hasPostNotificationsPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            has(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            true  // Granted implicitly on older Android versions
        }
    }

    // ── Storage / Media ────────────────────────────
    fun hasMediaReadPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            has(Manifest.permission.READ_MEDIA_IMAGES) &&
                    has(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            has(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    // ── Special permissions (no standard grant flow) ──
    /** Requires [Settings.ACTION_MANAGE_OVERLAY_PERMISSION] intent, not a dialog. */
    fun hasOverlayPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(context)
        else
            true

    /** Requires [Settings.ACTION_ACCESSIBILITY_SETTINGS] intent. */
    fun hasAccessibilityServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("${context.packageName}/${context.packageName}.service.HeritageAccessibilityService")
    }

    /** Requires [Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS] intent. */
    fun hasNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return flat.contains(context.packageName)
    }

    /** Requires [Settings.ACTION_MANAGE_WRITE_SETTINGS] intent. */
    fun canWriteSystemSettings(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.System.canWrite(context)
        else
            true

    // ── Exact alarm permission (API 31+) ───────────
    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE)
                    as android.app.AlarmManager
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    // ── Bluetooth (API 31+) ────────────────────────
    fun hasBluetoothConnectPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            has(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            has(Manifest.permission.BLUETOOTH)
        }
    }

    // ── Helper ─────────────────────────────────────
    private fun has(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) ==
                PackageManager.PERMISSION_GRANTED

    /**
     * Returns a map of all feature-permission pairs and their current status.
     * Used by the Settings screen to show a permission checklist.
     */
    fun getPermissionStatus(): Map<String, Boolean> = mapOf(
        "Microphone" to hasMicrophonePermission(),
        "Camera" to hasCameraPermission(),
        "Contacts" to hasContactsPermission(),
        "Calendar" to hasCalendarReadPermission(),
        "Notifications (post)" to hasPostNotificationsPermission(),
        "Media / Storage" to hasMediaReadPermission(),
        "Overlay (bubble)" to hasOverlayPermission(),
        "Accessibility service" to hasAccessibilityServiceEnabled(),
        "Notification listener" to hasNotificationListenerEnabled(),
        "Modify system settings" to canWriteSystemSettings(),
        "Exact alarms" to canScheduleExactAlarms(),
        "Bluetooth" to hasBluetoothConnectPermission()
    )
}
