package com.heritage.ai.presentation.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ──────────────────────────────────────────────────
// DARK COLOR SCHEME — Default Heritage AI experience
// ──────────────────────────────────────────────────
private val HeritageDarkColorScheme = darkColorScheme(
    primary = HeritageViolet,
    onPrimary = HeritageTextPrimary,
    primaryContainer = HeritagePurpleContainer,
    onPrimaryContainer = HeritageVioletDim,

    secondary = HeritageTeal,
    onSecondary = HeritageSurfaceDark,
    secondaryContainer = Color(0xFF00352E),
    onSecondaryContainer = HeritageTeal,

    tertiary = Heritage_Pulse3,
    onTertiary = HeritageSurfaceDark,
    tertiaryContainer = Color(0xFF2A1F5C),
    onTertiaryContainer = Heritage_Pulse3,

    background = HeritageSurfaceDark,
    onBackground = HeritageTextPrimary,

    surface = HeritageSurface1Dark,
    onSurface = HeritageTextPrimary,
    surfaceVariant = HeritageSurface2Dark,
    onSurfaceVariant = HeritageTextSecondary,

    surfaceTint = HeritageViolet,
    inverseSurface = HeritagePurpleLight,
    inverseOnSurface = HeritageTextPrimaryLight,
    inversePrimary = HeritageVioletDeep,

    outline = HeritageOutlineDark,
    outlineVariant = Color(0xFF2A2645),

    error = HeritageError,
    onError = HeritageTextPrimary,
    errorContainer = Color(0xFF5C1F1F),
    onErrorContainer = HeritageError,

    scrim = HeritageScrim,
)

// ──────────────────────────────────────────────────
// LIGHT COLOR SCHEME
// ──────────────────────────────────────────────────
private val HeritageLightColorScheme = lightColorScheme(
    primary = HeritageVioletDeep,
    onPrimary = HeritageSurface1Light,
    primaryContainer = HeritagePurpleLight,
    onPrimaryContainer = HeritageVioletDeep,

    secondary = HeritageTealDim,
    onSecondary = HeritageSurface1Light,
    secondaryContainer = Color(0xFFB2EFE6),
    onSecondaryContainer = Color(0xFF003730),

    tertiary = Color(0xFF7B52C4),
    onTertiary = HeritageSurface1Light,
    tertiaryContainer = Color(0xFFE8D9FF),
    onTertiaryContainer = Color(0xFF3A0078),

    background = HeritageSurfaceLight,
    onBackground = HeritageTextPrimaryLight,

    surface = HeritageSurface1Light,
    onSurface = HeritageTextPrimaryLight,
    surfaceVariant = HeritageSurface2Light,
    onSurfaceVariant = HeritageTextSecondaryLight,

    surfaceTint = HeritageVioletDeep,
    inverseSurface = HeritageSurface2Dark,
    inverseOnSurface = HeritageTextPrimary,
    inversePrimary = HeritageVioletDim,

    outline = HeritageOutlineLight,
    outlineVariant = Color(0xFFE3DFEE),

    error = Color(0xFFCC3333),
    onError = HeritageSurface1Light,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),

    scrim = Color(0x990D0B1A),
)

// ──────────────────────────────────────────────────
// HERITAGE THEME COMPOSABLE
// ──────────────────────────────────────────────────
@Composable
fun HeritageAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep false to preserve brand identity
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> HeritageDarkColorScheme
        else -> HeritageLightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
            WindowCompat.setDecorFitsSystemWindows(window, false)
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = HeritageTypography,
        shapes = HeritageShapes,
        content = content
    )
}
