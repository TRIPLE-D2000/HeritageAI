package com.heritage.ai.di

import android.content.Context
import com.heritage.ai.data.local.crypto.DatabaseEncryption
import com.heritage.ai.data.local.dao.ConversationDao
import com.heritage.ai.data.local.dao.MemoryDao
import com.heritage.ai.data.local.dao.MessageDao
import com.heritage.ai.data.local.dao.RoutineDao
import com.heritage.ai.data.local.database.HeritageDatabase
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.data.remote.api.LLMApi
import com.heritage.ai.data.remote.interceptor.AuthInterceptor
import com.heritage.ai.data.remote.interceptor.DynamicBaseUrlInterceptor
import com.heritage.ai.data.repository.ChatRepositoryImpl
import com.heritage.ai.data.repository.MemoryRepositoryImpl
import com.heritage.ai.data.repository.RoutineRepositoryImpl
import com.heritage.ai.domain.repository.ChatRepository
import com.heritage.ai.domain.repository.MemoryRepository
import com.heritage.ai.domain.repository.RoutineRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

// ──────────────────────────────────────────────────
// DATABASE MODULE
// ──────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideEncryption(@ApplicationContext context: Context): DatabaseEncryption {
        return DatabaseEncryption(context)
    }

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context,
        encryption: DatabaseEncryption
    ): HeritageDatabase {
        val passphrase = encryption.getDatabasePassphrase()
        return HeritageDatabase.create(context, passphrase)
    }

    @Provides
    fun provideConversationDao(db: HeritageDatabase): ConversationDao = db.conversationDao()

    @Provides
    fun provideMessageDao(db: HeritageDatabase): MessageDao = db.messageDao()

    @Provides
    fun provideMemoryDao(db: HeritageDatabase): MemoryDao = db.memoryDao()

    @Provides
    fun provideRoutineDao(db: HeritageDatabase): RoutineDao = db.routineDao()
}

// ──────────────────────────────────────────────────
// NETWORK MODULE
// ──────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(prefs: AppPreferences): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = if (com.heritage.ai.BuildConfig.DEBUG_MODE)
                HttpLoggingInterceptor.Level.BODY
            else
                HttpLoggingInterceptor.Level.NONE
        }

        return OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor {
                prefs.llmApiKey.first()
            })
            .addInterceptor(DynamicBaseUrlInterceptor {
                prefs.llmBaseUrl.first()
            })
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(
        okHttpClient: OkHttpClient,
        prefs: AppPreferences
    ): Retrofit {
        // Start with default base URL; DynamicBaseUrlInterceptor will override per-request
        val baseUrl = runBlocking { prefs.llmBaseUrl.first() }
            .takeIf { it.isNotBlank() } ?: "https://red-grass-398aheritage-ai.dandamdad2000.workers.dev/"

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideLLMApi(retrofit: Retrofit): LLMApi = retrofit.create(LLMApi::class.java)
}

// ──────────────────────────────────────────────────
// REPOSITORY MODULE
// ──────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindChatRepository(impl: ChatRepositoryImpl): ChatRepository

    @Binds
    @Singleton
    abstract fun bindMemoryRepository(impl: MemoryRepositoryImpl): MemoryRepository

    @Binds
    @Singleton
    abstract fun bindRoutineRepository(impl: RoutineRepositoryImpl): RoutineRepository
}

// ──────────────────────────────────────────────────
// APP MODULE — misc singleton providers
// ──────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAppPreferences(@ApplicationContext context: Context): AppPreferences {
        return AppPreferences(context)
    }

    @Provides
    @Singleton
    fun provideApplicationContext(@ApplicationContext context: Context): Context = context
}
