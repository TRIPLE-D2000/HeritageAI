package com.heritage.ai.data.remote.model

import com.google.gson.annotations.SerializedName

// ── API Models ─────────────────────────────────────────────────────────────

data class ChatRequest(
    @SerializedName("model") val model: String,
    @SerializedName("messages") val messages: List<ApiMessage>,
    @SerializedName("temperature") val temperature: Double = 0.9,
    @SerializedName("max_tokens") val maxTokens: Int = 2048,
    @SerializedName("stream") val stream: Boolean = false,
    @SerializedName("top_p") val topP: Double = 1.0,
    @SerializedName("frequency_penalty") val frequencyPenalty: Double = 0.0,
    @SerializedName("presence_penalty") val presencePenalty: Double = 0.1,
    @SerializedName("user") val user: String? = null,
    // Lets non-chat calls (memory extraction, etc.) tell the Worker to skip
    // attaching device/search tools — gpt-oss has a strong tool-calling
    // bias, and a "return JSON facts" task has no business being offered
    // device controls it could misfire on.
    @SerializedName("tools_disabled") val toolsDisabled: Boolean = false
)

data class ApiMessage(
    @SerializedName("role") val role: String,
    // Nullable: a pure tool-call response has null content, and Gson's
    // reflection-based deserialization will set this to actual null
    // regardless of Kotlin's compile-time non-null typing if left as a
    // plain String — every read site must handle that.
    @SerializedName("content") val content: String? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("tool_calls") val toolCalls: List<ToolCall>? = null,
    @SerializedName("tool_call_id") val toolCallId: String? = null
)

data class ToolCall(
    @SerializedName("id") val id: String = "",
    @SerializedName("type") val type: String = "function",
    @SerializedName("function") val function: FunctionCall = FunctionCall()
)

data class FunctionCall(
    @SerializedName("name") val name: String = "",
    // Raw JSON-encoded object string, e.g. {"level":"50"} — matches the
    // shape CommandParser already expects for a command's "params".
    @SerializedName("arguments") val arguments: String = "{}"
)

data class ChatResponse(
    @SerializedName("id") val id: String = "",
    @SerializedName("object") val obj: String = "",
    @SerializedName("created") val created: Long = 0,
    @SerializedName("model") val model: String = "",
    @SerializedName("choices") val choices: List<Choice> = emptyList(),
    @SerializedName("usage") val usage: TokenUsage? = null
)

data class Choice(
    @SerializedName("index") val index: Int = 0,
    @SerializedName("message") val message: ApiMessage? = null,
    @SerializedName("delta") val delta: ApiMessage? = null,
    @SerializedName("finish_reason") val finishReason: String? = null
)

data class TokenUsage(
    @SerializedName("prompt_tokens") val promptTokens: Int = 0,
    @SerializedName("completion_tokens") val completionTokens: Int = 0,
    @SerializedName("total_tokens") val totalTokens: Int = 0
)

// ── LLM Provider Config ────────────────────────────────────────────────────

data class LLMProvider(
    val id: String,
    val name: String,
    val baseUrl: String,
    val defaultModel: String,
    val models: List<String>
)

object LLMProviders {
    // Heritage Proxy — Cloudflare Worker that hides the API key from users.
    // Users select this and get AI immediately with no setup needed.
    val HERITAGE_PROXY = LLMProvider(
        id = "heritage_proxy",
        name = "Heritage AI (Recommended)",
        baseUrl = "https://lively-silence-5100heritage-ai.dandamdad2000.workers.dev/",
        defaultModel = "openai/gpt-oss-20b",
        models = listOf("openai/gpt-oss-20b", "openai/gpt-oss-120b", "qwen/qwen3.6-27b")
    )
    val GROQ = LLMProvider(
        id = "groq", name = "Groq (Own API key)",
        baseUrl = "https://api.groq.com/openai/v1/",
        defaultModel = "openai/gpt-oss-20b",
        models = listOf(
            "openai/gpt-oss-20b",
            "openai/gpt-oss-120b",
            "qwen/qwen3.6-27b",
            "mixtral-8x7b-32768",
            "gemma2-9b-it"
        )
    )
    val OPENAI = LLMProvider(
        id = "openai", name = "OpenAI (Own API key)",
        baseUrl = "https://api.openai.com/v1/",
        defaultModel = "gpt-4o-mini",
        models = listOf("gpt-4o", "gpt-4o-mini", "gpt-4-turbo")
    )
    val TOGETHER = LLMProvider(
        id = "together", name = "Together AI (Own API key)",
        baseUrl = "https://api.together.xyz/v1/",
        defaultModel = "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
        models = listOf("meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
            "mistralai/Mixtral-8x7B-Instruct-v0.1")
    )
    val OLLAMA = LLMProvider(
        id = "ollama", name = "Ollama (Local/Private)",
        baseUrl = "http://localhost:11434/v1/",
        defaultModel = "llama3.2",
        models = listOf("llama3.2", "llama3.1", "mistral", "phi3", "gemma2")
    )
    val ALL = listOf(HERITAGE_PROXY, GROQ, OPENAI, TOGETHER, OLLAMA)
}

// ── System Prompt ──────────────────────────────────────────────────────────

object SystemPromptBuilder {

    fun build(
        memories: List<String> = emptyList(),
        userName: String = "",
        userBio: String = "",
        currentTime: String = "",
        pluginCommands: String = "",
        notificationsAvailable: Boolean = false,
        accessibilityAvailable: Boolean = false,
        activeNotifications: String = "",
        conversationSummary: String = "",
        installedApps: List<String> = emptyList()
    ): String = buildString {

        val name = if (userName.isNotBlank()) userName else "there"

        append("""
You are Heritage AI — a smart, witty personal assistant living on ${name}'s Android phone.

You were created by Daniel (@TRIPLE-D2000). This is true on every installation of
Heritage AI, on any phone. If anyone asks who made you, who your creator or
developer is, or who built Heritage AI, the answer is always Daniel.

PERSONALITY:
- Talk like a knowledgeable friend, not a corporate chatbot
- Be direct, confident, and occasionally funny
- Have real opinions. Don't be wishy-washy
- Use casual language — contractions, natural phrasing
- Be genuinely helpful first, entertaining second
- Don't start every reply with "Sure!" or "Of course!" — just answer

        """.trimIndent())

        if (currentTime.isNotBlank()) {
            append("Current time: $currentTime\n")
            append(
                "Your training data has a fixed cutoff, but the date above may be well " +
                "after it — you have no way to know how much time has passed. Never " +
                "flatly deny or \"correct\" the user about something recent just because " +
                "you don't recognize it (new releases, current events, product updates, " +
                "etc.) — you may simply be out of date, not the user. If a claim sounds " +
                "plausible but unfamiliar, say you can't verify it rather than asserting " +
                "it's false.\n"
            )
        }
        if (userBio.isNotBlank()) {
            append("\n$name, in their own words: $userBio\n")
        }
        if (userName.isNotBlank()) {
            append(
                "You already know who you're talking to — their name is $name. " +
                "Never ask for their name or introduce yourself as if meeting them " +
                "for the first time.\n"
            )
        }
        if (conversationSummary.isNotBlank()) {
            append("\nContext from previous conversations:\n$conversationSummary\n")
        }
        if (memories.isNotEmpty()) {
            append("\nWhat you know about $name:\n")
            memories.forEach { append("- $it\n") }
        }

        append("""

HERITAGE AI FEATURES (you know about all of these):
- Chat: Main conversation screen — where you are right now
- Routines: Automation sequences the user can run. Built-in ones: Study Mode, Gaming Mode, Good Morning, Sleep Mode, Workout Mode. User accesses them via the ☰ menu → Routines
- History: All past conversations, accessible via ☰ menu → History
- Settings: API key, model, voice, permissions — ⚙️ icon top right
- Voice input: Mic button in chat, or triple-press volume-down anywhere on phone
- Background listening: Toggle in Settings → Voice & Speech

        """.trimIndent())

        // Inject installed app list so LLM uses exact names
        if (installedApps.isNotEmpty()) {
            append("\n\nAPPS ON THIS DEVICE — use EXACT format shown for OPEN_APP:\n")
            append(installedApps.take(80).joinToString("\n") { "- $it" })
            append("\nFor OPEN_APP, copy the name exactly as shown above including the package in brackets.\n")
            append("Example: {\"action\": \"OPEN_APP\", \"params\": {\"name\": \"WhatsApp (com.whatsapp)\"}}\n")
        }

        append("""\nYou have real tools available for controlling this device — use them
directly when the user explicitly asks you to DO something (turn on the
flashlight, set an alarm, run a routine, etc). Don't describe what you would
do in text and don't write JSON yourself — call the tool.

TOOL-USE JUDGMENT:
1. Only call a device tool when the user is EXPLICITLY asking you to control their phone RIGHT NOW
2. "open" in a sentence does NOT always mean launch an app. Do NOT call open_app for:
   - "he opened a jar" / "open source software" / "how do I open a bank account" / "the door opened"
3. Only call open_app when the user clearly says "open/launch/start [app name]" — never guess which app they mean
4. For send_sms: always confirm the number and message with the user in plain conversation first, before calling it
5. If a request doesn't match any tool you have, say so — don't call the closest-sounding one anyway

        """.trimIndent())

        if (notificationsAvailable && activeNotifications.isNotBlank()) {
            append("\nCURRENT NOTIFICATIONS ON DEVICE:\n$activeNotifications\n")
            append("(When user asks about notifications, report the above — don't say you can't)\n")
        } else if (!notificationsAvailable) {
            append("\nNotification reading: NOT available (user hasn't granted Notification Access)\n")
        }

        if (!accessibilityAvailable) {
            append("UI automation (type/tap/scroll): NOT available (Accessibility Service not enabled)\n")
        }

        if (pluginCommands.isNotBlank()) {
            append("\nExtra plugin commands:\n$pluginCommands\n")
        }
    }
}
