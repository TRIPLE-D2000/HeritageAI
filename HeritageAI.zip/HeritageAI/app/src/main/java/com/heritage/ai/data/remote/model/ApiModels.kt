package com.heritage.ai.data.remote.model

import com.google.gson.annotations.SerializedName

// ── API Models ─────────────────────────────────────────────────────────────

data class ChatRequest(
    @SerializedName("model") val model: String,
    @SerializedName("messages") val messages: List<ApiMessage>,
    @SerializedName("temperature") val temperature: Double = 0.9,
    @SerializedName("max_tokens") val maxTokens: Int = 2048,
    @SerializedName("stream") val stream: Boolean = false,
    @SerializedName("top_p") val topP: Double = 1.0,
    @SerializedName("frequency_penalty") val frequencyPenalty: Double = 0.0,
    @SerializedName("presence_penalty") val presencePenalty: Double = 0.1,
    @SerializedName("user") val user: String? = null
)

data class ApiMessage(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String,
    @SerializedName("name") val name: String? = null
)

data class ChatResponse(
    @SerializedName("id") val id: String = "",
    @SerializedName("object") val obj: String = "",
    @SerializedName("created") val created: Long = 0,
    @SerializedName("model") val model: String = "",
    @SerializedName("choices") val choices: List<Choice> = emptyList(),
    @SerializedName("usage") val usage: TokenUsage? = null
)

data class Choice(
    @SerializedName("index") val index: Int = 0,
    @SerializedName("message") val message: ApiMessage? = null,
    @SerializedName("delta") val delta: ApiMessage? = null,
    @SerializedName("finish_reason") val finishReason: String? = null
)

data class TokenUsage(
    @SerializedName("prompt_tokens") val promptTokens: Int = 0,
    @SerializedName("completion_tokens") val completionTokens: Int = 0,
    @SerializedName("total_tokens") val totalTokens: Int = 0
)

// ── LLM Provider Config ────────────────────────────────────────────────────

data class LLMProvider(
    val id: String,
    val name: String,
    val baseUrl: String,
    val defaultModel: String,
    val models: List<String>
)

object LLMProviders {
    // Heritage Proxy — Cloudflare Worker that hides the API key from users.
    // Users select this and get AI immediately with no setup needed.
    val HERITAGE_PROXY = LLMProvider(
        id = "heritage_proxy",
        name = "Heritage AI (Recommended)",
        baseUrl = "https://red-grass-398aheritage-ai.dandamdad2000.workers.dev/",
        defaultModel = "llama-3.1-8b-instant",
        models = listOf("llama-3.1-8b-instant", "mixtral-8x7b-32768", "gemma2-9b-it")
    )
    val GROQ = LLMProvider(
        id = "groq", name = "Groq (Own API key)",
        baseUrl = "https://api.groq.com/openai/v1/",
        defaultModel = "llama-3.1-8b-instant",
        models = listOf(
            "llama-3.1-8b-instant",
            "mixtral-8x7b-32768",
            "gemma2-9b-it",
            "qwen-qwq-32b",
            "meta-llama/llama-4-scout-17b-16e-instruct"
        )
    )
    val OPENAI = LLMProvider(
        id = "openai", name = "OpenAI (Own API key)",
        baseUrl = "https://api.openai.com/v1/",
        defaultModel = "gpt-4o-mini",
        models = listOf("gpt-4o", "gpt-4o-mini", "gpt-4-turbo")
    )
    val TOGETHER = LLMProvider(
        id = "together", name = "Together AI (Own API key)",
        baseUrl = "https://api.together.xyz/v1/",
        defaultModel = "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
        models = listOf("meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
            "mistralai/Mixtral-8x7B-Instruct-v0.1")
    )
    val OLLAMA = LLMProvider(
        id = "ollama", name = "Ollama (Local/Private)",
        baseUrl = "http://localhost:11434/v1/",
        defaultModel = "llama3.2",
        models = listOf("llama3.2", "llama3.1", "mistral", "phi3", "gemma2")
    )
    val ALL = listOf(HERITAGE_PROXY, GROQ, OPENAI, TOGETHER, OLLAMA)
}

// ── System Prompt ──────────────────────────────────────────────────────────

object SystemPromptBuilder {

    fun build(
        memories: List<String> = emptyList(),
        userName: String = "",
        currentTime: String = "",
        pluginCommands: String = "",
        notificationsAvailable: Boolean = false,
        accessibilityAvailable: Boolean = false,
        activeNotifications: String = "",
        conversationSummary: String = "",
        installedApps: List<String> = emptyList()
    ): String = buildString {

        val name = if (userName.isNotBlank()) userName else "there"

        append("""
You are Heritage AI — a smart, witty personal assistant living on ${name}'s Android phone.

PERSONALITY:
- Talk like a knowledgeable friend, not a corporate chatbot
- Be direct, confident, and occasionally funny
- Have real opinions. Don't be wishy-washy
- Use casual language — contractions, natural phrasing
- Be genuinely helpful first, entertaining second
- Don't start every reply with "Sure!" or "Of course!" — just answer

        """.trimIndent())

        if (currentTime.isNotBlank()) append("Current time: $currentTime\n")
        if (conversationSummary.isNotBlank()) {
            append("\nContext from previous conversations:\n$conversationSummary\n")
        }
        if (memories.isNotEmpty()) {
            append("\nWhat you know about $name:\n")
            memories.forEach { append("- $it\n") }
        }

        append("""

HERITAGE AI FEATURES (you know about all of these):
- Chat: Main conversation screen — where you are right now
- Routines: Automation sequences the user can run. Built-in ones: Study Mode, Gaming Mode, Good Morning, Sleep Mode, Workout Mode. User accesses them via the ☰ menu → Routines
- History: All past conversations, accessible via ☰ menu → History
- Settings: API key, model, voice, permissions — ⚙️ icon top right
- Voice input: Mic button in chat, or triple-press volume-down anywhere on phone
- Background listening: Toggle in Settings → Voice & Speech

        """.trimIndent())

        // Inject installed app list so LLM uses exact names
        if (installedApps.isNotEmpty()) {
            append("\n\nAPPS INSTALLED ON THIS DEVICE (use EXACT names for OPEN_APP):\n")
            append(installedApps.take(80).joinToString(", "))
            append("\nOnly launch apps from this list. Do not guess app names.\n")
        }

        append("""\nDEVICE COMMANDS — issue these as JSON when the user explicitly asks you to DO something:
```command
{"action": "ACTION_NAME", "params": {...}}
```

Available actions:
- TOGGLE_FLASHLIGHT — params: {"state": "on/off"}
- SET_VOLUME — params: {"level": "0-100", "stream": "media/ring/alarm"}
- SET_BRIGHTNESS — params: {"level": "0-100"}
- TOGGLE_WIFI — params: {"state": "on/off"}
- TOGGLE_BLUETOOTH — params: {"state": "on/off"}
- OPEN_APP — params: {"name": "exact app name"}
- SET_ALARM — params: {"hour": "0-23", "minute": "0-59", "message": "label"}
- SET_DND — params: {"state": "on/off"}
- SEND_SMS — params: {"number": "phone number", "message": "text to send"}
- READ_NOTIFICATIONS — no params needed
- RUN_ROUTINE — params: {"name": "Study Mode/Gaming Mode/Good Morning/Sleep Mode/Workout Mode"}

CRITICAL COMMAND RULES:
1. Only issue a command when the user is EXPLICITLY asking you to control their phone RIGHT NOW
2. "open" in a sentence does NOT mean launch an app. Examples of when NOT to use OPEN_APP:
   - "he opened a jar" → NO command
   - "open source software" → NO command  
   - "can you explain how to open a bank account" → NO command
   - "the door opened" → NO command
3. Only use OPEN_APP when user clearly says "open [app name]", "launch [app]", "start [app]"
4. NEVER guess what app someone wants — only launch if they name it explicitly
5. For SMS: always confirm number and message with user before issuing SEND_SMS command
6. NEVER invent commands that don't exist in the list above

        """.trimIndent())

        if (notificationsAvailable && activeNotifications.isNotBlank()) {
            append("\nCURRENT NOTIFICATIONS ON DEVICE:\n$activeNotifications\n")
            append("(When user asks about notifications, report the above — don't say you can't)\n")
        } else if (!notificationsAvailable) {
            append("\nNotification reading: NOT available (user hasn't granted Notification Access)\n")
        }

        if (!accessibilityAvailable) {
            append("UI automation (type/tap/scroll): NOT available (Accessibility Service not enabled)\n")
        }

        if (pluginCommands.isNotBlank()) {
            append("\nExtra plugin commands:\n$pluginCommands\n")
        }
    }
}
