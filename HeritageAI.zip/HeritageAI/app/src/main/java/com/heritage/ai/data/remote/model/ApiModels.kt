package com.heritage.ai.data.remote.model

import com.google.gson.annotations.SerializedName

// ──────────────────────────────────────────────────
// OPENAI-COMPATIBLE API MODELS
// Compatible with: OpenAI, Azure OpenAI, Groq,
//                  Together.ai, Ollama, LM Studio
// ──────────────────────────────────────────────────

data class ChatRequest(
    @SerializedName("model") val model: String,
    @SerializedName("messages") val messages: List<ApiMessage>,
    @SerializedName("temperature") val temperature: Double = 0.7,
    @SerializedName("max_tokens") val maxTokens: Int = 2048,
    @SerializedName("stream") val stream: Boolean = false,
    @SerializedName("top_p") val topP: Double = 1.0,
    @SerializedName("frequency_penalty") val frequencyPenalty: Double = 0.0,
    @SerializedName("presence_penalty") val presencePenalty: Double = 0.0,
    @SerializedName("user") val user: String? = null
)

data class ApiMessage(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String,
    @SerializedName("name") val name: String? = null
)

data class ChatResponse(
    @SerializedName("id") val id: String,
    @SerializedName("object") val obj: String,
    @SerializedName("created") val created: Long,
    @SerializedName("model") val model: String,
    @SerializedName("choices") val choices: List<Choice>,
    @SerializedName("usage") val usage: TokenUsage?
)

data class Choice(
    @SerializedName("index") val index: Int,
    @SerializedName("message") val message: ApiMessage?,
    @SerializedName("delta") val delta: ApiMessage?,  // Used in streaming
    @SerializedName("finish_reason") val finishReason: String?
)

data class TokenUsage(
    @SerializedName("prompt_tokens") val promptTokens: Int,
    @SerializedName("completion_tokens") val completionTokens: Int,
    @SerializedName("total_tokens") val totalTokens: Int
)

// ──────────────────────────────────────────────────
// LLM PROVIDER CONFIG
// ──────────────────────────────────────────────────

data class LLMProvider(
    val id: String,
    val name: String,
    val baseUrl: String,
    val defaultModel: String,
    val models: List<String>
)

object LLMProviders {
    val OPENAI = LLMProvider(
        id = "openai",
        name = "OpenAI",
        baseUrl = "https://api.openai.com/v1/",
        defaultModel = "gpt-4o",
        models = listOf("gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo")
    )

    val GROQ = LLMProvider(
        id = "groq",
        name = "Groq (Fast)",
        baseUrl = "https://api.groq.com/openai/v1/",
        defaultModel = "llama-3.3-70b-versatile",
        models = listOf(
            "llama-3.3-70b-versatile",
            "llama-3.1-8b-instant",
            "mixtral-8x7b-32768",
            "gemma2-9b-it"
        )
    )

    val TOGETHER = LLMProvider(
        id = "together",
        name = "Together AI",
        baseUrl = "https://api.together.xyz/v1/",
        defaultModel = "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
        models = listOf(
            "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
            "mistralai/Mixtral-8x7B-Instruct-v0.1",
            "google/gemma-2-27b-it"
        )
    )

    val OLLAMA = LLMProvider(
        id = "ollama",
        name = "Ollama (Local)",
        baseUrl = "http://localhost:11434/v1/",
        defaultModel = "llama3.2",
        models = listOf("llama3.2", "llama3.1", "mistral", "phi3", "gemma2")
    )

    val ALL = listOf(OPENAI, GROQ, TOGETHER, OLLAMA)
}

// ──────────────────────────────────────────────────
// SYSTEM PROMPT BUILDER
// ──────────────────────────────────────────────────

object SystemPromptBuilder {
    fun build(
        memories: List<String> = emptyList(),
        userName: String = "",
        currentTime: String = "",
        location: String = "",
        pluginCommands: String = "",
        notificationsAvailable: Boolean = false,
        accessibilityAvailable: Boolean = false
    ): String = buildString {
        append("""
You are Heritage AI — a smart, honest AI assistant on the user's Android phone.

Core rules:
- Be warm, direct, and helpful — never sycophantic
- ONLY claim you can do something if it appears in the capabilities list below
- If a feature is listed as UNAVAILABLE, say so clearly and explain how to enable it in Heritage AI settings
- Keep replies concise; this app has voice output so avoid long lists
- Do not use markdown headers or asterisks — plain text only
- IMPORTANT: You are Heritage AI, a standalone Android app. You are NOT Google Assistant, Siri, Bixby, or Alexa.
- NEVER tell users to configure Google Assistant, OK Google, Voice Match, or any other assistant's settings
- NEVER suggest users go to Chrome settings, Google app settings, or any settings outside of Heritage AI
- For voice input: Heritage AI has its own built-in microphone button. That is the only voice method.
- For wake word: Heritage AI's wake word feature requires a one-time setup from the developer — tell users it is coming soon
- Do not make up features or settings that don't exist in Heritage AI

        """.trimIndent())

        if (userName.isNotBlank()) {
            append("\nUser's name: $userName")
        }
        if (currentTime.isNotBlank()) {
            append("\nCurrent time: $currentTime")
        }
        if (location.isNotBlank()) {
            append("\nUser's location context: $location")
        }

        if (memories.isNotEmpty()) {
            append("\n\n## Long-term memory about this user:\n")
            memories.forEach { memory ->
                append("- $memory\n")
            }
        }

        append("""

## Device commands you can issue (include in responses as JSON fences when needed):
```command
{
  "action": "SET_VOLUME | SET_BRIGHTNESS | TOGGLE_WIFI | TOGGLE_BLUETOOTH |
             TOGGLE_FLASHLIGHT | OPEN_APP | SET_ALARM | SET_DND |
             TAKE_SCREENSHOT | SEND_SMS | READ_NOTIFICATIONS",
  "params": { ... }
}
```
        """.trimIndent())

        // Plugin-contributed commands — built-in plugins and any third-party
        // plugins registered at runtime extend the assistant's vocabulary
        // without requiring changes to this prompt template.
        if (pluginCommands.isNotBlank()) {
            append("\n\n## Additional plugin commands available:\n")
            append(pluginCommands)
        }

        append("\n\nAlways confirm with the user before executing sensitive commands (sending messages, etc.).")
    }
}
