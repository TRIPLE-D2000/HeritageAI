package com.heritage.ai.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * TextToSpeechManager wraps Android TTS with coroutine support.
 *
 * Usage: call [speak] from a coroutine — it suspends until the utterance completes.
 * Call [shutdown] when the owning component is destroyed.
 */
@Singleton
class TextToSpeechManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var tts: TextToSpeech? = null
    private var isReady = false
    private var pendingSpeed = 1.0f
    private var pendingPitch = 1.0f

    init {
        initialize()
    }

    private fun initialize() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isReady = true
                tts?.language = Locale.getDefault()
                tts?.setSpeechRate(pendingSpeed)
                tts?.setPitch(pendingPitch)
            }
        }
    }

    /**
     * Speaks [text] and suspends until the utterance finishes.
     * Silently skips if TTS is not ready.
     */
    suspend fun speak(text: String): Unit = suspendCancellableCoroutine { cont ->
        if (!isReady || tts == null) {
            cont.resume(Unit)
            return@suspendCancellableCoroutine
        }

        val utteranceId = UUID.randomUUID().toString()

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId && cont.isActive) cont.resume(Unit)
            }
            override fun onError(id: String?) {
                if (id == utteranceId && cont.isActive) cont.resume(Unit)
            }
        })

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)

        cont.invokeOnCancellation {
            tts?.stop()
        }
    }

    /** Stops any in-progress speech immediately. */
    fun stop() {
        tts?.stop()
    }

    fun setSpeed(speed: Float) {
        pendingSpeed = speed
        tts?.setSpeechRate(speed)
    }

    fun setPitch(pitch: Float) {
        pendingPitch = pitch
        tts?.setPitch(pitch)
    }

    fun isReady(): Boolean = isReady

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
