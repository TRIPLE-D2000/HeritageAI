package com.heritage.ai.util

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * TextToSpeechManager — rebuilt with auto-reinitialisation.
 *
 * Root cause of "works once then stops":
 * The TTS engine on budget Android devices (especially with Go Edition)
 * shuts itself down after a period of inactivity or after the first
 * utterance completes, and never signals that it has done so.
 * The fix: detect the dead state and reinitialise transparently before
 * every speak() call instead of assuming the engine stays alive.
 */
@Singleton
class TextToSpeechManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var tts: TextToSpeech? = null
    private var isReady = false
    private var pendingSpeed = 1.0f
    private var pendingPitch = 1.0f
    private var pendingVoiceName: String? = null

    // Reinit on first use and after every detected failure
    init { initialize() }

    private fun initialize() {
        // Fully destroy any previous instance first
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        isReady = false

        tts = TextToSpeech(context) { status ->
            isReady = (status == TextToSpeech.SUCCESS)
            if (isReady) {
                tts?.language = Locale.getDefault()
                tts?.setSpeechRate(pendingSpeed)
                tts?.setPitch(pendingPitch)
                applyPendingVoice()
            }
        }
    }

    private fun applyPendingVoice() {
        val name = pendingVoiceName ?: return
        runCatching {
            tts?.voices?.firstOrNull { it.name == name }
        }.getOrNull()?.let { tts?.voice = it }
    }

    /**
     * Voices available on-device right now — no network round-trip, this just
     * reads what the OS TTS engine already reports, so it's effectively free
     * on any device including low-end ones.
     *
     * Filtered to voices that (a) don't require a network connection to speak
     * (avoids a surprise data/latency cost) and (b) are already installed
     * (avoids picking one that silently falls back to the default because its
     * voice data isn't downloaded).
     */
    fun getAvailableVoices(): List<android.speech.tts.Voice> {
        return runCatching {
            tts?.voices
                ?.filter { voice ->
                    !voice.isNetworkConnectionRequired &&
                        !voice.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
                }
                ?.sortedBy { it.locale?.displayName ?: it.name }
        }.getOrNull() ?: emptyList()
    }

    fun setVoice(voiceName: String) {
        pendingVoiceName = voiceName.ifBlank { null }
        applyPendingVoice()
    }

    /**
     * Speak [text], reinitialising the TTS engine if it has died.
     * Suspends until the utterance finishes or times out.
     */
    suspend fun speak(text: String): Unit = suspendCancellableCoroutine { cont ->
        // If engine is dead, reinitialise and retry once
        if (!isReady || tts == null) {
            initialize()
            // Give the engine 1.5s to initialise then try again
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (isReady) {
                    doSpeak(text, cont)
                } else {
                    if (cont.isActive) cont.resume(Unit)
                }
            }, 1500)
            return@suspendCancellableCoroutine
        }
        doSpeak(text, cont)
    }

    private fun doSpeak(
        text: String,
        cont: CancellableContinuation<Unit>
    ) {
        val id = UUID.randomUUID().toString()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(uid: String?) {}
            override fun onDone(uid: String?) {
                if (uid == id && cont.isActive) cont.resume(Unit)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(uid: String?) {
                // Engine error — reinit so next call works
                isReady = false
                if (uid == id && cont.isActive) cont.resume(Unit)
            }
            override fun onError(uid: String?, errorCode: Int) {
                isReady = false
                if (uid == id && cont.isActive) cont.resume(Unit)
            }
        })

        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        // If speak() itself fails, the engine is dead — mark for reinit
        if (result == TextToSpeech.ERROR) {
            isReady = false
            initialize()
            if (cont.isActive) cont.resume(Unit)
        }
    }

    fun stop() {
        try { tts?.stop() } catch (_: Exception) {}
    }

    fun setSpeed(speed: Float) {
        pendingSpeed = speed
        tts?.setSpeechRate(speed)
    }

    fun setPitch(pitch: Float) {
        pendingPitch = pitch
        tts?.setPitch(pitch)
    }

    fun isReady() = isReady

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        isReady = false
    }
}
