package com.heritage.ai.util

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * TextToSpeechManager — rebuilt with auto-reinitialisation.
 *
 * Root cause of "works once then stops":
 * The TTS engine on budget Android devices (especially with Go Edition)
 * shuts itself down after a period of inactivity or after the first
 * utterance completes, and never signals that it has done so.
 * The fix: detect the dead state and reinitialise transparently before
 * every speak() call instead of assuming the engine stays alive.
 */
@Singleton
class TextToSpeechManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var tts: TextToSpeech? = null
    private var isReady = false
    private var pendingSpeed = 1.0f
    private var pendingPitch = 1.0f
    private var pendingVoiceName: String? = null

    // Reinit on first use and after every detected failure
    init { initialize() }

    private fun initialize() {
        // Fully destroy any previous instance first
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        isReady = false

        tts = TextToSpeech(context) { status ->
            isReady = (status == TextToSpeech.SUCCESS)
            if (isReady) {
                tts?.language = Locale.getDefault()
                tts?.setSpeechRate(pendingSpeed)
                tts?.setPitch(pendingPitch)
                applyPendingVoice()
            }
        }
    }

    private fun applyPendingVoice() {
        val name = pendingVoiceName ?: return
        runCatching {
            tts?.voices?.firstOrNull { it.name == name }
        }.getOrNull()?.let { tts?.voice = it }
    }

    /**
     * Voices available on-device right now — no network round-trip, this just
     * reads what the OS TTS engine already reports, so it's effectively free
     * on any device including low-end ones.
     *
     * Filtered to voices that (a) don't require a network connection to speak
     * (avoids a surprise data/latency cost) and (b) are already installed
     * (avoids picking one that silently falls back to the default because its
     * voice data isn't downloaded).
     */
    fun getAvailableVoices(): List<android.speech.tts.Voice> {
        return runCatching {
            tts?.voices
                ?.filter { voice ->
                    !voice.isNetworkConnectionRequired &&
                        !voice.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
                }
                ?.sortedBy { it.locale?.displayName ?: it.name }
        }.getOrNull() ?: emptyList()
    }

    fun setVoice(voiceName: String) {
        pendingVoiceName = voiceName.ifBlank { null }
        applyPendingVoice()
    }

    /**
     * Speak [text], reinitialising the TTS engine if it has died.
     * Suspends until the utterance finishes or times out.
     */
    suspend fun speak(text: String): Unit = suspendCancellableCoroutine { cont ->
        // If engine is dead, reinitialise and retry once
        if (!isReady || tts == null) {
            initialize()
            // Give the engine 1.5s to initialise then try again
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (isReady) {
                    doSpeak(text, cont)
                } else {
                    if (cont.isActive) cont.resume(Unit)
                }
            }, 1500)
            return@suspendCancellableCoroutine
        }
        doSpeak(text, cont)
    }

    /**
     * Speaks [text] in sentence-sized chunks rather than as one long
     * utterance.
     *
     * BUGFIX (beta feedback: "TTS is slow to start on long answers"): the
     * TTS engine has to finish synthesizing an ENTIRE utterance before any
     * audio plays. For a long reply that's real, noticeable processing time
     * on a low-end CPU — not a network delay. Queuing sentence-by-sentence
     * lets playback start on the first sentence while later ones are still
     * being synthesized. Short replies are a single "chunk" and behave
     * exactly as before.
     */
    // The speak() call currently waiting for its utterance to finish. stop()
    // must release it, otherwise callers hang (and UI like "isSpeaking" sticks).
    @Volatile
    private var pendingCont: CancellableContinuation<Unit>? = null

    private fun releasePending() {
        val c = pendingCont
        pendingCont = null
        if (c != null && c.isActive) c.resume(Unit)
    }

    private fun doSpeak(
        text: String,
        cont: CancellableContinuation<Unit>
    ) {
        // A new utterance flushes the old one, so release whoever was waiting on it
        releasePending()
        pendingCont = cont
        val chunks = splitIntoChunks(text)
        if (chunks.isEmpty()) {
            if (cont.isActive) cont.resume(Unit)
            return
        }

        // Only the LAST chunk's id resumes the caller — earlier chunks are
        // fire-and-forget from the coroutine's point of view, they just
        // queue up behind the first one.
        val lastId = UUID.randomUUID().toString()

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(uid: String?) {}
            override fun onDone(uid: String?) {
                if (uid == lastId && cont.isActive) cont.resume(Unit)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(uid: String?) {
                // Engine error — reinit so next call works
                isReady = false
                if (uid == lastId && cont.isActive) cont.resume(Unit)
            }
            override fun onError(uid: String?, errorCode: Int) {
                isReady = false
                if (uid == lastId && cont.isActive) cont.resume(Unit)
            }
        })

        var enqueueFailed = false
        chunks.forEachIndexed { index, chunk ->
            val id = if (index == chunks.lastIndex) lastId else UUID.randomUUID().toString()
            // Flush any old speech on the very first chunk, then add the
            // rest behind it so they play back-to-back in order.
            val mode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val result = tts?.speak(chunk, mode, null, id)
            if (result == TextToSpeech.ERROR) enqueueFailed = true
        }

        // If queuing itself failed, the engine is dead — mark for reinit
        // and don't leave the caller suspended forever.
        if (enqueueFailed) {
            isReady = false
            initialize()
            if (cont.isActive) cont.resume(Unit)
        }
    }

    /**
     * Splits text into TTS-friendly chunks on sentence boundaries.
     * Deliberately simple — the goal is just breaking a long reply into
     * pieces small enough that the first one starts playing quickly, not
     * perfect grammatical parsing. Falls back to the whole string when
     * there's no sentence boundary to split on (e.g. a short reply).
     */
    private fun splitIntoChunks(text: String): List<String> {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return emptyList()
        val sentences = Regex("(?<=[.!?])\\s+")
            .split(trimmed)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        return sentences.ifEmpty { listOf(trimmed) }
    }

    fun stop() {
        try { tts?.stop() } catch (_: Exception) {}
        releasePending()
    }

    fun isSpeaking(): Boolean = try { tts?.isSpeaking == true } catch (_: Exception) { false }

    fun setSpeed(speed: Float) {
        pendingSpeed = speed
        tts?.setSpeechRate(speed)
    }

    fun setPitch(pitch: Float) {
        pendingPitch = pitch
        tts?.setPitch(pitch)
    }

    fun isReady() = isReady

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        isReady = false
    }
}
