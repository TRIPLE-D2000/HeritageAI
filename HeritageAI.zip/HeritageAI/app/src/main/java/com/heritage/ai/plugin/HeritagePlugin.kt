package com.heritage.ai.plugin

import android.content.Context

/**
 * ────────────────────────────────────────────────────────────
 * HERITAGE AI PLUGIN ARCHITECTURE
 * ────────────────────────────────────────────────────────────
 *
 * Heritage AI's capabilities (flashlight, alarms, app launching, etc.)
 * are implemented as [HeritagePlugin]s registered with the [PluginRegistry].
 * This allows new device capabilities or integrations (e.g. Spotify
 * control, smart-home, third-party APIs) to be added without touching
 * the core chat/voice pipeline.
 *
 * A plugin declares:
 *  - A unique [id] and human-readable [displayName]
 *  - A set of [triggerPhrases] / intents it can handle
 *  - An [execute] function that performs the action and returns a result
 *
 * The [PluginRegistry] is queried by the command-routing layer (see
 * [com.heritage.ai.util.CommandParser]) both for offline pattern matching
 * and for building the list of available commands injected into the
 * LLM system prompt.
 */

/** Result of a plugin execution. */
sealed class PluginResult {
    data class Success(val message: String, val data: Map<String, String> = emptyMap()) : PluginResult()
    data class Failure(val message: String, val recoverable: Boolean = true) : PluginResult()
    data class RequiresPermission(val permission: String, val rationale: String) : PluginResult()
    data class RequiresConfirmation(val prompt: String, val onConfirmAction: String) : PluginResult()
}

/** Context passed to a plugin at execution time. */
data class PluginContext(
    val appContext: Context,
    val rawUserInput: String,
    val parameters: Map<String, String>,
    val conversationId: String
)

/**
 * Base interface every Heritage AI plugin must implement.
 *
 * Plugins are intentionally lightweight and synchronous-friendly;
 * long-running work should be dispatched internally to coroutines
 * and the plugin should suspend until a result is ready.
 */
interface HeritagePlugin {

    /** Stable unique identifier, e.g. "flashlight", "spotify", "calendar". */
    val id: String

    /** Human-readable name shown in Settings → Plugins. */
    val displayName: String

    /** Short description of what this plugin does. */
    val description: String

    /** Whether this plugin requires network access to function. */
    val requiresNetwork: Boolean get() = false

    /** Android permissions this plugin needs (checked before execution). */
    val requiredPermissions: List<String> get() = emptyList()

    /**
     * Phrases/keywords that hint this plugin can handle a given input.
     * Used for fast offline routing before falling back to the LLM.
     */
    fun canHandle(input: String): Boolean

    /** Executes the plugin's action and returns a structured result. */
    suspend fun execute(context: PluginContext): PluginResult

    /**
     * Returns a JSON-schema-like description of this plugin's command,
     * injected into the LLM system prompt so the model knows how to invoke it.
     */
    fun commandSchema(): String
}

/**
 * Central registry of all available plugins.
 *
 * Built-in plugins (flashlight, volume, app launcher, etc.) are registered
 * at app startup via Hilt multibinding (see [PluginModule] in di/).
 * Third-party / user-installed plugins can register themselves at runtime
 * by calling [register].
 */
class PluginRegistry {

    private val plugins = mutableMapOf<String, HeritagePlugin>()

    fun register(plugin: HeritagePlugin) {
        plugins[plugin.id] = plugin
    }

    fun unregister(pluginId: String) {
        plugins.remove(pluginId)
    }

    fun getPlugin(id: String): HeritagePlugin? = plugins[id]

    fun getAllPlugins(): List<HeritagePlugin> = plugins.values.toList()

    /** Finds the first plugin claiming it can handle [input], if any. */
    fun findHandler(input: String): HeritagePlugin? =
        plugins.values.firstOrNull { it.canHandle(input) }

    /** Builds the combined command schema block injected into the system prompt. */
    fun buildSystemPromptSchema(): String =
        plugins.values.joinToString("\n") { it.commandSchema() }
}
