package com.heritage.ai.domain.model

import java.time.Instant

// ──────────────────────────────────────────────────
// CORE DOMAIN MODELS
// ──────────────────────────────────────────────────

/**
 * Represents a single chat message in a conversation.
 */
data class Message(
    val id: String,
    val conversationId: String,
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tokenCount: Int = 0,
    val model: String = "",
    val isError: Boolean = false,
    val metadata: Map<String, String> = emptyMap()
)

enum class MessageRole {
    USER, ASSISTANT, SYSTEM, FUNCTION;

    fun toApiRole(): String = when (this) {
        USER -> "user"
        ASSISTANT -> "assistant"
        SYSTEM -> "system"
        FUNCTION -> "function"
    }
}

/**
 * Represents a conversation session.
 */
data class Conversation(
    val id: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val summary: String = "",
    val isPinned: Boolean = false,
    val tags: List<String> = emptyList()
)

/**
 * Represents a long-term memory fact about the user.
 */
data class Memory(
    val id: String,
    val content: String,
    val category: MemoryCategory,
    val importance: Int = 5,  // 1-10 scale
    val source: String = "",  // Which conversation triggered this
    val createdAt: Long = System.currentTimeMillis(),
    val accessCount: Int = 0,
    val lastAccessed: Long = System.currentTimeMillis()
)

enum class MemoryCategory {
    PERSONAL,        // Name, birthday, preferences
    PROFESSIONAL,    // Work, studies
    INTERESTS,       // Hobbies, topics of interest
    BEHAVIORAL,      // How user prefers to interact
    KNOWLEDGE,       // Facts user knows / mentioned
    RELATIONSHIP,    // People in user's life
    LOCATION,        // Places user frequents
    TEMPORAL         // Time-based patterns
}

/**
 * Represents an automation routine (e.g., Study Mode, Good Morning).
 */
data class Routine(
    val id: String,
    val name: String,
    val description: String,
    val icon: String,
    val actions: List<RoutineAction>,
    val trigger: RoutineTrigger = RoutineTrigger.MANUAL,
    val triggerValue: String = "",
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val lastRunAt: Long = 0L,
    val runCount: Int = 0
)

data class RoutineAction(
    val type: RoutineActionType,
    val parameters: Map<String, String> = emptyMap(),
    val delayMs: Long = 0L,
    val description: String = ""
)

enum class RoutineActionType {
    SET_VOLUME,
    SET_BRIGHTNESS,
    TOGGLE_WIFI,
    TOGGLE_BLUETOOTH,
    TOGGLE_FLASHLIGHT,
    OPEN_APP,
    SEND_MESSAGE,
    SET_ALARM,
    SET_DND,
    SPEAK_TEXT,
    SET_RINGTONE_MODE,
    LAUNCH_SHORTCUT
}

enum class RoutineTrigger {
    MANUAL,
    TIME_BASED,
    LOCATION_BASED,
    VOICE_COMMAND,
    APP_LAUNCH
}

/**
 * Represents the AI assistant state.
 */
data class AssistantState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val isProcessing: Boolean = false,
    val isWakeWordActive: Boolean = false,
    val currentVolume: Float = 0f,  // 0-1 voice amplitude
    val error: String? = null
)

// Note: repository and use-case results across the app use the Kotlin
// standard library's kotlin.Result<T> (Result.success / Result.failure /
// .fold), not a custom wrapper — keeping one Result type avoids the
// confusion of two same-named classes with different shapes.
