package com.heritage.ai.domain.usecase

import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.MessageRole
import com.heritage.ai.domain.repository.ChatRepository
import com.heritage.ai.domain.repository.MemoryRepository
import com.heritage.ai.domain.repository.RoutineRepository
import com.heritage.ai.domain.model.Routine
import com.heritage.ai.util.CommandAction
import com.heritage.ai.util.CommandParser
import com.heritage.ai.util.DeviceControlManager
import com.heritage.ai.util.NetworkConnectivityObserver
import com.heritage.ai.util.RoutineEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * One place for "user said something -> assistant answers".
 *
 * Used by BOTH the chat screen (ChatViewModel) and the triple-volume
 * overlay (QuickVoiceOverlayService), so the two can never drift apart.
 *
 * It saves the user message, tries offline device commands, calls the LLM,
 * runs any device commands in the reply, saves the cleaned answer to history
 * and schedules memory extraction. It does NOT speak or draw anything; the
 * caller decides how to present the reply.
 */
@Singleton
class AskAssistantUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
    private val memoryRepository: MemoryRepository,
    private val prefs: AppPreferences,
    private val deviceControl: DeviceControlManager,
    private val commandParser: CommandParser,
    private val routineRepository: RoutineRepository,
    private val routineEngine: RoutineEngine,
    private val networkObserver: NetworkConnectivityObserver
) {

    sealed class AskResult {
        /** [text] is already cleaned (no command blocks). */
        data class Reply(val text: String) : AskResult()
        data class Failure(val message: String?) : AskResult()
    }

    // Survives the overlay service / ViewModel being destroyed, so background
    // memory extraction is not cancelled when the overlay closes.
    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Returns the current conversation id, creating one if none exists yet. */
    suspend fun ensureConversationId(): String {
        val stored = prefs.currentConversationId.first()
        if (stored.isNotBlank()) return stored
        val id = chatRepository.createConversation()
        prefs.setCurrentConversationId(id)
        return id
    }

    suspend fun ask(conversationId: String, text: String): AskResult {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return AskResult.Failure(null)

        chatRepository.saveMessage(
            Message(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                role = MessageRole.USER,
                content = trimmed,
                timestamp = System.currentTimeMillis()
            )
        )

        // Offline-first: simple device commands need no network and no LLM
        val offline = commandParser.tryParseOfflineCommand(trimmed)
        if (offline != null && offline.isOfflineCapable && offline.command != null) {
            deviceControl.executeCommand(offline.command)
            saveAssistant(conversationId, offline.responseText, model = "offline")
            return AskResult.Reply(offline.responseText)
        }

        // Everything else needs the LLM: fail fast and friendly when offline
        if (!networkObserver.isCurrentlyOnline()) {
            val notice = "I'm offline right now, so I can only help with basic device " +
                    "commands like the flashlight, volume, Wi-Fi, alarms, or opening apps. " +
                    "Reconnect for full conversations."
            saveAssistant(conversationId, notice)
            return AskResult.Reply(notice)
        }

        val memories = if (prefs.longTermMemoryEnabled.first()) {
            memoryRepository.getTopMemories(8)
        } else {
            emptyList()
        }

        // Auto-title the conversation on its first message
        val isFirstMessage = chatRepository.getMessages(conversationId).first().size <= 1
        if (isFirstMessage && trimmed.length > 10) {
            val title = trimmed.take(50).let { if (trimmed.length > 50) "$it…" else it }
            chatRepository.updateConversationTitle(conversationId, title)
        }

        return chatRepository.sendToLLM(
            conversationId = conversationId,
            userMessage = trimmed,
            contextMemories = memories
        ).fold(
            onSuccess = { assistantMessage ->
                // Run device commands first, then strip the raw JSON blocks
                runCommands(assistantMessage.content)

                // Never persist blank content: an empty history entry makes the
                // LLM API reject the next request with HTTP 400.
                val clean = stripCommandBlocks(assistantMessage.content).ifBlank { "Done." }
                chatRepository.saveMessage(assistantMessage.copy(content = clean))

                launchMemoryExtraction(conversationId)
                AskResult.Reply(clean)
            },
            onFailure = { error -> AskResult.Failure(error.message) }
        )
    }

    private suspend fun saveAssistant(conversationId: String, content: String, model: String = "") {
        chatRepository.saveMessage(
            Message(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                role = MessageRole.ASSISTANT,
                content = content,
                timestamp = System.currentTimeMillis(),
                model = model
            )
        )
    }

    private suspend fun runCommands(content: String) {
        commandParser.extractCommands(content).forEach { command ->
            if (command.action == CommandAction.RUN_ROUTINE) {
                val name = command.params["name"] ?: return@forEach
                val routine = routineRepository.getRoutineById(name) ?: findRoutineByName(name)
                routine?.let { routineEngine.execute(it) }
            } else {
                deviceControl.executeCommand(command)
            }
        }
    }

    private suspend fun findRoutineByName(name: String): Routine? {
        return try {
            routineRepository.getAllRoutines().first()
                .firstOrNull { it.name.equals(name, ignoreCase = true) }
        } catch (_: Exception) {
            null
        }
    }

    private fun launchMemoryExtraction(conversationId: String) {
        backgroundScope.launch {
            delay(3000) // keep the UI snappy first
            runCatching {
                val extracted = memoryRepository.extractMemoriesFromConversation(conversationId)
                if (extracted > 0) chatRepository.generateSummary(conversationId)
            }
        }
    }

    companion object {
        /** Removes ```command {...}``` / ```json blocks (kept in sync with CommandParser). */
        fun stripCommandBlocks(content: String): String {
            return content
                .replace(Regex("```(?:command|cmd|heritage|json)[\\s\\S]*?```", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\n{3,}"), "\n\n")
                .trim()
        }

        /** Markdown-free text for showing in the overlay and reading aloud. */
        fun toPlainText(content: String): String {
            return content
                .replace(Regex("```[^`]*```", RegexOption.DOT_MATCHES_ALL), "")
                .replace(Regex("\\*\\*([^*]*)\\*\\*"), "$1")
                .replace(Regex("\\*([^*]*)\\*"), "$1")
                .replace(Regex("#+ "), "")
                .trim()
        }
    }
}
