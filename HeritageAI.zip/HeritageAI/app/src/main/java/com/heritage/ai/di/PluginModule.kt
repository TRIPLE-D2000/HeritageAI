package com.heritage.ai.di

import com.heritage.ai.plugin.PluginRegistry
import com.heritage.ai.plugin.plugins.AlarmPlugin
import com.heritage.ai.plugin.plugins.AppLauncherPlugin
import com.heritage.ai.plugin.plugins.ConnectivityPlugin
import com.heritage.ai.plugin.plugins.FlashlightPlugin
import com.heritage.ai.plugin.plugins.VolumePlugin
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Wires the [PluginRegistry] singleton and registers all built-in plugins
 * at app startup. Third-party plugins can call [PluginRegistry.register]
 * at runtime after being discovered (e.g. via a plugin-loading mechanism).
 */
@Module
@InstallIn(SingletonComponent::class)
object PluginModule {

    @Provides
    @Singleton
    fun providePluginRegistry(
        flashlight: FlashlightPlugin,
        appLauncher: AppLauncherPlugin,
        volume: VolumePlugin,
        alarm: AlarmPlugin,
        connectivity: ConnectivityPlugin
    ): PluginRegistry {
        return PluginRegistry().apply {
            register(flashlight)
            register(appLauncher)
            register(volume)
            register(alarm)
            register(connectivity)
        }
    }
}
