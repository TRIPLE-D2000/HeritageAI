package com.heritage.ai.presentation.chat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.domain.model.AssistantState
import com.heritage.ai.domain.model.Conversation
import com.heritage.ai.domain.model.Memory
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.MessageRole
import com.heritage.ai.domain.repository.ChatRepository
import com.heritage.ai.domain.repository.MemoryRepository
import com.heritage.ai.util.CommandParser
import com.heritage.ai.util.DeviceControlManager
import com.heritage.ai.util.TextToSpeechManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

// ──────────────────────────────────────────────────
// UI STATE
// ──────────────────────────────────────────────────

data class ChatUiState(
    val messages: List<Message> = emptyList(),
    val currentConversationId: String = "",
    val assistantState: AssistantState = AssistantState(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val inputText: String = "",
    val showVoiceOverlay: Boolean = false,
    val voiceAmplitude: Float = 0f,
    val conversations: List<Conversation> = emptyList(),
    val userName: String = "",
    val isOnline: Boolean = true
)

sealed class ChatEvent {
    object StartListening : ChatEvent()
    object StopListening : ChatEvent()
    data class SendTextMessage(val text: String) : ChatEvent()
    data class VoiceResult(val text: String) : ChatEvent()
    data class UpdateInput(val text: String) : ChatEvent()
    object NewConversation : ChatEvent()
    data class SwitchConversation(val id: String) : ChatEvent()
    data class DeleteConversation(val id: String) : ChatEvent()
    object DismissError : ChatEvent()
    data class VoiceAmplitudeUpdate(val amplitude: Float) : ChatEvent()
}

// ──────────────────────────────────────────────────
// VIEWMODEL
// ──────────────────────────────────────────────────

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val memoryRepository: MemoryRepository,
    private val prefs: AppPreferences,
    private val deviceControl: DeviceControlManager,
    private val tts: TextToSpeechManager,
    private val commandParser: CommandParser,
    private val networkObserver: com.heritage.ai.util.NetworkConnectivityObserver,
    private val voiceOrchestrator: com.heritage.ai.util.VoiceOrchestrator,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    /** Live partial transcript from the voice recogniser — drives the animated preview text. */
    val partialVoiceText: StateFlow<String> = voiceOrchestrator.partialText

    private var messageObserverJob: Job? = null
    private var currentConversationId: String = ""

    init {
        observeConversations()
        initCurrentConversation()
        observeUserName()
        observeConnectivity()
        observeVoice()
        registerQuickVoiceReceiver()
    }

    private fun observeConnectivity() {
        viewModelScope.launch {
            networkObserver.isOnline.collect { online ->
                _uiState.update { it.copy(isOnline = online) }
            }
        }
    }

    /**
     * Wires the [VoiceOrchestrator]'s flows into UiState so that:
     * - Recognised text is automatically sent as a message
     * - Partial transcript and amplitude animate the voice UI in real time
     * - Service-level errors surface in the chat error banner
     */
    private fun observeVoice() {
        // Final recognised text → send as message automatically
        viewModelScope.launch {
            voiceOrchestrator.recognizedText.collect { text ->
                if (text.isNotBlank()) {
                    _uiState.update { it.copy(showVoiceOverlay = false) }
                    voiceOrchestrator.stopListening()
                    sendMessage(text)
                }
            }
        }
        // Partial transcript → live preview inside the voice overlay
        viewModelScope.launch {
            voiceOrchestrator.partialText.collect { partial ->
                _uiState.update { it.copy(
                    assistantState = it.assistantState.copy()
                    // partial text is read directly from orchestrator in the UI
                ) }
            }
        }
        // Microphone amplitude → orb pulse animation
        viewModelScope.launch {
            voiceOrchestrator.amplitude.collect { amp ->
                _uiState.update { it.copy(
                    voiceAmplitude = amp,
                    assistantState = it.assistantState.copy(currentVolume = amp)
                ) }
            }
        }
        // Service-level errors — show in error banner AND auto-dismiss after 5 seconds
        viewModelScope.launch {
            voiceOrchestrator.error.collect { msg ->
                _uiState.update { it.copy(
                    error = msg,
                    showVoiceOverlay = false,
                    assistantState = it.assistantState.copy(isListening = false)
                ) }
                // Auto-dismiss after 5 seconds so the user can read it
                kotlinx.coroutines.delay(5000)
                _uiState.update { if (it.error == msg) it.copy(error = null) else it }
            }
        }
        // Sync isListening flag
        viewModelScope.launch {
            voiceOrchestrator.isListening.collect { listening ->
                _uiState.update { it.copy(
                    assistantState = it.assistantState.copy(isListening = listening)
                ) }
            }
        }
    }

    private fun observeConversations() {
        viewModelScope.launch {
            chatRepository.getAllConversations().collect { convs ->
                _uiState.update { it.copy(conversations = convs) }
            }
        }
    }

    private fun observeUserName() {
        viewModelScope.launch {
            prefs.userName.collect { name ->
                _uiState.update { it.copy(userName = name) }
            }
        }
    }

    private fun initCurrentConversation() {
        viewModelScope.launch {
            val storedId = prefs.currentConversationId.first()
            if (storedId.isNotBlank()) {
                switchToConversation(storedId)
            } else {
                createNewConversation()
            }
        }
    }

    fun onEvent(event: ChatEvent) {
        when (event) {
            is ChatEvent.SendTextMessage -> sendMessage(event.text)
            is ChatEvent.VoiceResult -> sendMessage(event.text)
            is ChatEvent.UpdateInput -> _uiState.update { it.copy(inputText = event.text) }
            is ChatEvent.NewConversation -> viewModelScope.launch { createNewConversation() }
            is ChatEvent.SwitchConversation -> viewModelScope.launch { switchToConversation(event.id) }
            is ChatEvent.DeleteConversation -> viewModelScope.launch { deleteConversation(event.id) }
            is ChatEvent.DismissError -> _uiState.update { it.copy(error = null) }
            is ChatEvent.StartListening -> {
                _uiState.update { it.copy(
                    showVoiceOverlay = true,
                    assistantState = it.assistantState.copy(isListening = true)
                ) }
                voiceOrchestrator.startListening()
            }
            is ChatEvent.StopListening -> {
                voiceOrchestrator.stopListening()
                _uiState.update { it.copy(
                    showVoiceOverlay = false,
                    assistantState = it.assistantState.copy(isListening = false, currentVolume = 0f),
                    voiceAmplitude = 0f
                ) }
            }
            is ChatEvent.VoiceAmplitudeUpdate -> _uiState.update {
                it.copy(voiceAmplitude = event.amplitude,
                    assistantState = it.assistantState.copy(currentVolume = event.amplitude))
            }
        }
    }

    private fun sendMessage(text: String) {
        if (text.isBlank()) return
        val trimmedText = text.trim()

        viewModelScope.launch {
            val convId = currentConversationId.takeIf { it.isNotBlank() }
                ?: createNewConversation().also { currentConversationId = it }

            // Add user message to local DB immediately
            val userMessage = Message(
                id = UUID.randomUUID().toString(),
                conversationId = convId,
                role = MessageRole.USER,
                content = trimmedText,
                timestamp = System.currentTimeMillis()
            )
            chatRepository.saveMessage(userMessage)
            _uiState.update { it.copy(inputText = "", error = null) }

            // ── OFFLINE-FIRST COMMAND ROUTING ──
            // Simple device commands ("turn on flashlight", "set volume to 50")
            // are pattern-matched locally and executed instantly — no network
            // round-trip, no LLM token cost, and they work with zero connectivity.
            val offlineCommand = commandParser.tryParseOfflineCommand(trimmedText)
            if (offlineCommand != null) {
                val execResult = deviceControl.executeCommand(offlineCommand.command!!)
                val assistantMessage = Message(
                    id = UUID.randomUUID().toString(),
                    conversationId = convId,
                    role = MessageRole.ASSISTANT,
                    content = offlineCommand.responseText,
                    timestamp = System.currentTimeMillis(),
                    model = "offline"
                )
                chatRepository.saveMessage(assistantMessage)
                speakResponse(assistantMessage.content)
                return@launch
            }

            // ── NO CONNECTIVITY — graceful degradation ──
            // Anything that isn't a recognized offline command requires the
            // LLM. Fail fast with a clear, friendly message instead of
            // letting the request hang and surface a raw network exception.
            if (!networkObserver.isCurrentlyOnline()) {
                val offlineNotice = Message(
                    id = UUID.randomUUID().toString(),
                    conversationId = convId,
                    role = MessageRole.ASSISTANT,
                    content = "I'm offline right now, so I can only help with basic device " +
                            "commands like the flashlight, volume, Wi-Fi, alarms, or opening apps. " +
                            "Reconnect for full conversations.",
                    timestamp = System.currentTimeMillis(),
                    isError = false
                )
                chatRepository.saveMessage(offlineNotice)
                speakResponse(offlineNotice.content)
                return@launch
            }

            _uiState.update { it.copy(isLoading = true) }

            // Fetch relevant memories for context injection
            val memories = if (prefs.longTermMemoryEnabled.first()) {
                memoryRepository.getTopMemories(8)
            } else {
                emptyList()
            }

            // Auto-title the conversation if it's the first message
            val messages = _uiState.value.messages
            if (messages.size <= 1 && trimmedText.length > 10) {
                val title = trimmedText.take(50).let {
                    if (trimmedText.length > 50) "$it…" else it
                }
                chatRepository.updateConversationTitle(convId, title)
            }

            // Call LLM
            chatRepository.sendToLLM(
                conversationId = convId,
                userMessage = trimmedText,
                contextMemories = memories
            ).fold(
                onSuccess = { assistantMessage ->
                    // FIX #4: Execute commands first, then strip the raw JSON
                    // blocks so users never see the ```command {...}``` in chat
                    handleAssistantResponse(assistantMessage.content)

                    val cleanContent = stripCommandBlocks(assistantMessage.content)
                    val cleanMessage = assistantMessage.copy(content = cleanContent)

                    chatRepository.saveMessage(cleanMessage)
                    _uiState.update { it.copy(isLoading = false) }

                    // FIX #5: Speak cleaned content only — no code blocks read aloud
                    speakResponse(cleanContent)

                    // Extract memories in the background
                    launchMemoryExtraction(convId)
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(isLoading = false, error = error.message)
                    }
                }
            )
        }
    }

    private suspend fun handleAssistantResponse(content: String) {
        val commands = commandParser.extractCommands(content)
        commands.forEach { command ->
            if (command.action == com.heritage.ai.util.CommandAction.RUN_ROUTINE) {
                val name = command.params["name"] ?: return@forEach
                // Look up routine by ID first, then by display name
                val routine = routineRepository.getRoutineById(name)
                    ?: findRoutineByName(name)
                routine?.let { routineEngine.execute(it) }
            } else {
                deviceControl.executeCommand(command)
            }
        }
    }

    private suspend fun findRoutineByName(name: String): com.heritage.ai.domain.model.Routine? {
        return kotlinx.coroutines.flow.first(routineRepository.getAllRoutines())
            .firstOrNull { it.name.equals(name, ignoreCase = true) }
    }

    private fun speakResponse(content: String) {
        viewModelScope.launch {
            val ttsEnabled = prefs.ttsEnabled.first()
            if (ttsEnabled) {
                // Strip markdown and command blocks before speaking
                val cleanText = content
                    .replace(Regex("```[^`]*```", RegexOption.DOT_MATCHES_ALL), "")
                    .replace(Regex("\\*\\*([^*]*)\\*\\*"), "$1")
                    .replace(Regex("\\*([^*]*)\\*"), "$1")
                    .replace(Regex("#+ "), "")
                    .trim()
                _uiState.update { it.copy(assistantState = it.assistantState.copy(isSpeaking = true)) }
                tts.speak(cleanText)
                _uiState.update { it.copy(assistantState = it.assistantState.copy(isSpeaking = false)) }
            }
        }
    }

    private fun launchMemoryExtraction(conversationId: String) {
        viewModelScope.launch {
            delay(3000) // Wait so UI stays snappy
            val extracted = memoryRepository.extractMemoriesFromConversation(conversationId)
            if (extracted > 0) {
                // Update conversation summary for cross-chat context
                chatRepository.generateSummary(conversationId)
            }
        }
    }

    private suspend fun createNewConversation(): String {
        val id = chatRepository.createConversation()
        switchToConversation(id)
        prefs.setCurrentConversationId(id)
        return id
    }

    private suspend fun switchToConversation(id: String) {
        currentConversationId = id
        prefs.setCurrentConversationId(id)

        messageObserverJob?.cancel()
        messageObserverJob = viewModelScope.launch {
            chatRepository.getMessages(id).collect { messages ->
                _uiState.update { it.copy(messages = messages, currentConversationId = id) }
            }
        }
    }

    private suspend fun deleteConversation(id: String) {
        chatRepository.deleteConversation(id)
        if (id == currentConversationId) {
            val remaining = _uiState.value.conversations.filter { it.id != id }
            if (remaining.isNotEmpty()) {
                switchToConversation(remaining.first().id)
            } else {
                createNewConversation()
            }
        }
    }

    /**
     * Removes ```command {...}``` blocks from LLM output.
     * Commands are executed first, then stripped so the user
     * only sees the natural language part of the reply.
     */
    private fun stripCommandBlocks(content: String): String {
        return content
            .replace(Regex("```(?:command|cmd|heritage)[\\s\\S]*?```", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\n{3,}"), "\n\n") // Collapse extra blank lines
            .trim()
    }

    private var quickVoiceReceiver: BroadcastReceiver? = null

    private fun registerQuickVoiceReceiver() {
        quickVoiceReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: android.content.Context?, intent: Intent?) {
                val query = intent?.getStringExtra("command_text") ?: return
                if (query.isNotBlank()) {
                    // Auto-send the voice query as if the user typed it
                    sendMessage(query)
                }
            }
        }
        val filter = IntentFilter("com.heritage.ai.QUICK_VOICE_COMMAND")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(quickVoiceReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(quickVoiceReceiver, filter)
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts.shutdown()
        runCatching { quickVoiceReceiver?.let { context.unregisterReceiver(it) } }
    }
}
