package com.heritage.ai.presentation.chat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.domain.model.AssistantState
import com.heritage.ai.domain.model.Conversation
import com.heritage.ai.domain.model.Memory
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.MessageRole
import com.heritage.ai.domain.repository.ChatRepository
import com.heritage.ai.domain.repository.MemoryRepository
import com.heritage.ai.domain.usecase.AskAssistantUseCase
import com.heritage.ai.util.CommandParser
import com.heritage.ai.util.DeviceControlManager
import com.heritage.ai.util.TextToSpeechManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

// ──────────────────────────────────────────────────
// UI STATE
// ──────────────────────────────────────────────────

data class ChatUiState(
    val messages: List<Message> = emptyList(),
    val currentConversationId: String = "",
    val assistantState: AssistantState = AssistantState(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val inputText: String = "",
    val showVoiceOverlay: Boolean = false,
    val voiceAmplitude: Float = 0f,
    val conversations: List<Conversation> = emptyList(),
    val userName: String = "",
    val isOnline: Boolean = true,
    /** A photo (shrunk JPEG) waiting to be sent with the next message. */
    val pendingImage: ByteArray? = null
)

sealed class ChatEvent {
    object StartListening : ChatEvent()
    object StopListening : ChatEvent()
    data class SendTextMessage(val text: String) : ChatEvent()
    data class VoiceResult(val text: String) : ChatEvent()
    data class UpdateInput(val text: String) : ChatEvent()
    object NewConversation : ChatEvent()
    data class SwitchConversation(val id: String) : ChatEvent()
    data class DeleteConversation(val id: String) : ChatEvent()
    object DismissError : ChatEvent()
    data class AttachImage(val uri: android.net.Uri) : ChatEvent()
    object RemoveImage : ChatEvent()
    data class ReportReply(val reply: String, val reason: String) : ChatEvent()
    data class VoiceAmplitudeUpdate(val amplitude: Float) : ChatEvent()
}

// ──────────────────────────────────────────────────
// VIEWMODEL
// ──────────────────────────────────────────────────

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val memoryRepository: MemoryRepository,
    private val prefs: AppPreferences,
    private val deviceControl: DeviceControlManager,
    private val tts: TextToSpeechManager,
    private val commandParser: CommandParser,
    private val networkObserver: com.heritage.ai.util.NetworkConnectivityObserver,
    private val voiceOrchestrator: com.heritage.ai.util.VoiceOrchestrator,
    private val routineRepository: com.heritage.ai.domain.repository.RoutineRepository,
    private val routineEngine: com.heritage.ai.util.RoutineEngine,
    private val askAssistant: AskAssistantUseCase,
    private val llmApi: com.heritage.ai.data.remote.api.LLMApi,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    /** Live partial transcript from the voice recogniser — drives the animated preview text. */
    val partialVoiceText: StateFlow<String> = voiceOrchestrator.partialText

    private var messageObserverJob: Job? = null
    private var currentConversationId: String = ""

    init {
        observeConversations()
        initCurrentConversation()
        observeUserName()
        observeTtsSettings()
        observeConnectivity()
        observeVoice()
        registerQuickVoiceReceiver()
    }

    private fun observeConnectivity() {
        viewModelScope.launch {
            networkObserver.isOnline.collect { online ->
                _uiState.update { it.copy(isOnline = online) }
            }
        }
    }

    /**
     * Wires the [VoiceOrchestrator]'s flows into UiState so that:
     * - Recognised text is automatically sent as a message
     * - Partial transcript and amplitude animate the voice UI in real time
     * - Service-level errors surface in the chat error banner
     */
    private fun observeVoice() {
        // Final recognised text → send as message automatically
        viewModelScope.launch {
            voiceOrchestrator.recognizedText.collect { text ->
                if (text.isNotBlank()) {
                    _uiState.update { it.copy(showVoiceOverlay = false) }
                    voiceOrchestrator.stopListening()
                    sendMessage(text)
                }
            }
        }
        // Partial transcript → live preview inside the voice overlay
        viewModelScope.launch {
            voiceOrchestrator.partialText.collect { partial ->
                _uiState.update { it.copy(
                    assistantState = it.assistantState.copy()
                    // partial text is read directly from orchestrator in the UI
                ) }
            }
        }
        // Microphone amplitude → orb pulse animation
        viewModelScope.launch {
            voiceOrchestrator.amplitude.collect { amp ->
                _uiState.update { it.copy(
                    voiceAmplitude = amp,
                    assistantState = it.assistantState.copy(currentVolume = amp)
                ) }
            }
        }
        // Service-level errors — show in error banner AND auto-dismiss after 5 seconds
        viewModelScope.launch {
            voiceOrchestrator.error.collect { msg ->
                _uiState.update { it.copy(
                    error = msg,
                    showVoiceOverlay = false,
                    assistantState = it.assistantState.copy(isListening = false)
                ) }
                // Auto-dismiss after 5 seconds so the user can read it
                kotlinx.coroutines.delay(5000)
                _uiState.update { if (it.error == msg) it.copy(error = null) else it }
            }
        }
        // Sync isListening flag
        viewModelScope.launch {
            voiceOrchestrator.isListening.collect { listening ->
                _uiState.update { it.copy(
                    assistantState = it.assistantState.copy(isListening = listening)
                ) }
            }
        }
    }

    private fun observeConversations() {
        viewModelScope.launch {
            chatRepository.getAllConversations().collect { convs ->
                _uiState.update { it.copy(conversations = convs) }
            }
        }
    }

    private fun observeUserName() {
        viewModelScope.launch {
            prefs.userName.collect { name ->
                _uiState.update { it.copy(userName = name) }
            }
        }
    }

    /**
     * BUGFIX: speed/pitch were saved to DataStore from the Settings sliders but
     * nothing ever read them back and applied them to the live TTS engine, so
     * the sliders had no real effect. Wired here the same way userName is kept
     * in sync, plus the new voice-selection preference.
     */
    private fun observeTtsSettings() {
        viewModelScope.launch {
            prefs.ttsSpeed.collect { speed -> tts.setSpeed(speed) }
        }
        viewModelScope.launch {
            prefs.ttsPitch.collect { pitch -> tts.setPitch(pitch) }
        }
        viewModelScope.launch {
            prefs.ttsVoiceName.collect { voice -> if (voice.isNotBlank()) tts.setVoice(voice) }
        }
    }

    private fun initCurrentConversation() {
        viewModelScope.launch {
            val storedId = prefs.currentConversationId.first()
            if (storedId.isNotBlank()) {
                switchToConversation(storedId)
            } else {
                createNewConversation()
            }
        }
    }

    fun onEvent(event: ChatEvent) {
        when (event) {
            is ChatEvent.SendTextMessage -> sendMessage(event.text)
            is ChatEvent.VoiceResult -> sendMessage(event.text)
            is ChatEvent.UpdateInput -> _uiState.update { it.copy(inputText = event.text) }
            is ChatEvent.NewConversation -> viewModelScope.launch { createNewConversation() }
            is ChatEvent.SwitchConversation -> viewModelScope.launch { switchToConversation(event.id) }
            is ChatEvent.DeleteConversation -> viewModelScope.launch { deleteConversation(event.id) }
            is ChatEvent.DismissError -> _uiState.update { it.copy(error = null) }
            is ChatEvent.AttachImage -> attachImage(event.uri)
            is ChatEvent.RemoveImage -> _uiState.update { it.copy(pendingImage = null) }
            is ChatEvent.ReportReply -> reportReply(event.reply, event.reason)
            is ChatEvent.StartListening -> {
                // Cut off any speech so the mic doesn't pick up the assistant's own voice
                tts.stop()
                _uiState.update { it.copy(
                    showVoiceOverlay = true,
                    assistantState = it.assistantState.copy(isListening = true)
                ) }
                voiceOrchestrator.startListening()
            }
            is ChatEvent.StopListening -> {
                voiceOrchestrator.stopListening()
                _uiState.update { it.copy(
                    showVoiceOverlay = false,
                    assistantState = it.assistantState.copy(isListening = false, currentVolume = 0f),
                    voiceAmplitude = 0f
                ) }
            }
            is ChatEvent.VoiceAmplitudeUpdate -> _uiState.update {
                it.copy(voiceAmplitude = event.amplitude,
                    assistantState = it.assistantState.copy(currentVolume = event.amplitude))
            }
        }
    }

    /** Sends a user-flagged AI reply (and the reason) to the developer for review. */
    private fun reportReply(reply: String, reason: String) {
        viewModelScope.launch {
            val sent = runCatching {
                llmApi.reportReply(
                    com.heritage.ai.data.remote.model.ReportRequest(
                        reason = reason,
                        reply = reply.take(1500),
                        appVersion = com.heritage.ai.BuildConfig.APP_VERSION
                    )
                ).isSuccessful
            }.getOrDefault(false)
            android.widget.Toast.makeText(
                context,
                if (sent) "Thanks, your report was sent." else "Couldn't send the report. Please try again later.",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }

    /** Shrinks the chosen photo off the main thread and holds it until the user sends. */
    private fun attachImage(uri: android.net.Uri) {
        viewModelScope.launch {
            val bytes = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.heritage.ai.util.ImageStore.shrinkToJpeg(context, uri)
            }
            if (bytes == null) {
                _uiState.update { it.copy(error = "Couldn't read that photo. Please try another one.") }
            } else {
                _uiState.update { it.copy(pendingImage = bytes, error = null) }
            }
        }
    }

    private fun sendMessage(text: String) {
        val image = _uiState.value.pendingImage
        if (text.isBlank() && image == null) return
        val trimmedText = text.trim().ifBlank { "Describe this image and read any text in it." }

        viewModelScope.launch {
            val convId = currentConversationId.takeIf { it.isNotBlank() }
                ?: createNewConversation().also { currentConversationId = it }

            _uiState.update { it.copy(inputText = "", error = null, isLoading = true, pendingImage = null) }

            // All the chat logic (offline commands, LLM call, device commands,
            // history, memory) lives in AskAssistantUseCase, shared with the
            // triple-volume overlay.
            when (val result = askAssistant.ask(convId, trimmedText, image)) {
                is AskAssistantUseCase.AskResult.Reply -> {
                    _uiState.update { it.copy(isLoading = false) }
                    speakResponse(result.text)
                }
                is AskAssistantUseCase.AskResult.Failure -> {
                    _uiState.update { it.copy(isLoading = false, error = result.message) }
                }
            }
        }
    }

    private fun speakResponse(content: String) {
        viewModelScope.launch {
            val ttsEnabled = prefs.ttsEnabled.first()
            if (ttsEnabled) {
                // Strip markdown and command blocks before speaking
                val cleanText = content
                    .replace(Regex("```[^`]*```", RegexOption.DOT_MATCHES_ALL), "")
                    .replace(Regex("\\*\\*([^*]*)\\*\\*"), "$1")
                    .replace(Regex("\\*([^*]*)\\*"), "$1")
                    .replace(Regex("#+ "), "")
                    .trim()
                _uiState.update { it.copy(assistantState = it.assistantState.copy(isSpeaking = true)) }
                tts.speak(cleanText)
                _uiState.update { it.copy(assistantState = it.assistantState.copy(isSpeaking = false)) }
            }
        }
    }

    private suspend fun createNewConversation(): String {
        val id = chatRepository.createConversation()
        switchToConversation(id)
        prefs.setCurrentConversationId(id)
        return id
    }

    private suspend fun switchToConversation(id: String) {
        currentConversationId = id
        prefs.setCurrentConversationId(id)

        messageObserverJob?.cancel()
        messageObserverJob = viewModelScope.launch {
            chatRepository.getMessages(id).collect { messages ->
                _uiState.update { it.copy(messages = messages, currentConversationId = id) }
            }
        }
    }

    private suspend fun deleteConversation(id: String) {
        // Photos shared in this chat are stored separately: remove them too
        val photos = runCatching {
            chatRepository.getMessages(id).first().mapNotNull { it.metadata["image"] }
        }.getOrDefault(emptyList())
        chatRepository.deleteConversation(id)
        com.heritage.ai.util.ImageStore.delete(context, photos)
        if (id == currentConversationId) {
            val remaining = _uiState.value.conversations.filter { it.id != id }
            if (remaining.isNotEmpty()) {
                switchToConversation(remaining.first().id)
            } else {
                createNewConversation()
            }
        }
    }

    private var quickVoiceReceiver: BroadcastReceiver? = null

    private fun registerQuickVoiceReceiver() {
        quickVoiceReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: android.content.Context?, intent: Intent?) {
                val query = intent?.getStringExtra("command_text") ?: return
                if (query.isNotBlank()) {
                    // Auto-send the voice query as if the user typed it
                    sendMessage(query)
                }
            }
        }
        val filter = IntentFilter("com.heritage.ai.QUICK_VOICE_COMMAND")
        // NOT_EXPORTED on every Android version: before Android 13 the plain call is
        // exported, letting any app inject commands into the assistant.
        androidx.core.content.ContextCompat.registerReceiver(
            context, quickVoiceReceiver, filter, androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onCleared() {
        super.onCleared()
        tts.shutdown()
        runCatching { quickVoiceReceiver?.let { context.unregisterReceiver(it) } }
    }
}
