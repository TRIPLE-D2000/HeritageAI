package com.heritage.ai.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ────────────────────────────────────────────────────────────
 * RoutineScheduler
 * ────────────────────────────────────────────────────────────
 * Arms/cancels the exact alarm that fires a time-based routine
 * (e.g. "Good Morning" at 7:00 AM) even when the app isn't open.
 *
 * Uses AlarmManager.setExactAndAllowWhileIdle rather than WorkManager's
 * PeriodicWorkRequest because a routine with a specific clock time is a
 * user-visible commitment ("this runs at 7am") — WorkManager's periodic
 * work is deliberately inexact and battery-friendly, and the OS can (and
 * does) delay it by anywhere from minutes to hours to batch background
 * work, especially under Doze. An exact alarm is the same mechanism a
 * normal alarm clock uses, so it behaves the way people actually expect
 * a scheduled routine to behave.
 *
 * Exact alarms are one-shot, not recurring — [RoutineAlarmReceiver]
 * re-arms the next day's alarm each time one fires, and [BootReceiver]
 * re-arms everything after a reboot or app update (both events clear
 * all previously-set alarms).
 */
@Singleton
class RoutineScheduler @Inject constructor() {

    /**
     * Arms (or re-arms) the next firing of [routineId] at [timeString]
     * ("HH:mm", 24-hour). If that time has already passed today, schedules
     * for tomorrow instead.
     *
     * Falls back to an inexact alarm on devices/preferences where exact
     * alarms aren't permitted (Android 12+ requires the user to grant
     * this separately) — late by a few minutes beats not running at all.
     */
    fun schedule(context: Context, routineId: String, timeString: String) {
        val (hour, minute) = parseTime(timeString) ?: return
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pendingIntent = buildPendingIntent(context, routineId)

        val triggerAt = nextOccurrence(hour, minute)

        val canScheduleExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            alarmManager.canScheduleExactAlarms()

        if (canScheduleExact) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        } else {
            // No exact-alarm permission granted — an inexact alarm still
            // fires (just with OS-discretion timing) rather than never.
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    /** Cancels any pending alarm for [routineId] (e.g. disabled, or schedule removed). */
    fun cancel(context: Context, routineId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        alarmManager.cancel(buildPendingIntent(context, routineId))
    }

    private fun buildPendingIntent(context: Context, routineId: String): PendingIntent {
        val intent = Intent(context, RoutineAlarmReceiver::class.java).apply {
            action = ACTION_ROUTINE_ALARM
            putExtra(RoutineAlarmReceiver.EXTRA_ROUTINE_ID, routineId)
        }
        // Stable per-routine request code so re-scheduling replaces the
        // existing alarm for this routine rather than stacking a new one.
        return PendingIntent.getBroadcast(
            context,
            routineId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Next occurrence of [hour]:[minute] — today if still upcoming, else tomorrow. */
    private fun nextOccurrence(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (target.timeInMillis <= now.timeInMillis) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }

    private fun parseTime(timeString: String): Pair<Int, Int>? {
        val parts = timeString.split(":")
        if (parts.size != 2) return null
        val hour = parts[0].trim().toIntOrNull() ?: return null
        val minute = parts[1].trim().toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        return hour to minute
    }

    companion object {
        const val ACTION_ROUTINE_ALARM = "com.heritage.ai.ACTION_ROUTINE_ALARM"
    }
}
