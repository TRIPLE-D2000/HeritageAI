package com.heritage.ai.util

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import javax.inject.Inject
import javax.inject.Singleton

// ──────────────────────────────────────────────────
// COMMAND MODEL
// ──────────────────────────────────────────────────

enum class CommandAction {
    TOGGLE_FLASHLIGHT,
    SET_VOLUME,
    SET_BRIGHTNESS,
    TOGGLE_WIFI,
    TOGGLE_BLUETOOTH,
    TOGGLE_HOTSPOT,
    OPEN_APP,
    SET_ALARM,
    SET_DND,
    TAKE_SCREENSHOT,
    SEND_SMS,
    READ_NOTIFICATIONS,
    RUN_ROUTINE,
    UNKNOWN;

    companion object {
        fun fromString(s: String): CommandAction = runCatching {
            valueOf(s.uppercase().replace(" ", "_").replace("-", "_"))
        }.getOrDefault(UNKNOWN)
    }
}

data class DeviceCommand(
    val action: CommandAction,
    val params: Map<String, String> = emptyMap(),
    val rawAction: String = ""
)

// ──────────────────────────────────────────────────
// PARSER
// ──────────────────────────────────────────────────

/**
 * Extracts structured [DeviceCommand]s from LLM response text.
 *
 * The LLM wraps commands in fenced code blocks:
 * ```command
 * { "action": "SET_VOLUME", "params": { "level": "50" } }
 * ```
 * This parser extracts those blocks and maps them to typed commands.
 * Gracefully handles malformed JSON by returning an empty list.
 */
@Singleton
class CommandParser @Inject constructor() {

    private val gson = Gson()

    // Regex: ```command ... ``` (case-insensitive, dot matches newline)
    // Also accepts ```json — the model doesn't reliably stick to the
    // ```command convention documented in the system prompt and often
    // defaults to ```json instead (a very common habit for JSON-generating
    // models). Without this, those replies were silently unexecuted AND
    // left as raw, unstripped text in the chat (e.g. alarms and DND
    // commands that appeared to just "not work").
    private val commandBlockRegex = Regex(
        "```(?:command|cmd|heritage|json)\\s*([\\s\\S]*?)```",
        RegexOption.IGNORE_CASE
    )

    fun extractCommands(content: String): List<DeviceCommand> {
        return commandBlockRegex.findAll(content)
            .mapNotNull { match ->
                parseCommandJson(match.groupValues[1].trim())
            }
            .toList()
    }

    private fun parseCommandJson(json: String): DeviceCommand? {
        return try {
            val type = object : TypeToken<Map<String, Any>>() {}.type
            val map: Map<String, Any> = gson.fromJson(json, type) ?: return null

            val actionStr = map["action"] as? String ?: return null
            @Suppress("UNCHECKED_CAST")
            val rawParams = map["params"] as? Map<String, Any> ?: emptyMap()

            // Convert all param values to strings
            val params = rawParams.mapValues { (_, v) -> v.toString() }

            DeviceCommand(
                action = CommandAction.fromString(actionStr),
                params = params,
                rawAction = actionStr
            )
        } catch (_: Exception) {
            null
        }
    }

    // ── Natural language quick-parse ───────────────
    // Allows simple command detection from user voice input
    // without requiring a full LLM round-trip.

    data class OfflineCommand(
        val command: DeviceCommand?,
        val isOfflineCapable: Boolean,
        val responseText: String
    )

    fun tryParseOfflineCommand(text: String): OfflineCommand? {
        val lower = text.lowercase().trim()

        // Flashlight
        if (lower.contains("flashlight") || lower.contains("torch")) {
            val on = lower.contains("on") || lower.contains("turn on") || lower.contains("enable")
            val off = lower.contains("off") || lower.contains("turn off") || lower.contains("disable")
            val state = when {
                on && !off -> "on"
                off -> "off"
                else -> "toggle"
            }
            return OfflineCommand(
                command = DeviceCommand(
                    action = CommandAction.TOGGLE_FLASHLIGHT,
                    params = mapOf("state" to state)
                ),
                isOfflineCapable = true,
                responseText = if (state == "off") "Turning off the flashlight." else "Turning on the flashlight."
            )
        }

        // Volume
        val volumeMatch = Regex("volume\\s*(to\\s*)?(\\d+)").find(lower)
        if (volumeMatch != null) {
            val level = volumeMatch.groupValues[2]
            return OfflineCommand(
                command = DeviceCommand(
                    action = CommandAction.SET_VOLUME,
                    params = mapOf("level" to level)
                ),
                isOfflineCapable = true,
                responseText = "Setting volume to $level%."
            )
        }
        if (lower.contains("mute") || lower.contains("silence")) {
            return OfflineCommand(
                command = DeviceCommand(CommandAction.SET_VOLUME, mapOf("level" to "0")),
                isOfflineCapable = true,
                responseText = "Muting device."
            )
        }

        // Wi-Fi
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            val state = if (lower.contains("off") || lower.contains("disable")) "off" else "on"
            return OfflineCommand(
                command = DeviceCommand(CommandAction.TOGGLE_WIFI, mapOf("state" to state)),
                isOfflineCapable = true,
                responseText = "Toggling Wi-Fi $state."
            )
        }

        // Bluetooth
        if (lower.contains("bluetooth")) {
            val state = if (lower.contains("off") || lower.contains("disable")) "off" else "on"
            return OfflineCommand(
                command = DeviceCommand(CommandAction.TOGGLE_BLUETOOTH, mapOf("state" to state)),
                isOfflineCapable = true,
                responseText = "Toggling Bluetooth $state."
            )
        }

        // Open app — ONLY match when user clearly intends to LAUNCH an app
        // Must start with "open"/"launch"/"start" as the first meaningful word
        // and must NOT be part of a longer sentence about something else
        val trimmed = lower.trim()
        val isExplicitAppLaunch = (
            trimmed.startsWith("open ") ||
            trimmed.startsWith("launch ") ||
            trimmed.startsWith("start ")
        ) && trimmed.split(" ").size <= 5 // Short command, not a sentence

        if (isExplicitAppLaunch) {
            val appName = trimmed
                .removePrefix("open ").removePrefix("launch ").removePrefix("start ")
                .replace(Regex("\\s+(app|application|for me|please)$"), "")
                .trim()
            // Ignore if the "app name" is a common non-app word
            val nonAppWords = setOf("it", "that", "this", "the", "a", "an",
                "up", "me", "my", "your", "their", "his", "her",
                "jar", "door", "window", "file", "box", "letter",
                "account", "ticket", "issue", "source", "ended")
            if (appName.isNotBlank() && appName !in nonAppWords && appName.length > 2) {
                return OfflineCommand(
                    command = DeviceCommand(CommandAction.OPEN_APP, mapOf("name" to appName)),
                    isOfflineCapable = true,
                    responseText = "Opening $appName."
                )
            }
        }

        // Alarm
        val alarmMatch = Regex("(set|wake me|alarm).*?(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE).find(lower)
        if (alarmMatch != null && lower.contains("alarm")) {
            var hour = alarmMatch.groupValues[2].toIntOrNull() ?: 7
            val minute = alarmMatch.groupValues[3].toIntOrNull() ?: 0
            val period = alarmMatch.groupValues[4].lowercase()
            if (period == "pm" && hour != 12) hour += 12
            if (period == "am" && hour == 12) hour = 0
            return OfflineCommand(
                command = DeviceCommand(
                    action = CommandAction.SET_ALARM,
                    params = mapOf("hour" to hour.toString(), "minute" to minute.toString())
                ),
                isOfflineCapable = true,
                responseText = "Setting alarm for $hour:${minute.toString().padStart(2, '0')}."
            )
        }

        return null  // Not an offline command — needs LLM
    }
}
