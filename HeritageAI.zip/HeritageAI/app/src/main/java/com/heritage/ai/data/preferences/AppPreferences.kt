package com.heritage.ai.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.heritage.ai.data.remote.model.LLMProviders
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// Extension property for DataStore instance
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "heritage_prefs")

/**
 * Heritage AI application preferences — stored in DataStore.
 *
 * Covers: API settings, UI preferences, voice settings, feature toggles.
 */
@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {

    // ── Keys ───────────────────────────────────────
    companion object Keys {
        // API / LLM
        val LLM_PROVIDER_ID = stringPreferencesKey("llm_provider_id")
        val LLM_API_KEY = stringPreferencesKey("llm_api_key")
        val LLM_MODEL = stringPreferencesKey("llm_model")
        val LLM_BASE_URL = stringPreferencesKey("llm_base_url")
        val LLM_TEMPERATURE = floatPreferencesKey("llm_temperature")
        val LLM_MAX_TOKENS = intPreferencesKey("llm_max_tokens")

        // User
        val USER_NAME = stringPreferencesKey("user_name")
        val USER_LOCATION = stringPreferencesKey("user_location")

        // Voice
        val VOICE_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val VOICE_TTS_SPEED = floatPreferencesKey("tts_speed")
        val VOICE_TTS_PITCH = floatPreferencesKey("tts_pitch")
        val VOICE_TTS_ENABLED = booleanPreferencesKey("tts_enabled")
        val VOICE_LANGUAGE = stringPreferencesKey("voice_language")

        // UI
        val THEME_DARK = booleanPreferencesKey("theme_dark")
        val THEME_FOLLOW_SYSTEM = booleanPreferencesKey("theme_follow_system")
        val SHOW_FLOATING_BUBBLE = booleanPreferencesKey("floating_bubble")

        // Features
        val NOTIFICATION_READING = booleanPreferencesKey("notification_reading")
        val ACCESSIBILITY_ENABLED = booleanPreferencesKey("accessibility_enabled")
        val LONG_TERM_MEMORY = booleanPreferencesKey("long_term_memory")

        // System prompt
        val SYSTEM_PROMPT_CUSTOM = stringPreferencesKey("system_prompt_custom")

        // Onboarding
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val CURRENT_CONVERSATION_ID = stringPreferencesKey("current_conversation_id")
    }

    // ── Flows ──────────────────────────────────────

    val llmProviderId: Flow<String> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[LLM_PROVIDER_ID] ?: LLMProviders.HERITAGE_PROXY.id }

    val llmApiKey: Flow<String> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[LLM_API_KEY] ?: "" }

    val llmModel: Flow<String> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[LLM_MODEL] ?: "openai/gpt-oss-20b" }

    val llmBaseUrl: Flow<String> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[LLM_BASE_URL] ?: LLMProviders.HERITAGE_PROXY.baseUrl }

    val llmTemperature: Flow<Float> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[LLM_TEMPERATURE] ?: 0.9f }

    val llmMaxTokens: Flow<Int> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[LLM_MAX_TOKENS] ?: 2048 }

    val userName: Flow<String> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[USER_NAME] ?: "" }

    val wakeWordEnabled: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[VOICE_WAKE_WORD_ENABLED] ?: false }

    val ttsEnabled: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[VOICE_TTS_ENABLED] ?: true }

    val ttsSpeed: Flow<Float> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[VOICE_TTS_SPEED] ?: 1.0f }

    val ttsPitch: Flow<Float> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[VOICE_TTS_PITCH] ?: 1.0f }

    val isDarkTheme: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[THEME_DARK] ?: true }

    val followSystemTheme: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[THEME_FOLLOW_SYSTEM] ?: true }

    val showFloatingBubble: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[SHOW_FLOATING_BUBBLE] ?: true }

    val notificationReadingEnabled: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[NOTIFICATION_READING] ?: false }

    val longTermMemoryEnabled: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[LONG_TERM_MEMORY] ?: true }

    val onboardingDone: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[ONBOARDING_DONE] ?: false }

    val currentConversationId: Flow<String> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[CURRENT_CONVERSATION_ID] ?: "" }

    // ── Suspend setters ────────────────────────────

    suspend fun setApiKey(key: String) {
        context.dataStore.edit { it[LLM_API_KEY] = key }
    }

    suspend fun setLLMProvider(providerId: String, baseUrl: String, model: String) {
        context.dataStore.edit { prefs ->
            prefs[LLM_PROVIDER_ID] = providerId
            prefs[LLM_BASE_URL] = baseUrl
            prefs[LLM_MODEL] = model
        }
    }

    suspend fun setModel(model: String) {
        context.dataStore.edit { it[LLM_MODEL] = model }
    }

    suspend fun setTemperature(temp: Float) {
        context.dataStore.edit { it[LLM_TEMPERATURE] = temp }
    }

    suspend fun setUserName(name: String) {
        context.dataStore.edit { it[USER_NAME] = name }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        context.dataStore.edit { it[VOICE_WAKE_WORD_ENABLED] = enabled }
    }

    suspend fun setTtsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[VOICE_TTS_ENABLED] = enabled }
    }

    suspend fun setTtsSpeed(speed: Float) {
        context.dataStore.edit { it[VOICE_TTS_SPEED] = speed }
    }

    suspend fun setDarkTheme(dark: Boolean) {
        context.dataStore.edit { it[THEME_DARK] = dark }
    }

    suspend fun setFollowSystem(follow: Boolean) {
        context.dataStore.edit { it[THEME_FOLLOW_SYSTEM] = follow }
    }

    suspend fun setShowFloatingBubble(show: Boolean) {
        context.dataStore.edit { it[SHOW_FLOATING_BUBBLE] = show }
    }

    suspend fun setNotificationReadingEnabled(enabled: Boolean) {
        context.dataStore.edit { it[NOTIFICATION_READING] = enabled }
    }

    suspend fun setLongTermMemoryEnabled(enabled: Boolean) {
        context.dataStore.edit { it[LONG_TERM_MEMORY] = enabled }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { it[ONBOARDING_DONE] = done }
    }

    suspend fun setCurrentConversationId(id: String) {
        context.dataStore.edit { it[CURRENT_CONVERSATION_ID] = id }
    }
}
