package com.heritage.ai.presentation.theme

import androidx.compose.runtime.compositionLocalOf

/**
 * CompositionLocal that signals whether the current device is low-RAM
 * (e.g. Android Go Edition, like the Itel A50 with 2–4GB RAM and a
 * PowerVR GE8322 GPU).
 *
 * Consuming composables use this to skip expensive GPU effects:
 *   - Multi-layer radial glow / pulse rings in [VoiceOrb]
 *   - Background blur in [VoiceOverlay]
 *   - Layered shimmer animations
 *
 * Provided at the root [HeritageAITheme] call site in [MainActivity].
 * Components read it with:
 *   val isLowRam = LocalIsLowRamDevice.current
 */
val LocalIsLowRamDevice = compositionLocalOf { false }
