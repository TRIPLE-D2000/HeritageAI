package com.heritage.ai.presentation.routines

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.heritage.ai.domain.model.Routine
import com.heritage.ai.domain.model.RoutineAction
import com.heritage.ai.domain.model.RoutineActionType
import com.heritage.ai.domain.model.RoutineTrigger
import com.heritage.ai.domain.repository.RoutineRepository
import com.heritage.ai.util.RoutineEngine
import com.heritage.ai.util.RoutineScheduler
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.ui.window.Dialog
import dagger.hilt.android.qualifiers.ApplicationContext
import com.heritage.ai.presentation.theme.HeritageViolet
import com.heritage.ai.presentation.theme.HeritageTeal
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

// ──────────────────────────────────────────────────
// ROUTINES VIEW MODEL
// ──────────────────────────────────────────────────

@HiltViewModel
class RoutinesViewModel @Inject constructor(
    private val routineRepository: RoutineRepository,
    private val routineEngine: RoutineEngine,
    private val routineScheduler: RoutineScheduler,
    @ApplicationContext private val context: android.content.Context
) : ViewModel() {

    val routines = routineRepository.getAllRoutines()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch {
            routineRepository.setEnabled(id, enabled)
            val routine = routineRepository.getRoutineById(id) ?: return@launch
            if (routine.trigger == RoutineTrigger.TIME_BASED && routine.triggerValue.isNotBlank()) {
                if (enabled) routineScheduler.schedule(context, id, routine.triggerValue)
                else routineScheduler.cancel(context, id)
            }
        }
    }

    /**
     * Sets or clears [routine]'s daily schedule. A null/blank [time] clears
     * it back to manual-only. Only actually arms the alarm if the routine
     * is currently enabled — a disabled routine can have a schedule saved
     * without it firing.
     */
    fun setSchedule(routine: Routine, time: String?) {
        viewModelScope.launch {
            if (time.isNullOrBlank()) {
                routineRepository.saveRoutine(routine.copy(trigger = RoutineTrigger.MANUAL, triggerValue = ""))
                routineScheduler.cancel(context, routine.id)
            } else {
                routineRepository.saveRoutine(routine.copy(trigger = RoutineTrigger.TIME_BASED, triggerValue = time))
                if (routine.isEnabled) routineScheduler.schedule(context, routine.id, time)
            }
        }
    }

    fun runRoutine(routine: Routine) {
        viewModelScope.launch {
            routineRepository.recordRun(routine.id)
            // FIX #7: Actually execute the routine actions
            routineEngine.execute(routine)
        }
    }

    fun deleteRoutine(id: String) {
        viewModelScope.launch {
            routineScheduler.cancel(context, id)
            routineRepository.deleteRoutine(id)
        }
    }

    /**
     * Restores whichever of the 5 built-in routines are currently missing,
     * matched by their fixed id (e.g. "routine_gaming") — NOT a blanket
     * "list is empty" check. Previously, deleting even one default routine
     * lost it permanently since there was no "add" flow to bring it back;
     * this covers that gap without touching any other routines (including
     * future custom ones, which would have different ids).
     */
    fun restoreMissingDefaults() {
        viewModelScope.launch {
            val existingIds = routines.value.map { it.id }.toSet()
            defaultRoutines()
                .filter { it.id !in existingIds }
                .forEach { routineRepository.saveRoutine(it) }
        }
    }
}

private fun defaultRoutines(): List<Routine> = listOf(
    Routine(
        id = "routine_study",
        name = "Study Mode",
        description = "Silence notifications, max brightness, open study apps",
        icon = "📚",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "0", "stream" to "ring"), description = "Mute ringer"),
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "80"), description = "Max brightness"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND")
        )
    ),
    Routine(
        id = "routine_gaming",
        name = "Gaming Mode",
        description = "Max volume, DND, disable Wi-Fi saving",
        icon = "🎮",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "80", "stream" to "media"), description = "Max media volume"),
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "100"), description = "Full brightness"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND")
        )
    ),
    Routine(
        id = "routine_morning",
        name = "Good Morning",
        description = "Gradual brightness, daily briefing, soft alarm volume",
        icon = "☀️",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "50"), description = "Soft brightness"),
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "40", "stream" to "media"), description = "Gentle volume"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "off"), description = "Disable DND"),
            RoutineAction(RoutineActionType.SPEAK_TEXT, mapOf("text" to "Good morning! Ready to start the day?"), description = "Greeting")
        )
    ),
    Routine(
        id = "routine_sleep",
        name = "Sleep Mode",
        description = "Mute everything, lowest brightness, DND on",
        icon = "🌙",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "0"), description = "Mute all"),
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "0"), description = "Min brightness"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND")
        )
    ),
    Routine(
        id = "routine_workout",
        name = "Workout Mode",
        description = "High volume, DND, open fitness app",
        icon = "💪",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "90", "stream" to "media"), description = "Loud music"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND"),
            RoutineAction(RoutineActionType.OPEN_APP, mapOf("name" to "YouTube Music"), description = "Open music")
        )
    )
)

// ──────────────────────────────────────────────────
// ROUTINES SCREEN
// ──────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutinesScreen(
    onBack: () -> Unit,
    viewModel: RoutinesViewModel = hiltViewModel()
) {
    val routines by viewModel.routines.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.restoreMissingDefaults()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Routines") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.restoreMissingDefaults() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Restore default routines")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Tap to run · Toggle to enable/disable",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            items(routines, key = { it.id }) { routine ->
                RoutineCard(
                    routine = routine,
                    onRun = { viewModel.runRoutine(routine) },
                    onToggle = { viewModel.toggleEnabled(routine.id, it) },
                    onDelete = { viewModel.deleteRoutine(routine.id) },
                    onSetSchedule = { time -> viewModel.setSchedule(routine, time) }
                )
            }
        }
    }
}

@Composable
private fun RoutineCard(
    routine: Routine,
    onRun: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onSetSchedule: (String?) -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete '${routine.name}'?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showTimePicker) {
        val (initHour, initMinute) = parseTimeOrDefault(routine.triggerValue)
        RoutineTimePickerDialog(
            initialHour = initHour,
            initialMinute = initMinute,
            onDismiss = { showTimePicker = false },
            onConfirm = { h, m ->
                onSetSchedule("%02d:%02d".format(h, m))
                showTimePicker = false
            }
        )
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (routine.isEnabled)
                                Brush.linearGradient(listOf(HeritageViolet, HeritageTeal), Offset.Zero, Offset.Infinite)
                            else
                                Brush.linearGradient(listOf(Color.Gray.copy(0.3f), Color.Gray.copy(0.2f)))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(routine.icon, style = MaterialTheme.typography.titleLarge)
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(routine.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        routine.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        maxLines = 2
                    )
                    if (routine.runCount > 0) {
                        // Deliberately muted, plain text — not a colored pill —
                        // so it reads as a passive stat, not another tappable
                        // action sitting next to Run/Enable.
                        Text(
                            if (routine.runCount == 1) "Run once so far" else "Run ${routine.runCount} times so far",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                Switch(checked = routine.isEnabled, onCheckedChange = onToggle)
            }

            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            Spacer(Modifier.height(12.dp))

            // Schedule is independent of Enabled — a routine can be enabled
            // but manual-only, or have a time set while currently disabled.
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Icon(
                    Icons.Default.Schedule,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Spacer(Modifier.width(6.dp))
                if (routine.trigger == RoutineTrigger.TIME_BASED && routine.triggerValue.isNotBlank()) {
                    Text(
                        "Runs daily at ${formatTime12h(routine.triggerValue)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { showTimePicker = true }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("Change", style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(onClick = { onSetSchedule(null) }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("Remove", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error.copy(alpha = 0.8f))
                    }
                } else {
                    Text(
                        "Manual only",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { showTimePicker = true }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("+ Set a time", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // A labeled, full-width button — not a small icon sitting right
            // next to the Enable switch. That cramped proximity was exactly
            // what made "run" and "enable" easy to mix up (beta feedback).
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(onClick = onRun, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Run now")
                }
                IconButton(onClick = { showDeleteDialog = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoutineTimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    onDismiss: () -> Unit,
    onConfirm: (hour: Int, minute: Int) -> Unit
) {
    val state = rememberTimePickerState(initialHour = initialHour, initialMinute = initialMinute, is24Hour = false)
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), tonalElevation = 6.dp) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Set a time", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 16.dp))
                TimePicker(state = state)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("Set") }
                }
            }
        }
    }
}

/** "19:00" -> "7:00 PM". Falls back to the raw string if it's not parseable. */
private fun formatTime12h(time: String): String {
    val parts = time.split(":")
    if (parts.size != 2) return time
    val hour24 = parts[0].toIntOrNull() ?: return time
    val minute = parts[1].toIntOrNull() ?: return time
    val amPm = if (hour24 < 12) "AM" else "PM"
    val hour12 = when {
        hour24 == 0 -> 12
        hour24 > 12 -> hour24 - 12
        else -> hour24
    }
    return "%d:%02d %s".format(hour12, minute, amPm)
}

/** Parses "HH:mm" for the time picker's initial value, defaulting to 8:00 AM if unset/invalid. */
private fun parseTimeOrDefault(time: String): Pair<Int, Int> {
    val parts = time.split(":")
    val hour = parts.getOrNull(0)?.toIntOrNull()
    val minute = parts.getOrNull(1)?.toIntOrNull()
    return if (hour != null && minute != null && hour in 0..23 && minute in 0..59) hour to minute else 8 to 0
}
