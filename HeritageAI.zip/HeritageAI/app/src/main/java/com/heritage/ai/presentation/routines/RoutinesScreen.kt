package com.heritage.ai.presentation.routines

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.heritage.ai.domain.model.Routine
import com.heritage.ai.domain.model.RoutineAction
import com.heritage.ai.domain.model.RoutineActionType
import com.heritage.ai.domain.repository.RoutineRepository
import com.heritage.ai.util.RoutineEngine
import com.heritage.ai.presentation.theme.HeritageViolet
import com.heritage.ai.presentation.theme.HeritageTeal
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

// ──────────────────────────────────────────────────
// ROUTINES VIEW MODEL
// ──────────────────────────────────────────────────

@HiltViewModel
class RoutinesViewModel @Inject constructor(
    private val routineRepository: RoutineRepository,
    private val routineEngine: RoutineEngine
) : ViewModel() {

    val routines = routineRepository.getAllRoutines()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch { routineRepository.setEnabled(id, enabled) }
    }

    fun runRoutine(routine: Routine) {
        viewModelScope.launch {
            routineRepository.recordRun(routine.id)
            // FIX #7: Actually execute the routine actions
            routineEngine.execute(routine)
        }
    }

    fun deleteRoutine(id: String) {
        viewModelScope.launch { routineRepository.deleteRoutine(id) }
    }

    /** Seeds the default starter routines on first launch (idempotent via REPLACE strategy). */
    fun seedDefaultRoutines() {
        viewModelScope.launch {
            val existing = routines.value
            if (existing.isNotEmpty()) return@launch
            defaultRoutines().forEach { routineRepository.saveRoutine(it) }
        }
    }
}

private fun defaultRoutines(): List<Routine> = listOf(
    Routine(
        id = "routine_study",
        name = "Study Mode",
        description = "Silence notifications, max brightness, open study apps",
        icon = "📚",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "0", "stream" to "ring"), description = "Mute ringer"),
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "80"), description = "Max brightness"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND")
        )
    ),
    Routine(
        id = "routine_gaming",
        name = "Gaming Mode",
        description = "Max volume, DND, disable Wi-Fi saving",
        icon = "🎮",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "80", "stream" to "media"), description = "Max media volume"),
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "100"), description = "Full brightness"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND")
        )
    ),
    Routine(
        id = "routine_morning",
        name = "Good Morning",
        description = "Gradual brightness, daily briefing, soft alarm volume",
        icon = "☀️",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "50"), description = "Soft brightness"),
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "40", "stream" to "media"), description = "Gentle volume"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "off"), description = "Disable DND"),
            RoutineAction(RoutineActionType.SPEAK_TEXT, mapOf("text" to "Good morning! Ready to start the day?"), description = "Greeting")
        )
    ),
    Routine(
        id = "routine_sleep",
        name = "Sleep Mode",
        description = "Mute everything, lowest brightness, DND on",
        icon = "🌙",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "0"), description = "Mute all"),
            RoutineAction(RoutineActionType.SET_BRIGHTNESS, mapOf("level" to "0"), description = "Min brightness"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND")
        )
    ),
    Routine(
        id = "routine_workout",
        name = "Workout Mode",
        description = "High volume, DND, open fitness app",
        icon = "💪",
        actions = listOf(
            RoutineAction(RoutineActionType.SET_VOLUME, mapOf("level" to "90", "stream" to "media"), description = "Loud music"),
            RoutineAction(RoutineActionType.SET_DND, mapOf("state" to "on"), description = "Enable DND"),
            RoutineAction(RoutineActionType.OPEN_APP, mapOf("name" to "YouTube Music"), description = "Open music")
        )
    )
)

// ──────────────────────────────────────────────────
// ROUTINES SCREEN
// ──────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutinesScreen(
    onBack: () -> Unit,
    viewModel: RoutinesViewModel = hiltViewModel()
) {
    val routines by viewModel.routines.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.seedDefaultRoutines()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Routines") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Tap to run · Toggle to enable/disable",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            items(routines, key = { it.id }) { routine ->
                RoutineCard(
                    routine = routine,
                    onRun = { viewModel.runRoutine(routine) },
                    onToggle = { viewModel.toggleEnabled(routine.id, it) },
                    onDelete = { viewModel.deleteRoutine(routine.id) }
                )
            }
        }
    }
}

@Composable
private fun RoutineCard(
    routine: Routine,
    onRun: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete '${routine.name}'?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (routine.isEnabled)
                            Brush.linearGradient(listOf(HeritageViolet, HeritageTeal), Offset.Zero, Offset.Infinite)
                        else
                            Brush.linearGradient(listOf(Color.Gray.copy(0.3f), Color.Gray.copy(0.2f)))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(routine.icon, style = MaterialTheme.typography.titleLarge)
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Text(routine.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    routine.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 2
                )
                if (routine.runCount > 0) {
                    Text(
                        "Run ${routine.runCount}× ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // Controls
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Switch(checked = routine.isEnabled, onCheckedChange = onToggle, modifier = Modifier.size(40.dp, 24.dp))
                FilledTonalIconButton(onClick = onRun, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.PlayArrow, "Run", modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
