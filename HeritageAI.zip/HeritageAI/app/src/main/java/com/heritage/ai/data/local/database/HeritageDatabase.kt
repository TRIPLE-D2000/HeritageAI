package com.heritage.ai.data.local.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.heritage.ai.data.local.dao.ConversationDao
import com.heritage.ai.data.local.dao.MemoryDao
import com.heritage.ai.data.local.dao.MessageDao
import com.heritage.ai.data.local.dao.RoutineDao
import com.heritage.ai.data.local.entity.ConversationEntity
import com.heritage.ai.data.local.entity.Converters
import com.heritage.ai.data.local.entity.MemoryEntity
import com.heritage.ai.data.local.entity.MessageEntity
import com.heritage.ai.data.local.entity.RoutineEntity
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

/**
 * Heritage AI Room Database — encrypted with SQLCipher.
 *
 * All user conversations, memories, and settings are stored in this
 * AES-256 encrypted SQLite database. The encryption key is derived
 * from the device's Android Keystore and never written to disk in
 * plaintext. See [DatabaseEncryption] for key management.
 */
@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryEntity::class,
        RoutineEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class HeritageDatabase : RoomDatabase() {

    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun routineDao(): RoutineDao

    companion object {
        const val DATABASE_NAME = "heritage_ai.db"

        /**
         * Creates the encrypted Room database with the provided passphrase.
         * The passphrase is cleared from memory immediately after use.
         */
        fun create(context: android.content.Context, passphrase: ByteArray): HeritageDatabase {
            val factory = SupportFactory(passphrase)
            // Wipe passphrase from memory for security
            passphrase.fill(0)

            return Room.databaseBuilder(
                context.applicationContext,
                HeritageDatabase::class.java,
                DATABASE_NAME
            )
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration() // Replace with proper migrations in production
                .addCallback(DatabaseCallback())
                .build()
        }
    }

    /**
     * Database lifecycle callbacks — used to pre-populate default routines.
     */
    private class DatabaseCallback : RoomDatabase.Callback() {
        override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            super.onCreate(db)
            // Default routines are inserted via a one-time WorkManager job
            // after the DI graph is fully constructed. See RoutineSeeder.
        }
    }
}
