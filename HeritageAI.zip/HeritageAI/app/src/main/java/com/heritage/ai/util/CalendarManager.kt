package com.heritage.ai.util

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.CalendarContract
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.TimeZone
import javax.inject.Inject
import javax.inject.Singleton

data class CalendarEventResult(
    val id: Long,
    val title: String,
    val description: String,
    val startTime: Long,
    val endTime: Long,
    val location: String,
    val calendarName: String
)

/**
 * CalendarManager — reads upcoming events and creates new ones via the
 * CalendarContract provider. Requires READ_CALENDAR / WRITE_CALENDAR
 * permissions, checked by the caller before invocation.
 */
@Singleton
class CalendarManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /** Returns events between [startMillis] and [endMillis], sorted by start time. */
    suspend fun getEvents(
        startMillis: Long = System.currentTimeMillis(),
        endMillis: Long = startMillis + 7L * 24 * 60 * 60 * 1000, // default: next 7 days
        limit: Int = 20
    ): List<CalendarEventResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<CalendarEventResult>()

        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, startMillis)
        ContentUris.appendId(builder, endMillis)

        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.CALENDAR_DISPLAY_NAME
        )

        runCatching {
            context.contentResolver.query(
                builder.build(), projection, null, null,
                "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { cursor ->
                while (cursor.moveToNext() && results.size < limit) {
                    results += CalendarEventResult(
                        id = cursor.getLong(0),
                        title = cursor.getString(1) ?: "Untitled Event",
                        description = cursor.getString(2) ?: "",
                        startTime = cursor.getLong(3),
                        endTime = cursor.getLong(4),
                        location = cursor.getString(5) ?: "",
                        calendarName = cursor.getString(6) ?: ""
                    )
                }
            }
        }
        results
    }

    /** Returns only today's events. */
    suspend fun getTodayEvents(): List<CalendarEventResult> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_MONTH, 1)
        val end = cal.timeInMillis
        return getEvents(start, end)
    }

    /**
     * Creates a new calendar event on the device's default writable calendar.
     * Returns the new event's URI, or null on failure.
     */
    suspend fun createEvent(
        title: String,
        description: String = "",
        location: String = "",
        startMillis: Long,
        endMillis: Long
    ): Uri? = withContext(Dispatchers.IO) {
        val calendarId = getDefaultCalendarId() ?: return@withContext null

        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, startMillis)
            put(CalendarContract.Events.DTEND, endMillis)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, description)
            put(CalendarContract.Events.EVENT_LOCATION, location)
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }

        runCatching {
            context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        }.getOrNull()
    }

    private fun getDefaultCalendarId(): Long? {
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY)
        return runCatching {
            context.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI, projection,
                "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ?",
                arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getLong(0) else null
            }
        }.getOrNull()
    }
}
