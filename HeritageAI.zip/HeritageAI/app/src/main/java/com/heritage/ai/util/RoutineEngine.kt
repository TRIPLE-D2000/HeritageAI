package com.heritage.ai.util

import com.heritage.ai.domain.model.Routine
import com.heritage.ai.domain.model.RoutineAction
import com.heritage.ai.domain.model.RoutineActionType
import com.heritage.ai.util.CommandAction
import com.heritage.ai.util.DeviceCommand
import com.heritage.ai.util.DeviceControlManager
import com.heritage.ai.util.TextToSpeechManager
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

/**
 * RoutineEngine — executes automation routine action lists.
 *
 * Iterates through each action in a Routine sequentially,
 * calling DeviceControlManager for device commands and
 * TextToSpeechManager for spoken messages.
 */
@Singleton
class RoutineEngine @Inject constructor(
    private val deviceControl: DeviceControlManager,
    private val tts: TextToSpeechManager
) {

    /**
     * Executes all actions in [routine] sequentially.
     * Returns a summary of what was done.
     */
    suspend fun execute(routine: Routine): String {
        val results = mutableListOf<String>()

        routine.actions.forEach { action ->
            // Optional delay before each action
            if (action.delayMs > 0) delay(action.delayMs)

            val result = executeAction(action)
            if (result.isNotBlank()) results.add(result)

            // Small gap between actions so device can process each one
            delay(300)
        }

        val summary = if (results.isEmpty())
            "${routine.name} completed."
        else
            "${routine.name} done: ${results.joinToString(", ")}"

        return summary
    }

    private suspend fun executeAction(action: RoutineAction): String {
        return when (action.type) {
            RoutineActionType.SET_VOLUME ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.SET_VOLUME, action.parameters))

            RoutineActionType.SET_BRIGHTNESS ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.SET_BRIGHTNESS, action.parameters))

            RoutineActionType.TOGGLE_WIFI ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.TOGGLE_WIFI, action.parameters))

            RoutineActionType.TOGGLE_BLUETOOTH ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.TOGGLE_BLUETOOTH, action.parameters))

            RoutineActionType.TOGGLE_FLASHLIGHT ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.TOGGLE_FLASHLIGHT, action.parameters))

            RoutineActionType.OPEN_APP ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.OPEN_APP, action.parameters))

            RoutineActionType.SET_ALARM ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.SET_ALARM, action.parameters))

            RoutineActionType.SET_DND ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.SET_DND, action.parameters))

            RoutineActionType.SPEAK_TEXT -> {
                val text = action.parameters["text"] ?: return ""
                tts.speak(text)
                ""
            }

            RoutineActionType.SET_RINGTONE_MODE -> {
                // Map to volume command with ring stream
                val params = action.parameters.toMutableMap()
                params["stream"] = "ring"
                deviceControl.executeCommand(DeviceCommand(CommandAction.SET_VOLUME, params))
            }

            RoutineActionType.LAUNCH_SHORTCUT ->
                deviceControl.executeCommand(DeviceCommand(CommandAction.OPEN_APP, action.parameters))

            RoutineActionType.SEND_MESSAGE -> ""  // Requires user confirmation — skip in auto-run
        }
    }
}
