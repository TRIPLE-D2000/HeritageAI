package com.heritage.ai.data.remote.api

import com.heritage.ai.data.remote.model.ChatRequest
import com.heritage.ai.data.remote.model.ChatResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * OpenAI-compatible chat completions API.
 * Supports any provider that follows the OpenAI REST standard.
 */
interface LLMApi {
    @POST("chat/completions")
    suspend fun createChatCompletion(
        @Body request: ChatRequest
    ): Response<ChatResponse>
}
