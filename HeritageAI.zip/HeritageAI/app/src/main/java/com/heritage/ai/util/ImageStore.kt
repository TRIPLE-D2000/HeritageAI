package com.heritage.ai.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import com.heritage.ai.data.local.crypto.SecretCipher
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

/**
 * ImageStore — everything about photos the user shares with the assistant.
 *
 *  - shrinkToJpeg: shrinks a photo to at most 1024 px on its long side (JPEG, quality 80)
 *    so it is cheap to send and does not exhaust RAM on low-end phones
 *  - save / load: photos are kept ENCRYPTED (Android Keystore, AES-GCM) in private storage
 *  - delete / deleteAll: used when a chat or all data is deleted
 */
object ImageStore {
    private const val DIR = "chat_images"
    private const val MAX_SIDE = 1024

    fun shrinkToJpeg(context: Context, uri: Uri): ByteArray? {
        return try {
            val resolver = context.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            // Decode at a reduced size first so a 12 MP photo never fully loads into RAM
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE) sample *= 2
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOpts)
            } ?: return null

            val rotation = resolver.openInputStream(uri)?.use { readRotation(it) } ?: 0
            val scale = MAX_SIDE.toFloat() / maxOf(decoded.width, decoded.height)
            val matrix = Matrix()
            if (scale < 1f) matrix.postScale(scale, scale)
            if (rotation != 0) matrix.postRotate(rotation.toFloat())

            val result = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
            val stream = ByteArrayOutputStream()
            result.compress(Bitmap.CompressFormat.JPEG, 80, stream)
            if (result !== decoded) decoded.recycle()
            result.recycle()
            stream.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    private fun readRotation(stream: java.io.InputStream): Int {
        return try {
            when (ExifInterface(stream).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            0
        }
    }

    /** Saves the photo encrypted; returns the stored file name, or null if it couldn't be saved. */
    fun save(context: Context, jpeg: ByteArray): String? {
        return try {
            val encrypted = SecretCipher.encryptBytes(jpeg) ?: return null
            val dir = File(context.filesDir, DIR).apply { mkdirs() }
            val name = UUID.randomUUID().toString() + ".img"
            File(dir, name).writeBytes(encrypted)
            name
        } catch (e: Exception) {
            null
        }
    }

    fun load(context: Context, name: String): ByteArray? {
        if (name.contains('/') || name.contains("..")) return null
        return try {
            val file = File(File(context.filesDir, DIR), name)
            if (!file.exists()) null else SecretCipher.decryptBytes(file.readBytes())
        } catch (e: Exception) {
            null
        }
    }

    fun delete(context: Context, names: Collection<String>) {
        names.forEach { name ->
            if (!name.contains('/') && !name.contains("..")) {
                runCatching { File(File(context.filesDir, DIR), name).delete() }
            }
        }
    }

    /** Removes every saved photo and any leftover camera captures. */
    fun deleteAll(context: Context) {
        runCatching { File(context.filesDir, DIR).deleteRecursively() }
        runCatching { File(context.cacheDir, "shared").deleteRecursively() }
    }

    /** A fresh file for the camera to write into (inside the FileProvider-shared cache folder). */
    fun newCaptureFile(context: Context): File {
        val dir = File(context.cacheDir, "shared").apply { mkdirs() }
        dir.listFiles()?.forEach { runCatching { it.delete() } } // clear older captures
        return File(dir, "capture_" + System.currentTimeMillis() + ".jpg")
    }
}
