package com.heritage.ai.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.heritage.ai.domain.model.RoutineTrigger
import com.heritage.ai.domain.repository.RoutineRepository
import com.heritage.ai.service.FloatingBubbleService
import com.heritage.ai.service.WakeWordService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * BootReceiver — restarts user-enabled persistent services after the
 * device reboots or the app is updated (Android kills all running
 * services and broadcasts go away on both events).
 *
 * Respects user preferences: only restarts the wake-word listener or
 * floating bubble if the user had explicitly enabled them, and only
 * restarts the overlay if the SYSTEM_ALERT_WINDOW permission is still
 * granted (it can be revoked by the user or the OS between boots).
 *
 * Also re-arms any time-based routine alarms — AlarmManager clears all
 * pending alarms on reboot, so without this a scheduled routine would
 * silently stop firing until the app happened to be opened again.
 *
 * Hilt's @AndroidEntryPoint on a BroadcastReceiver lets us inject
 * [AppPreferences] directly without manually wiring an EntryPoint.
 */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var preferences: com.heritage.ai.data.preferences.AppPreferences

    @Inject
    lateinit var routineRepository: RoutineRepository

    @Inject
    lateinit var routineScheduler: RoutineScheduler

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        // BroadcastReceivers get a limited time window to finish work;
        // dispatch to a short-lived coroutine scope rather than blocking.
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                restoreServices(context)
                rearmScheduledRoutines(context)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun rearmScheduledRoutines(context: Context) {
        val routines = routineRepository.getAllRoutines().first()
        routines
            .filter { it.isEnabled && it.trigger == RoutineTrigger.TIME_BASED && it.triggerValue.isNotBlank() }
            .forEach { routine -> routineScheduler.schedule(context, routine.id, routine.triggerValue) }
    }

    private suspend fun restoreServices(context: Context) {
        val wakeWordEnabled = preferences.wakeWordEnabled.first()
        if (wakeWordEnabled) {
            val serviceIntent = Intent(context, WakeWordService::class.java)
            ContextCompat.startForegroundService(context, serviceIntent)
        }

        val bubbleEnabled = preferences.showFloatingBubble.first()
        if (bubbleEnabled && hasOverlayPermission(context)) {
            val serviceIntent = Intent(context, FloatingBubbleService::class.java)
            ContextCompat.startForegroundService(context, serviceIntent)
        }
    }

    private fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }
}
