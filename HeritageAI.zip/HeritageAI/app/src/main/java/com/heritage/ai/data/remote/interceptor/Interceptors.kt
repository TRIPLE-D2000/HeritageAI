package com.heritage.ai.data.remote.interceptor

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Injects the Bearer API key into every outgoing request.
 * The key is fetched from DataStore each time to pick up changes without restart.
 */
class AuthInterceptor(
    private val apiKeyProvider: suspend () -> String
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val apiKey = runBlocking { apiKeyProvider() }

        val request = chain.request().newBuilder()
            .apply {
                if (apiKey.isNotBlank()) {
                    header("Authorization", "Bearer $apiKey")
                }
                header("Content-Type", "application/json")
                header("HTTP-Referer", "https://heritage.ai")
                header("X-Title", "Heritage AI")
            }
            .build()

        return chain.proceed(request)
    }
}

/**
 * Intercepts requests and rewrites the base URL dynamically.
 * Needed so that switching LLM providers in Settings takes effect
 * without recreating the entire Retrofit instance.
 */
class DynamicBaseUrlInterceptor(
    private val baseUrlProvider: suspend () -> String
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val baseUrl = runBlocking { baseUrlProvider() }
        val newUrl = if (baseUrl.isNotBlank()) {
            val parsed = baseUrl.toHttpUrlOrNull()
            if (parsed != null) {
                chain.request().url.newBuilder()
                    .scheme(parsed.scheme)
                    .host(parsed.host)
                    .port(parsed.port)
                    .build()
            } else {
                chain.request().url
            }
        } else {
            chain.request().url
        }

        return chain.proceed(chain.request().newBuilder().url(newUrl).build())
    }
}
