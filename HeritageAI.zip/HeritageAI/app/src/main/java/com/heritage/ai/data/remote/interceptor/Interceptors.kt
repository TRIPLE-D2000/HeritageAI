package com.heritage.ai.data.remote.interceptor

import kotlinx.coroutines.runBlocking
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Injects Bearer API key into every outgoing request.
 */
class AuthInterceptor(
    private val apiKeyProvider: suspend () -> String
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val apiKey = runBlocking { apiKeyProvider() }
        val request = chain.request().newBuilder()
            .apply {
                if (apiKey.isNotBlank()) header("Authorization", "Bearer $apiKey")
                header("Content-Type", "application/json")
                header("HTTP-Referer", "https://heritage.ai")
                header("X-Title", "Heritage AI")
            }
            .build()
        return chain.proceed(request)
    }
}

/**
 * DynamicBaseUrlInterceptor — rewrites the full request URL to use
 * the provider base URL stored in DataStore.
 *
 * ROOT CAUSE OF HTTP 404:
 * The previous version only changed scheme/host/port but left the
 * PATH unchanged. Groq's API lives at /openai/v1/chat/completions
 * but the original Retrofit path is /v1/chat/completions (OpenAI).
 * Swapping only the host sent requests to the WRONG PATH on Groq → 404.
 *
 * FIX:
 * Extract just the API endpoint name from the original request
 * (e.g. "chat/completions") and append it to the full stored base URL.
 * This builds the correct full URL for every provider regardless of
 * how their base path differs.
 */
class DynamicBaseUrlInterceptor(
    private val baseUrlProvider: suspend () -> String
) : Interceptor {

    // All endpoints exposed by LLMApi — used to extract the endpoint
    // name from the original Retrofit-built request URL
    private val knownEndpoints = listOf(
        "chat/completions",
        "completions",
        "embeddings",
        "models"
    )

    override fun intercept(chain: Interceptor.Chain): Response {
        // Use Groq as safe fallback if no provider is configured yet
        val storedBase = runBlocking { baseUrlProvider() }
            .takeIf { it.isNotBlank() } ?: "https://api.groq.com/openai/v1/"

        val originalPath = chain.request().url.encodedPath

        // Find which known API endpoint this request targets
        val endpoint = knownEndpoints.firstOrNull { originalPath.contains(it) }
            ?: originalPath.substringAfterLast("/")

        // Build: storedBase + endpoint
        // e.g. "https://api.groq.com/openai/v1/" + "chat/completions"
        //    = "https://api.groq.com/openai/v1/chat/completions"  ✅
        val fullUrl = "${storedBase.trimEnd('/')}/$endpoint"
        val newUrl = fullUrl.toHttpUrlOrNull() ?: chain.request().url

        return chain.proceed(
            chain.request().newBuilder().url(newUrl).build()
        )
    }
}
