package com.heritage.ai.presentation.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.heritage.ai.presentation.chat.ChatScreen
import com.heritage.ai.presentation.history.HistoryScreen
import com.heritage.ai.presentation.routines.RoutinesScreen
import com.heritage.ai.presentation.settings.SettingsScreen

/**
 * ────────────────────────────────────────────────────────────
 * HERITAGE AI NAVIGATION GRAPH
 * ────────────────────────────────────────────────────────────
 * Single-activity architecture: [MainActivity] hosts this NavHost
 * and every screen is a composable destination. Transitions use a
 * consistent fade + horizontal-slide pattern so the app feels like
 * a single cohesive surface rather than separate "pages".
 */
object HeritageDestinations {
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val HISTORY = "history"
    const val ROUTINES = "routines"
}

/** Key used to pass a chosen conversation ID back from History → Chat via SavedStateHandle. */
const val SELECTED_CONVERSATION_KEY = "selected_conversation_id"

@Composable
fun HeritageNavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = HeritageDestinations.CHAT,
        enterTransition = { slideInHorizontally(initialOffsetX = { it / 4 }, animationSpec = tween(280)) + fadeIn(tween(280)) },
        exitTransition = { fadeOut(tween(180)) },
        popEnterTransition = { fadeIn(tween(200)) },
        popExitTransition = { slideOutHorizontally(targetOffsetX = { it / 4 }, animationSpec = tween(220)) + fadeOut(tween(220)) }
    ) {
        composable(HeritageDestinations.CHAT) { backStackEntry ->
            ChatScreen(
                savedStateHandle = backStackEntry.savedStateHandle,
                onNavigateToSettings = { navController.navigate(HeritageDestinations.SETTINGS) },
                onNavigateToHistory = { navController.navigate(HeritageDestinations.HISTORY) },
                onNavigateToRoutines = { navController.navigate(HeritageDestinations.ROUTINES) }
            )
        }

        composable(HeritageDestinations.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(HeritageDestinations.HISTORY) {
            HistoryScreen(
                onBack = { navController.popBackStack() },
                onSelectConversation = { conversationId ->
                    // Pass the chosen conversation back to Chat's SavedStateHandle —
                    // the standard Compose Navigation pattern for returning a result
                    // to a screen that's still alive on the back stack.
                    navController.previousBackStackEntry
                        ?.savedStateHandle
                        ?.set(SELECTED_CONVERSATION_KEY, conversationId)
                    navController.popBackStack()
                }
            )
        }

        composable(HeritageDestinations.ROUTINES) {
            RoutinesScreen(onBack = { navController.popBackStack() })
        }
    }
}
