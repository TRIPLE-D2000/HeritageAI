package com.heritage.ai.presentation.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.heritage.ai.presentation.theme.*

/**
 * Full-screen voice recognition overlay.
 * Shows: animated orb, live partial transcript, close button.
 */
@Composable
fun VoiceOverlay(
    isVisible: Boolean,
    isListening: Boolean,
    partialText: String,
    amplitude: Float,
    onDismiss: () -> Unit,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn(animationSpec = tween(250)) +
                slideInVertically(initialOffsetY = { it / 4 }, animationSpec = tween(300, easing = EaseOutCubic)),
        exit = fadeOut(animationSpec = tween(200)) +
                slideOutVertically(targetOffsetY = { it / 4 }, animationSpec = tween(200))
    ) {
        val isLowRam = com.heritage.ai.presentation.theme.LocalIsLowRamDevice.current

        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.85f))
                .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { /* consume clicks */ },
            contentAlignment = Alignment.Center
        ) {
            // Background gradient blob — skip on low-RAM (blur is GPU-expensive)
            if (!isLowRam) {
                Box(
                    modifier = Modifier
                        .size(400.dp)
                        .blur(120.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    HeritageViolet.copy(alpha = 0.3f),
                                    HeritageTeal.copy(alpha = 0.15f),
                                    Color.Transparent
                                )
                            )
                        )
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(32.dp),
                modifier = Modifier.padding(32.dp)
            ) {

                // Close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(
                        onClick = {
                            if (isListening) onStopListening()
                            onDismiss()
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Close, "Close", tint = MaterialTheme.colorScheme.onSurface)
                    }
                }

                Spacer(Modifier.weight(1f))

                // Heritage label
                Text(
                    text = if (isListening) "Listening…" else "Tap to speak",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )

                // Animated Orb
                VoiceOrb(
                    amplitude = amplitude,
                    isListening = isListening,
                    size = 140.dp
                )

                // Mic toggle button
                FilledTonalIconButton(
                    onClick = { if (isListening) onStopListening() else onStartListening() },
                    modifier = Modifier.size(64.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = if (isListening)
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                        contentDescription = if (isListening) "Stop listening" else "Start listening",
                        modifier = Modifier.size(28.dp),
                        tint = if (isListening)
                            MaterialTheme.colorScheme.onPrimary
                        else
                            MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Partial transcript display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 80.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedContent(
                        targetState = partialText,
                        transitionSpec = {
                            fadeIn(tween(150)) togetherWith fadeOut(tween(150))
                        },
                        label = "partial_text"
                    ) { text ->
                        Text(
                            text = text.ifBlank { "Start speaking…" },
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (text.isBlank())
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                            else
                                MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            fontStyle = if (text.isBlank()) FontStyle.Italic else FontStyle.Normal
                        )
                    }
                }

                Spacer(Modifier.weight(1f))

                Text(
                    text = "Powered by Heritage AI",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                )
            }
        }
    }
}
