package com.heritage.ai.data.repository

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.heritage.ai.data.local.dao.RoutineDao
import com.heritage.ai.data.local.entity.RoutineEntity
import com.heritage.ai.domain.model.Routine
import com.heritage.ai.domain.model.RoutineAction
import com.heritage.ai.domain.model.RoutineTrigger
import com.heritage.ai.domain.repository.RoutineRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RoutineRepositoryImpl @Inject constructor(
    private val routineDao: RoutineDao
) : RoutineRepository {

    private val gson = Gson()
    private val actionListType = object : TypeToken<List<RoutineAction>>() {}.type

    override fun getAllRoutines(): Flow<List<Routine>> =
        routineDao.getAllRoutines().map { entities -> entities.map { it.toDomain() } }

    override fun getEnabledRoutines(): Flow<List<Routine>> =
        routineDao.getEnabledRoutines().map { entities -> entities.map { it.toDomain() } }

    override suspend fun getRoutineById(id: String): Routine? =
        routineDao.getRoutineById(id)?.toDomain()

    override suspend fun saveRoutine(routine: Routine) {
        routineDao.insertRoutine(routine.toEntity())
    }

    override suspend fun deleteRoutine(routineId: String) {
        val entity = routineDao.getRoutineById(routineId) ?: return
        routineDao.deleteRoutine(entity)
    }

    override suspend fun recordRun(routineId: String) {
        routineDao.recordRun(routineId)
    }

    override suspend fun setEnabled(routineId: String, enabled: Boolean) {
        routineDao.setEnabled(routineId, enabled)
    }

    private fun Routine.toEntity() = RoutineEntity(
        id = id, name = name, description = description, icon = icon,
        actionsJson = gson.toJson(actions),
        trigger = trigger.name, triggerValue = triggerValue,
        isEnabled = isEnabled, createdAt = createdAt, lastRunAt = lastRunAt, runCount = runCount
    )

    private fun RoutineEntity.toDomain(): Routine {
        val actions: List<RoutineAction> = try {
            gson.fromJson(actionsJson, actionListType)
        } catch (_: Exception) {
            emptyList()
        }
        return Routine(
            id = id, name = name, description = description, icon = icon,
            actions = actions,
            trigger = runCatching { RoutineTrigger.valueOf(trigger) }.getOrDefault(RoutineTrigger.MANUAL),
            triggerValue = triggerValue, isEnabled = isEnabled,
            createdAt = createdAt, lastRunAt = lastRunAt, runCount = runCount
        )
    }
}
