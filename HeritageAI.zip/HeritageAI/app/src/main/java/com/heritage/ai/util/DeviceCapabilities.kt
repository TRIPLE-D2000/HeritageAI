package com.heritage.ai.util

import android.app.ActivityManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DeviceCapabilities — detects hardware constraints so Heritage AI can
 * gracefully scale itself down on entry-level devices instead of assuming
 * flagship-class RAM and GPU everywhere.
 *
 * This matters in practice: a large share of Android devices in active use
 * worldwide are budget devices (e.g. Android *Go Edition* phones, common
 * in price-sensitive markets) with 2–4GB RAM and entry-level GPUs. Go
 * Edition is a certified Google program — as part of that certification,
 * such devices are REQUIRED to report [ActivityManager.isLowRamDevice] as
 * `true`, which makes it a reliable, OEM-verified signal rather than a
 * guess based on RAM thresholds alone.
 */
@Singleton
class DeviceCapabilities @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val activityManager by lazy {
        context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    }

    /**
     * Returns true if this device should run in reduced-fidelity mode:
     * fewer simultaneous animations, no expensive blur/glow compositing,
     * lighter visual effects overall.
     *
     * Combines the OS-certified [ActivityManager.isLowRamDevice] flag
     * (authoritative for Android Go Edition devices) with a manual total-RAM
     * fallback for devices that don't set the flag but still ship with
     * constrained memory (≤ 3GB is a common practical threshold below which
     * Compose's blur/RenderEffect compositing becomes visibly janky on
     * entry-level GPUs).
     */
    fun isLowRamDevice(): Boolean {
        if (activityManager.isLowRamDevice) return true

        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val totalRamGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
        return totalRamGb <= 3.0
    }
}
