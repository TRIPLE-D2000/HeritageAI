package com.heritage.ai.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import com.heritage.ai.service.VoiceAssistantService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * VoiceOrchestrator — the single source of truth for voice-recognition
 * state across the entire app.
 *
 * Problem it solves:
 * Android's SpeechRecognizer can only run inside a bound or foreground
 * Service, but the consuming code (ChatViewModel, floating bubble, etc.)
 * lives outside that Service. Direct field injection of a Service into
 * a ViewModel is forbidden (lifecycle mismatch; ViewModel outlives the
 * Service). The canonical solution is a process-scoped singleton that:
 *
 *  1. Binds to [VoiceAssistantService] lazily (only when voice is first
 *     requested)
 *  2. Mirrors the Service's exposed StateFlows into its own flows so that
 *     ViewModels observe these app-scoped flows — not the Service directly
 *  3. Exposes [startListening] / [stopListening] as the single control API
 *
 * ViewModel code never needs to know whether the Service is currently
 * bound; it just calls [startListening] and observes the flows.
 */
@Singleton
class VoiceOrchestrator @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    // ── Publicly observed flows ────────────────────
    private val _recognizedText = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val recognizedText: SharedFlow<String> = _recognizedText.asSharedFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _error = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val error: SharedFlow<String> = _error.asSharedFlow()

    // ── Service connection state ───────────────────
    private var service: VoiceAssistantService? = null
    private var isBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val voiceBinder = binder as? VoiceAssistantService.VoiceBinder ?: return
            service = voiceBinder.getService()
            isBound = true
            mirrorServiceFlows()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            isBound = false
            _isListening.value = false
            _amplitude.value = 0f
            _partialText.value = ""
        }
    }

    /**
     * Mirror the service's internal flows into this orchestrator's flows.
     * Called once the service binds successfully.
     */
    private fun mirrorServiceFlows() {
        val svc = service ?: return
        scope.launch {
            svc.recognizedText.collect { text -> _recognizedText.emit(text) }
        }
        scope.launch {
            svc.partialText.collect { text -> _partialText.value = text }
        }
        scope.launch {
            svc.amplitude.collect { amp -> _amplitude.value = amp }
        }
        scope.launch {
            svc.isListening.collect { listening -> _isListening.value = listening }
        }
        scope.launch {
            svc.errorMessage.collect { msg -> _error.emit(msg) }
        }
    }

    // ── Public control API ─────────────────────────

    /**
     * Starts voice recognition. Binds and starts the foreground service if
     * needed (idempotent — safe to call even when already listening).
     */
    fun startListening() {
        ensureServiceRunning()
        scope.launch(Dispatchers.Main) {
            // Give the bind a moment to complete if it's the first call
            if (isBound) {
                service?.startListening()
            }
        }
    }

    /** Stops active voice recognition without stopping the service itself. */
    fun stopListening() {
        service?.stopListening()
        _isListening.value = false
        _partialText.value = ""
        _amplitude.value = 0f
    }

    /**
     * Starts + binds the [VoiceAssistantService] foreground service.
     * No-op if the service is already running.
     */
    private fun ensureServiceRunning() {
        val intent = Intent(context, VoiceAssistantService::class.java)
        context.startForegroundService(intent)
        if (!isBound) {
            context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }
    }

    /**
     * Permanently stops the voice service and unbinds.
     * Called when the user disables the assistant entirely, not on every
     * individual stop (the service keeps running between queries so the
     * foreground notification stays consistent).
     */
    fun shutdown() {
        if (isBound) {
            context.unbindService(connection)
            isBound = false
        }
        service = null
        context.stopService(Intent(context, VoiceAssistantService::class.java))
    }
}
