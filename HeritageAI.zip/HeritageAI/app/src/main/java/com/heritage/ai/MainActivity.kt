package com.heritage.ai

import android.view.KeyEvent
import android.content.BroadcastReceiver
import com.heritage.ai.util.ButtonTriggerManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.presentation.navigation.HeritageNavGraph
import com.heritage.ai.presentation.theme.HeritageAITheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MainActivity — the single Activity hosting all of Heritage AI's
 * Compose screens via [HeritageNavGraph].
 *
 * Responsibilities:
 *  - Installs the splash screen (Android 12+ SplashScreen API,
 *    gracefully degrades on older versions via the compat theme)
 *  - Resolves the dark/light theme preference (manual override or
 *    system default) and applies it reactively
 *  - Handles the `heritage://assistant` deep link used by the
 *    floating bubble / wake-word service to bring the UI forward
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var preferences: AppPreferences

    @Inject
    lateinit var deviceCapabilities: com.heritage.ai.util.DeviceCapabilities

    @Inject
    lateinit var buttonTriggerManager: ButtonTriggerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        // Splash screen must be installed before super.onCreate() and
        // before any content is set, per the SplashScreen API contract.
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Keep the splash visible for a brief moment while the very first
        // preferences read resolves, avoiding a flash of default theme.
        var isReady = false
        splashScreen.setKeepOnScreenCondition { !isReady }
        lifecycleScope.launch {
            preferences.onboardingDone.collect {
                isReady = true
            }
        }

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.auto(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )

        // Observe volume-button long-press trigger
        lifecycleScope.launch {
            buttonTriggerManager.voiceTrigger.collect {
                startVoiceFromWakeWord()
            }
        }

        // Handle quick voice query if app was launched fresh from the overlay
        intent?.getStringExtra("quick_voice_query")?.let { query ->
            if (query.isNotBlank()) {
                // Small delay so ChatViewModel finishes initialising first
                lifecycleScope.launch {
                    kotlinx.coroutines.delay(800)
                    broadcastQuickQuery(query)
                }
            }
        }

        // Register receiver for wake word detection from WakeWordService
        val wakeReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == com.heritage.ai.service.WakeWordService.ACTION_WAKE_WORD_DETECTED) {
                    // The WakeWordService already brought the app to foreground.
                    // Post a broadcast that VoiceOrchestrator will pick up to
                    // auto-start listening — handled in MainActivity below.
                    startVoiceFromWakeWord()
                }
            }
        }
        val filter = IntentFilter(com.heritage.ai.service.WakeWordService.ACTION_WAKE_WORD_DETECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(wakeReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(wakeReceiver, filter)
        }

        setContent {
            val followSystem by preferences.followSystemTheme.collectAsStateWithLifecycle(initialValue = true)
            val manualDark by preferences.isDarkTheme.collectAsStateWithLifecycle(initialValue = true)
            val systemDark = isSystemInDarkTheme()
            val useDarkTheme = if (followSystem) systemDark else manualDark
            val isLowRam = remember { deviceCapabilities.isLowRamDevice() }

            androidx.compose.runtime.CompositionLocalProvider(
                com.heritage.ai.presentation.theme.LocalIsLowRamDevice provides isLowRam
            ) {
                HeritageAITheme(darkTheme = useDarkTheme) {
                    HeritageNavGraph()
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Long-press volume down activates Heritage AI voice
        if (buttonTriggerManager.onKeyDown(keyCode)) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        buttonTriggerManager.onKeyUp(keyCode)
        return super.onKeyUp(keyCode, event)
    }

    private fun startVoiceFromWakeWord() {
        // Broadcast internally — ChatViewModel observes this via VoiceOrchestrator
        val i = Intent("com.heritage.ai.START_VOICE_FROM_WAKE").apply { setPackage(packageName) }
        sendBroadcast(i)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Handle quick voice query arriving while app is already open
        intent.getStringExtra("quick_voice_query")?.let { query ->
            if (query.isNotBlank()) broadcastQuickQuery(query)
        }
    }

    private fun broadcastQuickQuery(query: String) {
        // Send to ChatViewModel via internal broadcast
        val broadcast = Intent("com.heritage.ai.QUICK_VOICE_COMMAND").apply {
            setPackage(packageName)
            putExtra("command_text", query)
        }
        sendBroadcast(broadcast)
    }
}
