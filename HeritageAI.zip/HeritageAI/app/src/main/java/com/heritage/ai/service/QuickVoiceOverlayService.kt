package com.heritage.ai.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.heritage.ai.util.DeviceControlManager
import com.heritage.ai.util.CommandParser
import com.heritage.ai.util.TextToSpeechManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import java.util.Locale
import javax.inject.Inject

/**
 * QuickVoiceOverlayService — the Siri-style floating voice bubble.
 *
 * Draws a small overlay window (no full Activity) showing:
 *  - A pulsing "H" orb while listening
 *  - The recognised text as it comes in
 *  - Auto-dismisses after the command is processed
 *
 * Triggered by: 3× volume-down presses in quick succession.
 * Requires:     SYSTEM_ALERT_WINDOW permission (overlay).
 */
@AndroidEntryPoint
class QuickVoiceOverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    // ── Lifecycle plumbing for Compose inside a Service ──
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    @Inject lateinit var deviceControl: DeviceControlManager
    @Inject lateinit var commandParser: CommandParser
    @Inject lateinit var tts: TextToSpeechManager

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Observable state for the Compose overlay
    private var overlayText by mutableStateOf("Listening…")
    private var amplitude  by mutableStateOf(0f)
    private var phase      by mutableStateOf(OverlayPhase.LISTENING)

    enum class OverlayPhase { LISTENING, PROCESSING, DONE }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(1004, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        showOverlay()
        return START_NOT_STICKY // Don't restart — one-shot service
    }

    // ── Overlay Window ────────────────────────────

    private fun showOverlay() {
        if (overlayView != null) return // Already showing

        val screenWidth  = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels

        val params = WindowManager.LayoutParams(
            (screenWidth * 0.85f).toInt(),  // 85% screen width
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = (screenHeight * 0.12f).toInt() // 12% from bottom
        }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@QuickVoiceOverlayService)
            setViewTreeSavedStateRegistryOwner(this@QuickVoiceOverlayService)
            setContent {
                QuickOverlayContent(
                    text      = overlayText,
                    amplitude = amplitude,
                    phase     = phase,
                    onDismiss = { dismissAndStop() }
                )
            }
        }

        overlayView = composeView
        windowManager.addView(composeView, params)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        // Start listening immediately
        startListening()
    }

    // ── Speech Recognition ────────────────────────

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            overlayText = "Speech recognition not available"
            scope.launch { delay(2000); dismissAndStop() }
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(params: android.os.Bundle?) {
                overlayText = "Listening…"
            }

            override fun onBeginningOfSpeech() {
                overlayText = "I hear you…"
            }

            override fun onRmsChanged(rmsdB: Float) {
                amplitude = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }

            override fun onResults(results: android.os.Bundle?) {
                amplitude = 0f
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull { it.isNotBlank() }

                if (text != null) {
                    overlayText = "\"$text\""
                    phase = OverlayPhase.PROCESSING
                    processCommand(text)
                } else {
                    overlayText = "Didn't catch that"
                    scope.launch { delay(1800); dismissAndStop() }
                }
                destroyRecognizer()
            }

            override fun onError(error: Int) {
                amplitude = 0f
                overlayText = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that — try again"
                    SpeechRecognizer.ERROR_NETWORK        -> "No internet for speech"
                    else                                  -> "Mic error — try again"
                }
                scope.launch { delay(2000); dismissAndStop() }
                destroyRecognizer()
            }

            override fun onPartialResults(partial: android.os.Bundle?) {
                val text = partial
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: return
                overlayText = text
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { amplitude = 0f }
            override fun onEvent(type: Int, params: android.os.Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
        speechRecognizer?.startListening(intent)
    }

    // ── Command Processing ────────────────────────

    private fun processCommand(text: String) {
        scope.launch {
            // ── Step 1: Try offline device commands first ──
            // These are instant — no network, no LLM, no app needed.
            // Examples: flashlight, volume, Wi-Fi, Bluetooth, open app, alarm
            val offline = commandParser.tryParseOfflineCommand(text)
            if (offline != null && offline.isOfflineCapable && offline.command != null) {
                val result = deviceControl.executeCommand(offline.command)
                overlayText = offline.responseText
                phase = OverlayPhase.DONE
                tts.speak(offline.responseText)
                // Overlay shows result briefly then dismisses — app never opens
                delay(1800)
                dismissAndStop()
                return@launch
            }

            // ── Step 2: Conversational question — needs LLM ──
            // Show a brief "opening Heritage AI" message then open the app
            // with the question pre-loaded so the answer appears immediately.
            overlayText = "Opening Heritage AI…"
            phase = OverlayPhase.PROCESSING
            delay(600) // Brief pause so user sees the transition

            // Open Heritage AI with the question as a deep-link extra
            // ChatViewModel will auto-send this text on launch
            val openApp = Intent(this@QuickVoiceOverlayService, com.heritage.ai.MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("quick_voice_query", text)
            }
            startActivity(openApp)

            phase = OverlayPhase.DONE
            delay(400)
            dismissAndStop()
        }
    }

    // ── Cleanup ───────────────────────────────────

    private fun destroyRecognizer() {
        runCatching { speechRecognizer?.cancel(); speechRecognizer?.destroy() }
        speechRecognizer = null
    }

    private fun dismissAndStop() {
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        overlayView = null
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        destroyRecognizer()
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "heritage_quick_voice", "Quick Voice", NotificationManager.IMPORTANCE_MIN
        ).apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification() =
        androidx.core.app.NotificationCompat.Builder(this, "heritage_quick_voice")
            .setSmallIcon(com.heritage.ai.R.drawable.ic_heritage_logo)
            .setContentTitle("Heritage AI listening")
            .setSilent(true).setOngoing(true)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MIN)
            .build()
}

// ── Compose UI for the overlay ─────────────────────────────────────────────

@Composable
fun QuickOverlayContent(
    text: String,
    amplitude: Float,
    phase: QuickVoiceOverlayService.OverlayPhase,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse"
    )

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFF1C1A35),
        tonalElevation = 8.dp,
        shadowElevation = 16.dp,
        modifier = Modifier.fillMaxWidth().padding(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Animated H orb
            val orbScale = if (phase == QuickVoiceOverlayService.OverlayPhase.LISTENING)
                pulse * (1f + amplitude * 0.15f) else 1f

            Box(
                modifier = Modifier
                    .size(52.dp)
                    .scale(orbScale)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF6B4EFF), Color(0xFF00D4B4)),
                            Offset.Zero, Offset.Infinite
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (phase) {
                    QuickVoiceOverlayService.OverlayPhase.LISTENING ->
                        Text("H", color = Color.White, fontSize = 22.sp)
                    QuickVoiceOverlayService.OverlayPhase.PROCESSING ->
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    QuickVoiceOverlayService.OverlayPhase.DONE ->
                        Text("✓", color = Color.White, fontSize = 20.sp)
                }
            }

            // Text area
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = when (phase) {
                        QuickVoiceOverlayService.OverlayPhase.LISTENING   -> "Heritage AI"
                        QuickVoiceOverlayService.OverlayPhase.PROCESSING  -> "Processing…"
                        QuickVoiceOverlayService.OverlayPhase.DONE        -> "Done"
                    },
                    color = Color(0xFF9B82FF),
                    fontSize = 11.sp
                )
                Text(
                    text = text,
                    color = Color.White,
                    fontSize = 15.sp,
                    maxLines = 3
                )
            }

            // Dismiss button
            TextButton(onClick = onDismiss) {
                Text("✕", color = Color(0xFF9B82FF), fontSize = 16.sp)
            }
        }
    }
}
