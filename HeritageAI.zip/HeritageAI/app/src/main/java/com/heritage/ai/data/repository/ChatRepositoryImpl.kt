package com.heritage.ai.data.repository

import com.heritage.ai.data.local.dao.ConversationDao
import com.heritage.ai.data.local.dao.MessageDao
import com.heritage.ai.data.local.entity.ConversationEntity
import com.heritage.ai.data.local.entity.toDomain
import com.heritage.ai.data.local.entity.toEntity
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.data.remote.api.LLMApi
import com.heritage.ai.data.remote.model.ApiMessage
import com.heritage.ai.data.remote.model.ChatRequest
import com.heritage.ai.data.remote.model.LLMProviders
import com.heritage.ai.data.remote.model.SystemPromptBuilder
import com.heritage.ai.domain.model.Conversation
import com.heritage.ai.domain.model.Memory
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.MessageRole
import com.heritage.ai.domain.repository.ChatRepository
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import android.content.Context
import com.heritage.ai.plugin.PluginRegistry
import com.heritage.ai.service.HeritageNotificationListenerService
import com.heritage.ai.service.HeritageAccessibilityService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val llmApi: LLMApi,
    private val prefs: AppPreferences,
    private val pluginRegistry: PluginRegistry,
    private val deviceControl: com.heritage.ai.util.DeviceControlManager,
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context
) : ChatRepository {

    override fun getAllConversations(): Flow<List<Conversation>> {
        return conversationDao.getAllConversations().map { entities ->
            entities.map { entity ->
                Conversation(
                    id = entity.id,
                    title = entity.title,
                    createdAt = entity.createdAt,
                    updatedAt = entity.updatedAt,
                    messageCount = entity.messageCount,
                    summary = entity.summary,
                    isPinned = entity.isPinned
                )
            }
        }
    }

    override fun getMessages(conversationId: String): Flow<List<Message>> {
        return messageDao.getMessagesForConversation(conversationId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getRecentMessagesSnapshot(conversationId: String, limit: Int): List<Message> {
        return messageDao.getRecentMessages(conversationId, limit)
            .reversed()
            .map { it.toDomain() }
    }

    override suspend fun createConversation(title: String): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        conversationDao.insertConversation(
            ConversationEntity(
                id = id,
                title = title,
                createdAt = now,
                updatedAt = now,
                messageCount = 0,
                summary = "",
                isPinned = false,
                tags = "[]"
            )
        )
        return id
    }

    override suspend fun saveMessage(message: Message) {
        messageDao.insertMessage(message.toEntity())
        conversationDao.incrementMessageCount(
            id = message.conversationId,
            timestamp = message.timestamp
        )
    }

    override suspend fun sendToLLM(
        conversationId: String,
        userMessage: String,
        contextMemories: List<Memory>,
        imageBase64: String?
    ): Result<Message> {
        return try {
            // Build context: recent messages from this conversation
            // BUGFIX: was 30 — on a long-running thread this let a single
            // request's history alone approach/exceed several thousand
            // tokens, and combined with tool schemas (~1-1.5K tokens,
            // attached to every request now) and a search-triggering
            // message needing 2 back-to-back Groq calls, this was enough
            // to blow past Groq's 8,000 TPM free-tier ceiling in a single
            // user turn — which is what was actually causing the
            // persistent-feeling "Rate limit exceeded" errors, not a daily
            // cap (confirmed via Groq's usage dashboard: 15K tokens used
            // out of a 200K daily budget). 12 keeps meaningful short-term
            // context while leaving real headroom under the per-minute cap.
            val recentMessages = getRecentMessagesSnapshot(conversationId, 12)

            // Fetch settings
            val model = prefs.llmModel.first()
            val temperature = prefs.llmTemperature.first()
            val maxTokens = prefs.llmMaxTokens.first()
            val userName = prefs.userName.first()
            val userBio = prefs.userBio.first()
            val providerId = prefs.llmProviderId.first()

            // Build the system prompt with memory injection
            val systemPrompt = SystemPromptBuilder.build(
                memories = contextMemories.map { it.content },
                userName = userName,
                userBio = userBio,
                currentTime = SimpleDateFormat("EEEE, MMM d yyyy HH:mm", Locale.getDefault())
                    .format(Date()),
                pluginCommands = pluginRegistry.buildSystemPromptSchema(),
                notificationsAvailable = HeritageNotificationListenerService.isServiceEnabled(context),
                accessibilityAvailable = HeritageAccessibilityService.instance != null,
                // Privacy: notifications (OTPs, bank alerts, private chats) are only sent
                // to the cloud model when the user is actually asking about them,
                // and any 4-8 digit codes are masked first.
                activeNotifications = if (
                    HeritageNotificationListenerService.isServiceEnabled(context) &&
                    Regex("notif|alert|missed|message|inbox", RegexOption.IGNORE_CASE)
                        .containsMatchIn(userMessage)
                )
                    (HeritageNotificationListenerService.instance?.getActiveNotificationsSummary() ?: "")
                        .replace(Regex("\\b\\d{4,8}\\b"), "[code hidden]")
                else "",
                conversationSummary = if (contextMemories.isNotEmpty())
                    contextMemories.take(3).joinToString("; ") { it.content }
                else "",
                // Inject apps with package names so LLM uses exact packages
                // Format: "WhatsApp (com.whatsapp)" — LLM extracts package for direct launch
                installedApps = deviceControl.getInstalledApps()
                    .map { (name, pkg) -> "$name ($pkg)" }
            )

            // Build API messages list
            val apiMessagesBase = buildList {
                add(ApiMessage(role = "system", content = systemPrompt))
                // Include conversation history
                // NOTE: also drops blank-content messages. The LLM API rejects the whole
                // request with HTTP 400 once any message has empty content, and existing
                // beta users may already have blank messages saved from before this fix —
                // filtering them here unblocks those conversations immediately instead of
                // requiring everyone to start a new chat.
                recentMessages.filter { !it.isError && it.content.isNotBlank() }.forEach { msg ->
                    add(ApiMessage(role = msg.role.toApiRole(), content = msg.content))
                }
                // Ensure the current user message is last
                if (recentMessages.lastOrNull()?.content != userMessage) {
                    add(ApiMessage(role = "user", content = userMessage))
                }
            }

            // Photo: attached to the newest user message as a marker that the Worker turns
            // into a real image message (and routes to a vision model).
            val apiMessages = if (imageBase64 != null) {
                val idx = apiMessagesBase.indexOfLast { it.role == "user" }
                if (idx >= 0) {
                    apiMessagesBase.mapIndexed { i, m ->
                        if (i == idx) m.copy(
                            content = "[[IMAGE:data:image/jpeg;base64,$imageBase64]]\n" + (m.content ?: "")
                        ) else m
                    }
                } else apiMessagesBase
            } else apiMessagesBase

            val request = ChatRequest(
                model = model,
                messages = apiMessages,
                temperature = temperature.toDouble(),
                maxTokens = maxTokens
            )

            val response = createChatCompletionWithRetry(request)

            if (response.isSuccessful) {
                val body = response.body()
                val message = body?.choices?.firstOrNull()?.message
                val toolCalls = message?.toolCalls.orEmpty()

                // .ifBlank matters here: ?: only catches null, but the API can also
                // return an empty string "" for content, which would otherwise slip
                // through and get saved/sent onward as a blank message.
                var content = message?.content?.ifBlank { null } ?: ""

                if (toolCalls.isNotEmpty()) {
                    // Bridge real tool calls into the existing ```command block
                    // text format rather than rewriting how commands get executed
                    // downstream — CommandParser/ChatViewModel already know how to
                    // parse and run this shape, so only how we OBTAIN the command
                    // JSON changes (reading Groq's structured tool_calls instead of
                    // hoping the model writes it inline in the right format, which
                    // is what caused the "wrong fence" and "tool choice is none but
                    // model called a tool" bugs in the first place).
                    val commandBlocks = toolCalls.joinToString("\n\n") { call ->
                        val actionName = call.function.name.uppercase()
                        "```command\n{\"action\": \"$actionName\", \"params\": ${call.function.arguments}}\n```"
                    }
                    content = if (content.isBlank()) commandBlocks else "$content\n\n$commandBlocks"
                }

                if (content.isBlank()) content = "I'm sorry, I couldn't generate a response."
                val tokens = body?.usage?.completionTokens ?: 0

                val assistantMessage = Message(
                    id = UUID.randomUUID().toString(),
                    conversationId = conversationId,
                    role = MessageRole.ASSISTANT,
                    content = content,
                    timestamp = System.currentTimeMillis(),
                    tokenCount = tokens,
                    model = body?.model ?: model
                )
                Result.success(assistantMessage)
            } else {
                val errorCode = response.code()
                // Try to get the actual error message from the response body
                val errorBody = runCatching {
                    response.errorBody()?.string()
                }.getOrNull() ?: ""
                
                val errorMessage = when (errorCode) {
                    401 -> if (providerId == "heritage_proxy")
                        "The Heritage AI server's own API key needs attention — this isn't " +
                        "something fixable in this app's settings. Check the GROQ_API_KEY " +
                        "secret in the Cloudflare Worker."
                        else "Invalid API key. Please check your settings."
                    404 -> if (errorBody.contains("model")) 
                        "AI model not found. Go to Settings and change the model."
                        else "Service endpoint not found (404). Check your provider settings."
                    429 -> "Rate limit exceeded. Please wait a moment."
                    500, 502, 503 -> "The AI service is temporarily unavailable."
                    400 -> {
                        // errorBody was already being fetched above but discarded
                        // here — this was the missing piece for diagnosing 400s
                        // that survive the empty-message fix. Surfacing Groq's
                        // actual validation message (instead of a generic
                        // "please try again") turns this into a self-diagnosing
                        // problem instead of one that needs adb logcat.
                        val detail = extractGroqErrorMessage(errorBody)
                        if (detail != null) "Request rejected: $detail"
                        else "Request failed (HTTP 400). Please try again."
                    }
                    else -> "Request failed (HTTP $errorCode). Please try again."
                }
                Result.failure(Exception(errorMessage))
            }
        } catch (e: java.net.UnknownHostException) {
            Result.failure(Exception("No internet connection. Please check your network."))
        } catch (e: java.net.SocketTimeoutException) {
            Result.failure(Exception("Request timed out. Please try again."))
        } catch (e: javax.net.ssl.SSLException) {
            Result.failure(Exception("Couldn't make a secure connection. Check your network and try again."))
        } catch (e: java.net.ConnectException) {
            Result.failure(Exception("Couldn't reach the server. Check your network and try again."))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "An unexpected error occurred."))
        }
    }

    /**
     * Sends the chat request. If it fails BEFORE the server could have answered
     * (secure connection failed, couldn't connect, DNS), it tries exactly ONE more time
     * after a short pause: these are usually brief mobile-network hiccups.
     *
     * It never retries HTTP errors (400, 429 rate limit, 5xx) or timeouts: those mean the
     * server already received the request, so repeating them would only waste rate limit
     * and tokens. Background calls (summaries, memory) are not retried at all.
     */
    private suspend fun createChatCompletionWithRetry(
        request: ChatRequest
    ): retrofit2.Response<com.heritage.ai.data.remote.model.ChatResponse> {
        return try {
            llmApi.createChatCompletion(request)
        } catch (e: java.io.IOException) {
            val connectionNeverEstablished =
                e is javax.net.ssl.SSLException ||
                e is java.net.ConnectException ||
                e is java.net.UnknownHostException ||
                e is java.net.NoRouteToHostException
            if (e is java.net.SocketTimeoutException || !connectionNeverEstablished) throw e
            kotlinx.coroutines.delay(1500)
            llmApi.createChatCompletion(request) // second and final attempt
        }
    }

    /**
     * Groq (like OpenAI) returns errors as {"error": {"message": "...", ...}}.
     * Pulls out just the message so the app can show the real reason a
     * request was rejected instead of a generic banner. Returns null if the
     * body isn't in that shape (falls back to the generic message).
     */
    private fun extractGroqErrorMessage(errorBody: String): String? {
        if (errorBody.isBlank()) return null
        return runCatching {
            val type = object : TypeToken<Map<String, Any>>() {}.type
            val map: Map<String, Any> = Gson().fromJson(errorBody, type) ?: return null
            @Suppress("UNCHECKED_CAST")
            val error = map["error"] as? Map<String, Any>
            (error?.get("message") as? String)?.takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    override suspend fun updateConversationTitle(conversationId: String, title: String) {
        conversationDao.updateTitle(conversationId, title)
    }

    override suspend fun deleteConversation(conversationId: String) {
        messageDao.deleteMessagesForConversation(conversationId)
        conversationDao.deleteConversationById(conversationId)
    }

    override suspend fun searchMessages(query: String): List<Message> {
        return messageDao.searchMessages(query).map { it.toDomain() }
    }

    override suspend fun generateSummary(conversationId: String): Result<String> {
        return try {
            val messages = getRecentMessagesSnapshot(conversationId, 20)
            if (messages.isEmpty()) return Result.success("")

            val conversationText = messages.joinToString("\n") { msg ->
                "${msg.role.name}: ${msg.content}"
            }

            val model = prefs.llmModel.first()
            val request = ChatRequest(
                model = model,
                messages = listOf(
                    ApiMessage(
                        role = "user",
                        content = "Summarize this conversation in 1-2 sentences, " +
                                "focusing on the main topic and outcome:\n\n$conversationText"
                    )
                ),
                maxTokens = 100,
                temperature = 0.3,
                toolsDisabled = true
            )

            val response = llmApi.createChatCompletion(request)
            val summary = response.body()?.choices?.firstOrNull()?.message?.content ?: ""
            if (summary.isNotBlank()) {
                conversationDao.updateSummary(conversationId, summary)
            }
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
