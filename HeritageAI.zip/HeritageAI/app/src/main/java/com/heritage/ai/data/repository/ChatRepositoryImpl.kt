package com.heritage.ai.data.repository

import com.heritage.ai.data.local.dao.ConversationDao
import com.heritage.ai.data.local.dao.MessageDao
import com.heritage.ai.data.local.entity.ConversationEntity
import com.heritage.ai.data.local.entity.toDomain
import com.heritage.ai.data.local.entity.toEntity
import com.heritage.ai.data.preferences.AppPreferences
import com.heritage.ai.data.remote.api.LLMApi
import com.heritage.ai.data.remote.model.ApiMessage
import com.heritage.ai.data.remote.model.ChatRequest
import com.heritage.ai.data.remote.model.LLMProviders
import com.heritage.ai.data.remote.model.SystemPromptBuilder
import com.heritage.ai.domain.model.Conversation
import com.heritage.ai.domain.model.Memory
import com.heritage.ai.domain.model.Message
import com.heritage.ai.domain.model.MessageRole
import com.heritage.ai.domain.repository.ChatRepository
import android.content.Context
import com.heritage.ai.plugin.PluginRegistry
import com.heritage.ai.service.HeritageNotificationListenerService
import com.heritage.ai.service.HeritageAccessibilityService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val llmApi: LLMApi,
    private val prefs: AppPreferences,
    private val pluginRegistry: PluginRegistry,
    private val deviceControl: com.heritage.ai.util.DeviceControlManager,
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context
) : ChatRepository {

    override fun getAllConversations(): Flow<List<Conversation>> {
        return conversationDao.getAllConversations().map { entities ->
            entities.map { entity ->
                Conversation(
                    id = entity.id,
                    title = entity.title,
                    createdAt = entity.createdAt,
                    updatedAt = entity.updatedAt,
                    messageCount = entity.messageCount,
                    summary = entity.summary,
                    isPinned = entity.isPinned
                )
            }
        }
    }

    override fun getMessages(conversationId: String): Flow<List<Message>> {
        return messageDao.getMessagesForConversation(conversationId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getRecentMessagesSnapshot(conversationId: String, limit: Int): List<Message> {
        return messageDao.getRecentMessages(conversationId, limit)
            .reversed()
            .map { it.toDomain() }
    }

    override suspend fun createConversation(title: String): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        conversationDao.insertConversation(
            ConversationEntity(
                id = id,
                title = title,
                createdAt = now,
                updatedAt = now,
                messageCount = 0,
                summary = "",
                isPinned = false,
                tags = "[]"
            )
        )
        return id
    }

    override suspend fun saveMessage(message: Message) {
        messageDao.insertMessage(message.toEntity())
        conversationDao.incrementMessageCount(
            id = message.conversationId,
            timestamp = message.timestamp
        )
    }

    override suspend fun sendToLLM(
        conversationId: String,
        userMessage: String,
        contextMemories: List<Memory>
    ): Result<Message> {
        return try {
            // Build context: recent messages from this conversation
            val recentMessages = getRecentMessagesSnapshot(conversationId, 30)

            // Fetch settings
            val model = prefs.llmModel.first()
            val temperature = prefs.llmTemperature.first()
            val maxTokens = prefs.llmMaxTokens.first()
            val userName = prefs.userName.first()

            // Build the system prompt with memory injection
            val systemPrompt = SystemPromptBuilder.build(
                memories = contextMemories.map { it.content },
                userName = userName,
                currentTime = SimpleDateFormat("EEEE, MMM d yyyy HH:mm", Locale.getDefault())
                    .format(Date()),
                pluginCommands = pluginRegistry.buildSystemPromptSchema(),
                notificationsAvailable = HeritageNotificationListenerService.isServiceEnabled(context),
                accessibilityAvailable = HeritageAccessibilityService.instance != null,
                activeNotifications = if (HeritageNotificationListenerService.isServiceEnabled(context))
                    HeritageNotificationListenerService.instance?.getActiveNotificationsSummary() ?: ""
                else "",
                conversationSummary = if (contextMemories.isNotEmpty())
                    contextMemories.take(3).joinToString("; ") { it.content }
                else "",
                // Inject apps with package names so LLM uses exact packages
                // Format: "WhatsApp (com.whatsapp)" — LLM extracts package for direct launch
                installedApps = deviceControl.getInstalledApps()
                    .map { (name, pkg) -> "$name ($pkg)" }
            )

            // Build API messages list
            val apiMessages = buildList {
                add(ApiMessage(role = "system", content = systemPrompt))
                // Include conversation history
                recentMessages.filter { !it.isError }.forEach { msg ->
                    add(ApiMessage(role = msg.role.toApiRole(), content = msg.content))
                }
                // Ensure the current user message is last
                if (recentMessages.lastOrNull()?.content != userMessage) {
                    add(ApiMessage(role = "user", content = userMessage))
                }
            }

            val request = ChatRequest(
                model = model,
                messages = apiMessages,
                temperature = temperature.toDouble(),
                maxTokens = maxTokens
            )

            val response = llmApi.createChatCompletion(request)

            if (response.isSuccessful) {
                val body = response.body()
                val content = body?.choices?.firstOrNull()?.message?.content
                    ?: "I'm sorry, I couldn't generate a response."
                val tokens = body?.usage?.completionTokens ?: 0

                val assistantMessage = Message(
                    id = UUID.randomUUID().toString(),
                    conversationId = conversationId,
                    role = MessageRole.ASSISTANT,
                    content = content,
                    timestamp = System.currentTimeMillis(),
                    tokenCount = tokens,
                    model = body?.model ?: model
                )
                Result.success(assistantMessage)
            } else {
                val errorCode = response.code()
                // Try to get the actual error message from the response body
                val errorBody = runCatching {
                    response.errorBody()?.string()
                }.getOrNull() ?: ""
                
                val errorMessage = when (errorCode) {
                    401 -> "Invalid API key. Please check your settings."
                    404 -> if (errorBody.contains("model")) 
                        "AI model not found. Go to Settings and change the model."
                        else "Service endpoint not found (404). Check your provider settings."
                    429 -> "Rate limit exceeded. Please wait a moment."
                    500, 502, 503 -> "The AI service is temporarily unavailable."
                    else -> "Request failed (HTTP $errorCode). Please try again."
                }
                Result.failure(Exception(errorMessage))
            }
        } catch (e: java.net.UnknownHostException) {
            Result.failure(Exception("No internet connection. Please check your network."))
        } catch (e: java.net.SocketTimeoutException) {
            Result.failure(Exception("Request timed out. Please try again."))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "An unexpected error occurred."))
        }
    }

    override suspend fun updateConversationTitle(conversationId: String, title: String) {
        conversationDao.updateTitle(conversationId, title)
    }

    override suspend fun deleteConversation(conversationId: String) {
        messageDao.deleteMessagesForConversation(conversationId)
        conversationDao.deleteConversationById(conversationId)
    }

    override suspend fun searchMessages(query: String): List<Message> {
        return messageDao.searchMessages(query).map { it.toDomain() }
    }

    override suspend fun generateSummary(conversationId: String): Result<String> {
        return try {
            val messages = getRecentMessagesSnapshot(conversationId, 20)
            if (messages.isEmpty()) return Result.success("")

            val conversationText = messages.joinToString("\n") { msg ->
                "${msg.role.name}: ${msg.content}"
            }

            val model = prefs.llmModel.first()
            val request = ChatRequest(
                model = model,
                messages = listOf(
                    ApiMessage(
                        role = "user",
                        content = "Summarize this conversation in 1-2 sentences, " +
                                "focusing on the main topic and outcome:\n\n$conversationText"
                    )
                ),
                maxTokens = 100,
                temperature = 0.3
            )

            val response = llmApi.createChatCompletion(request)
            val summary = response.body()?.choices?.firstOrNull()?.message?.content ?: ""
            if (summary.isNotBlank()) {
                conversationDao.updateSummary(conversationId, summary)
            }
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
