package com.heritage.ai.plugin.plugins

import android.Manifest
import com.heritage.ai.plugin.HeritagePlugin
import com.heritage.ai.plugin.PluginContext
import com.heritage.ai.plugin.PluginResult
import com.heritage.ai.util.CommandAction
import com.heritage.ai.util.DeviceCommand
import com.heritage.ai.util.DeviceControlManager
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ────────────────────────────────────────────────────────────
 * BUILT-IN PLUGINS
 * ────────────────────────────────────────────────────────────
 * Reference implementations showing how core device capabilities
 * are expressed in the plugin architecture. Each delegates the
 * actual system call to [DeviceControlManager] to avoid duplicating
 * low-level Android API logic, while exposing itself uniformly
 * through the [HeritagePlugin] contract so third-party plugins
 * follow the same shape.
 */

@Singleton
class FlashlightPlugin @Inject constructor(
    private val deviceControl: DeviceControlManager
) : HeritagePlugin {

    override val id = "flashlight"
    override val displayName = "Flashlight"
    override val description = "Turns the camera flashlight on or off"
    override val requiredPermissions = listOf(Manifest.permission.CAMERA)

    override fun canHandle(input: String): Boolean {
        val lower = input.lowercase()
        return lower.contains("flashlight") || lower.contains("torch")
    }

    override suspend fun execute(context: PluginContext): PluginResult {
        val state = context.parameters["state"] ?: "toggle"
        val result = deviceControl.executeCommand(
            DeviceCommand(CommandAction.TOGGLE_FLASHLIGHT, mapOf("state" to state))
        )
        return PluginResult.Success(result)
    }

    override fun commandSchema(): String = """
        {"action": "TOGGLE_FLASHLIGHT", "params": {"state": "on|off"}} — Controls the flashlight
    """.trimIndent()
}

@Singleton
class AppLauncherPlugin @Inject constructor(
    private val deviceControl: DeviceControlManager
) : HeritagePlugin {

    override val id = "app_launcher"
    override val displayName = "App Launcher"
    override val description = "Opens any installed app by name"

    override fun canHandle(input: String): Boolean =
        input.lowercase().startsWith("open ") || input.lowercase().startsWith("launch ")

    override suspend fun execute(context: PluginContext): PluginResult {
        val appName = context.parameters["name"]
            ?: return PluginResult.Failure("No app name provided")
        val result = deviceControl.executeCommand(
            DeviceCommand(CommandAction.OPEN_APP, mapOf("name" to appName))
        )
        return if (result.startsWith("App") && result.contains("not found")) {
            PluginResult.Failure(result)
        } else {
            PluginResult.Success(result)
        }
    }

    override fun commandSchema(): String = """
        {"action": "OPEN_APP", "params": {"name": "<app name>"}} — Launches an installed app
    """.trimIndent()
}

@Singleton
class VolumePlugin @Inject constructor(
    private val deviceControl: DeviceControlManager
) : HeritagePlugin {

    override val id = "volume"
    override val displayName = "Volume Control"
    override val description = "Adjusts media, ring, or alarm volume"

    override fun canHandle(input: String): Boolean {
        val lower = input.lowercase()
        return lower.contains("volume") || lower.contains("mute") || lower.contains("silence")
    }

    override suspend fun execute(context: PluginContext): PluginResult {
        val level = context.parameters["level"] ?: "50"
        val stream = context.parameters["stream"] ?: "media"
        val result = deviceControl.executeCommand(
            DeviceCommand(CommandAction.SET_VOLUME, mapOf("level" to level, "stream" to stream))
        )
        return PluginResult.Success(result)
    }

    override fun commandSchema(): String = """
        {"action": "SET_VOLUME", "params": {"level": "0-100", "stream": "media|ring|alarm|notification"}} — Sets volume
    """.trimIndent()
}

@Singleton
class AlarmPlugin @Inject constructor(
    private val deviceControl: DeviceControlManager
) : HeritagePlugin {

    override val id = "alarm"
    override val displayName = "Alarms"
    override val description = "Sets alarms via the system clock app"

    override fun canHandle(input: String): Boolean =
        input.lowercase().let { it.contains("alarm") || it.contains("wake me") }

    override suspend fun execute(context: PluginContext): PluginResult {
        val hour = context.parameters["hour"]
            ?: return PluginResult.Failure("No hour specified")
        val minute = context.parameters["minute"] ?: "0"
        val message = context.parameters["message"] ?: "Heritage AI Alarm"
        val result = deviceControl.executeCommand(
            DeviceCommand(
                CommandAction.SET_ALARM,
                mapOf("hour" to hour, "minute" to minute, "message" to message)
            )
        )
        return PluginResult.Success(result)
    }

    override fun commandSchema(): String = """
        {"action": "SET_ALARM", "params": {"hour": "0-23", "minute": "0-59", "message": "<label>"}} — Sets a system alarm
    """.trimIndent()
}

@Singleton
class ConnectivityPlugin @Inject constructor(
    private val deviceControl: DeviceControlManager
) : HeritagePlugin {

    override val id = "connectivity"
    override val displayName = "Wi-Fi & Bluetooth"
    override val description = "Toggles Wi-Fi and Bluetooth radios"

    override fun canHandle(input: String): Boolean {
        val lower = input.lowercase()
        return lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("bluetooth")
    }

    override suspend fun execute(context: PluginContext): PluginResult {
        val isWifi = context.rawUserInput.lowercase().let { it.contains("wifi") || it.contains("wi-fi") }
        val state = context.parameters["state"] ?: "on"
        val action = if (isWifi) CommandAction.TOGGLE_WIFI else CommandAction.TOGGLE_BLUETOOTH
        val result = deviceControl.executeCommand(DeviceCommand(action, mapOf("state" to state)))
        return PluginResult.Success(result)
    }

    override fun commandSchema(): String = """
        {"action": "TOGGLE_WIFI", "params": {"state": "on|off"}} — Toggles Wi-Fi
        {"action": "TOGGLE_BLUETOOTH", "params": {"state": "on|off"}} — Toggles Bluetooth
    """.trimIndent()
}
