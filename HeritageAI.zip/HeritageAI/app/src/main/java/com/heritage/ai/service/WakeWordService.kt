package com.heritage.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.heritage.ai.MainActivity
import com.heritage.ai.R
import com.heritage.ai.util.AudioFeatureExtractor
import com.heritage.ai.util.WakeWordDetector
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * WakeWordService — always-on background listener.
 *
 * BUGFIX / REDESIGN (beta feedback): the previous implementation looped
 * Android's SpeechRecognizer continuously, which defaults to CLOUD speech
 * recognition — meaning "always on" meant constant background data usage
 * and battery drain, not something viable to actually leave running.
 *
 * This version runs real on-device wake-word detection: continuous 16kHz
 * audio capture feeds a 3-stage TFLite pipeline (melspectrogram ->
 * embeddings -> the trained "Hey Heritage" classifier), entirely local,
 * no network involved at all until the wake word is actually detected.
 * The melspectrogram/embedding stages are openWakeWord's shared, generic
 * models — the classifier is the one actually trained for this app.
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "heritage_wake_channel"
        const val NOTIF_ID = 1002
        const val ACTION_WAKE_WORD_DETECTED = "com.heritage.ai.WAKE_WORD_DETECTED"

        private const val SAMPLE_RATE = 16000
        private const val READ_CHUNK_SAMPLES = 1280 // 80ms @ 16kHz — matches the model pipeline's native chunk size

        // Confidence threshold for a detection. 0.5 is openWakeWord's
        // typical default — raise it if false-triggers happen too often,
        // lower it if genuine "Hey Heritage" isn't being caught.
        private const val DETECTION_THRESHOLD = 0.5f

        // After a detection, pause this long before checking again so the
        // same utterance's lingering embeddings don't immediately re-fire.
        private const val COOLDOWN_MS = 2000L
    }

    private val scope = CoroutineScope(Dispatchers.Default)
    private var listenJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var featureExtractor: AudioFeatureExtractor? = null
    private var detector: WakeWordDetector? = null
    private var isRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            isRunning = true
            startListening()
        }
        return START_STICKY
    }

    private fun startListening() {
        listenJob = scope.launch {
            try {
                featureExtractor = AudioFeatureExtractor(applicationContext)
                detector = WakeWordDetector(applicationContext)
            } catch (e: Exception) {
                // Model files missing/corrupt or interpreter init failed —
                // stop cleanly rather than crash the foreground service.
                stopSelf()
                return@launch
            }

            val minBufferSize = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBufferSize <= 0) {
                stopSelf()
                return@launch
            }
            val bufferSize = maxOf(minBufferSize, READ_CHUNK_SAMPLES * 4)

            val record = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
            } catch (e: SecurityException) {
                stopSelf()
                return@launch
            }

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                record.release()
                stopSelf()
                return@launch
            }

            audioRecord = record
            record.startRecording()

            val readBuffer = ShortArray(READ_CHUNK_SAMPLES)

            while (isActive && isRunning) {
                val samplesRead = record.read(readBuffer, 0, readBuffer.size)
                if (samplesRead <= 0) continue

                val chunk = if (samplesRead == readBuffer.size) readBuffer else readBuffer.copyOf(samplesRead)
                featureExtractor?.processAudio(chunk)

                val features = featureExtractor?.getFeatures(16) ?: continue
                val score = detector?.predict(features) ?: continue

                if (score >= DETECTION_THRESHOLD) {
                    onWakeWordDetected()
                    delay(COOLDOWN_MS)
                }
            }
        }
    }

    private fun onWakeWordDetected() {
        val intent = Intent(ACTION_WAKE_WORD_DETECTED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)

        val openApp = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("auto_start_voice", true)
        }
        startActivity(openApp)
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Wake Word Detection", NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = "Listening for 'Hey Heritage' in the background"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_heritage_logo)
            .setContentTitle("Heritage AI — Listening")
            .setContentText("Say 'Hey Heritage' to activate")
            .setContentIntent(pending)
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        listenJob?.cancel()
        try {
            audioRecord?.stop()
        } catch (_: Exception) {}
        audioRecord?.release()
        audioRecord = null
        featureExtractor?.close()
        detector?.close()
        super.onDestroy()
    }
}
