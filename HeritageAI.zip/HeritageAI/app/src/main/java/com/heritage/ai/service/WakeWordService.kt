package com.heritage.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.heritage.ai.MainActivity
import com.heritage.ai.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * WakeWordService — always-on background listener.
 *
 * Strategy: Uses Android's SpeechRecognizer in a continuous loop.
 * After each recognition session ends (result, error, or timeout),
 * it waits 1 second then starts a fresh session automatically.
 * When the user says "Hey Heritage" or "Heritage", it broadcasts
 * ACTION_WAKE_WORD_DETECTED which opens the main voice overlay.
 *
 * Battery impact: Medium. The recognizer is cloud-based so it uses
 * both CPU and network. Users can toggle this in Settings.
 * Recommended: only enable when you actually want hands-free use.
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "heritage_wake_channel"
        const val NOTIF_ID = 1002
        const val ACTION_WAKE_WORD_DETECTED = "com.heritage.ai.WAKE_WORD_DETECTED"

        // Words that trigger Heritage AI — flexible matching
        private val WAKE_PHRASES = listOf(
            "hey heritage",
            "heritage",
            "hey harriet",   // Common mishearing of "heritage"
            "hey harriet age",
            "heritage ai",
            "ok heritage",
            "okay heritage"
        )
    }

    private val scope = CoroutineScope(Dispatchers.Main)
    private var recognizerJob: Job? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            isRunning = true
            startContinuousListening()
        }
        return START_STICKY
    }

    /**
     * Runs a continuous loop:
     * Listen → check for wake phrase → rest 1s → listen again
     */
    private fun startContinuousListening() {
        recognizerJob = scope.launch {
            while (isActive && isRunning) {
                listenOnce()
                // Brief pause between sessions to avoid hammering the mic
                delay(1000L)
            }
        }
    }

    private suspend fun listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        // Destroy any previous instance before creating new one
        destroyRecognizer()

        var sessionComplete = false

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

            override fun onResults(results: android.os.Bundle?) {
                val matches = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?: emptyList()

                // Check if any recognised phrase contains a wake word
                val triggered = matches.any { result ->
                    val lower = result.lowercase().trim()
                    WAKE_PHRASES.any { phrase -> lower.contains(phrase) }
                }

                if (triggered) {
                    onWakeWordDetected()
                }
                sessionComplete = true
            }

            override fun onError(error: Int) {
                // Errors are expected (silence, timeout, etc.) — just restart
                sessionComplete = true
            }

            override fun onPartialResults(partialResults: android.os.Bundle?) {
                // Check partial results too for faster response
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.lowercase() ?: return

                if (WAKE_PHRASES.any { partial.contains(it) }) {
                    onWakeWordDetected()
                    sessionComplete = true
                    destroyRecognizer()
                }
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            // Short session — just listening for the trigger phrase
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }

        speechRecognizer?.startListening(intent)

        // Wait for session to finish (max 10 seconds)
        var waited = 0
        while (!sessionComplete && waited < 100) {
            delay(100L)
            waited++
        }
    }

    private fun onWakeWordDetected() {
        // Broadcast to MainActivity / VoiceOrchestrator
        val intent = Intent(ACTION_WAKE_WORD_DETECTED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)

        // Also bring the app to foreground
        val openApp = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("auto_start_voice", true)
        }
        startActivity(openApp)
    }

    private fun destroyRecognizer() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Wake Word Detection", NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = "Listening for 'Hey Heritage' in the background"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_heritage_logo)
            .setContentTitle("Heritage AI — Listening")
            .setContentText("Say 'Hey Heritage' to activate")
            .setContentIntent(pending)
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        recognizerJob?.cancel()
        destroyRecognizer()
        super.onDestroy()
    }
}
