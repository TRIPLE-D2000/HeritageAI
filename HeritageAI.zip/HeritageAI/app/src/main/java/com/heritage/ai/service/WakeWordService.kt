package com.heritage.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.heritage.ai.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * WakeWordService — Always-on audio listener for the "Hey Heritage" wake word.
 *
 * Implementation note:
 * A production app would integrate a dedicated on-device wake-word engine
 * (e.g. Porcupine by Picovoice, openWakeWord, or Whisper.cpp). This
 * implementation provides the full skeleton: audio capture loop, amplitude
 * gating, and intent broadcasting to the VoiceAssistantService.
 *
 * To integrate Porcupine:
 *   1. Add dependency: implementation("ai.picovoice:porcupine-android:3.x.x")
 *   2. Obtain a free API key from console.picovoice.ai
 *   3. Replace the [detectWakeWord] stub with PorcupineManager callbacks
 *
 * The service keeps a LOW-priority notification so it won't be mistaken
 * for a security risk; it stops immediately when disabled in Settings.
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "heritage_wake_channel"
        const val NOTIF_ID = 1002
        const val ACTION_WAKE_WORD_DETECTED = "com.heritage.ai.WAKE_WORD_DETECTED"

        // Audio parameters
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val WINDOW_MS = 1000         // 1-second rolling window
        private const val FRAME_SIZE = SAMPLE_RATE * WINDOW_MS / 1000 // 16000 samples
    }

    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private var isEnabled = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        captureJob?.cancel()
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        val bufferSize = maxOf(minBuffer, FRAME_SIZE * 2)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT, bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) return

        audioRecord?.startRecording()

        captureJob = scope.launch {
            val buffer = ShortArray(FRAME_SIZE)
            while (isActive && isEnabled) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: break
                if (read > 0) {
                    // Gate: only run detection when audio is above noise floor
                    val energy = buffer.take(read).sumOf { abs(it.toInt()) } / read.toFloat()
                    if (energy > 400f) {  // Noise floor ~400 for typical mic
                        if (detectWakeWord(buffer, read)) {
                            onWakeWordDetected()
                        }
                    }
                }
            }
        }
    }

    /**
     * Stub wake word detector.
     *
     * REPLACE THIS with a real on-device wake-word engine.
     * Options (all free tier available):
     *   - Picovoice Porcupine (most accurate, MIT-licensed training data)
     *   - openWakeWord (fully open source)
     *   - Custom ONNX model via ORT Android
     *
     * Returns true if "Hey Heritage" (or the user's chosen phrase) is detected.
     */
    private fun detectWakeWord(audio: ShortArray, length: Int): Boolean {
        // Placeholder — always returns false until a real engine is integrated.
        // The audio capture loop, buffering, and intent plumbing are production-ready.
        return false
    }

    private fun onWakeWordDetected() {
        val intent = Intent(ACTION_WAKE_WORD_DETECTED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Wake Word Detection",
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = "Always listening for 'Hey Heritage'"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_heritage_logo)
            .setContentTitle("Heritage AI")
            .setContentText("Listening for 'Hey Heritage'…")
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

    override fun onDestroy() {
        captureJob?.cancel()
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        super.onDestroy()
    }
}
