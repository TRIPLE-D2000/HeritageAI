package com.heritage.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.heritage.ai.MainActivity
import com.heritage.ai.R
import com.heritage.ai.util.AudioFeatureExtractor
import com.heritage.ai.util.WakeWordDetector
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * WakeWordService — always-on background listener.
 *
 * BUGFIX / REDESIGN (beta feedback): the previous implementation looped
 * Android's SpeechRecognizer continuously, which defaults to CLOUD speech
 * recognition — meaning "always on" meant constant background data usage
 * and battery drain, not something viable to actually leave running.
 *
 * This version runs real on-device wake-word detection: continuous 16kHz
 * audio capture feeds a 3-stage TFLite pipeline (melspectrogram ->
 * embeddings -> the trained "Hey Heritage" classifier), entirely local,
 * no network involved at all until the wake word is actually detected.
 * The melspectrogram/embedding stages are openWakeWord's shared, generic
 * models — the classifier is the one actually trained for this app.
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    companion object {
        const val CHANNEL_ID = "heritage_wake_channel"
        const val NOTIF_ID = 1002
        const val ACTION_WAKE_WORD_DETECTED = "com.heritage.ai.WAKE_WORD_DETECTED"

        private const val SAMPLE_RATE = 16000
        private const val READ_CHUNK_SAMPLES = 1280 // 80ms @ 16kHz — matches the model pipeline's native chunk size

        // Confidence threshold for a detection. Started at openWakeWord's
        // typical default (0.5); dropped to 0.3 after zero detections in
        // real testing — that result meant "meaningfully too high," not
        // "slightly off," so this is a bigger step down, not a nudge.
        private const val DETECTION_THRESHOLD = 0.3f

        // After a detection, pause this long before checking again so the
        // same utterance's lingering embeddings don't immediately re-fire.
        private const val COOLDOWN_MS = 2000L

        // If no successful mic read happens for this long, the capture
        // loop is alive but genuinely stuck — surface that visibly via the
        // notification instead of it only being discoverable through logs.
        private const val STALL_THRESHOLD_MS = 5 * 60 * 1000L
    }

    private val scope = CoroutineScope(Dispatchers.Default)
    private var listenJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var featureExtractor: AudioFeatureExtractor? = null
    private var detector: WakeWordDetector? = null
    private var isRunning = false
    private var lastGoodReadTime = 0L
    private var stalledNotificationShown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            createChannel()
            // Explicitly specifying the service type here (not just in the
            // manifest) — on modern Android, a mismatch between the
            // declared type and what's passed at runtime can cause the
            // foreground promotion to silently fail rather than throw,
            // which would explain zero signal at all: no chime, no
            // notification, nothing — because we'd never even reach
            // onStartCommand's logic.
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIF_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
            Log.d("HeritageWakeWord", "onCreate() completed, startForeground() succeeded")
        } catch (e: Exception) {
            Log.e("HeritageWakeWord", "onCreate() FAILED: ${e.javaClass.simpleName}: ${e.message}", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("HeritageWakeWord", "onStartCommand() called, isRunning=$isRunning")
        if (!isRunning) {
            isRunning = true
            startListening()
        }
        return START_STICKY
    }

    private fun startListening() {
        Log.d("HeritageWakeWord", "startListening() called — beginning setup")
        listenJob = scope.launch {
            try {
                featureExtractor = AudioFeatureExtractor(applicationContext)
                detector = WakeWordDetector(applicationContext)
                Log.d("HeritageWakeWord", "TFLite models loaded successfully")
            } catch (e: Exception) {
                // Model files missing/corrupt or interpreter init failed —
                // stop cleanly rather than crash the foreground service.
                // isRunning MUST reset here — otherwise onStartCommand's
                // guard silently skips every future attempt within the
                // same process lifetime, with zero new log output.
                Log.e("HeritageWakeWord", "Model loading FAILED: ${e.javaClass.simpleName}: ${e.message}", e)
                isRunning = false
                stopSelf()
                return@launch
            }

            val minBufferSize = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBufferSize <= 0) {
                Log.e("HeritageWakeWord", "getMinBufferSize returned $minBufferSize — device doesn't support this audio config")
                isRunning = false
                stopSelf()
                return@launch
            }
            val bufferSize = maxOf(minBufferSize, READ_CHUNK_SAMPLES * 4)

            val record = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
            } catch (e: SecurityException) {
                Log.e("HeritageWakeWord", "AudioRecord creation FAILED (permission?): ${e.message}", e)
                isRunning = false
                stopSelf()
                return@launch
            }

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                Log.e("HeritageWakeWord", "AudioRecord failed to initialize (state=${record.state})")
                isRunning = false
                record.release()
                stopSelf()
                return@launch
            }

            audioRecord = record
            record.startRecording()
            Log.d("HeritageWakeWord", "AudioRecord started, entering capture loop")
            playStartChime()
            lastGoodReadTime = System.currentTimeMillis()

            val readBuffer = ShortArray(READ_CHUNK_SAMPLES)
            var chunkCount = 0

            try {
                while (isActive && isRunning) {
                    val samplesRead = record.read(readBuffer, 0, readBuffer.size)
                    if (samplesRead <= 0) {
                        Log.w("HeritageWakeWord", "AudioRecord.read returned $samplesRead — mic capture may not be working")
                        checkForStall()
                        continue
                    }

                    lastGoodReadTime = System.currentTimeMillis()
                    if (stalledNotificationShown) {
                        stalledNotificationShown = false
                        updateNotification(stalled = false)
                    }

                    val chunk = if (samplesRead == readBuffer.size) readBuffer else readBuffer.copyOf(samplesRead)

                    chunkCount++
                    if (chunkCount % 25 == 0) { // ~every 2s, so this doesn't spam logcat
                        val maxAmplitude = chunk.maxOf { kotlin.math.abs(it.toInt()) }
                        Log.d("HeritageWakeWord", "Mic check: chunk #$chunkCount, max amplitude=$maxAmplitude (near 0 = silence/no real audio reaching the buffer)")
                    }

                    featureExtractor?.processAudio(chunk)

                    val features = featureExtractor?.getFeatures(16) ?: continue
                    val score = detector?.predict(features) ?: continue

                    Log.d("HeritageWakeWord", "score=$score")

                    if (score >= DETECTION_THRESHOLD) {
                        Log.i("HeritageWakeWord", "DETECTED at score=$score")
                        onWakeWordDetected()
                        delay(COOLDOWN_MS)
                    }
                }
            } catch (e: Exception) {
                // Catches anything NOT already handled above (a crash deep
                // inside TFLite inference, for example) — without this, an
                // unexpected exception here would kill the coroutine with
                // zero visible signal, the exact "nothing, no matter what"
                // symptom this whole diagnostic pass is trying to prevent.
                Log.e("HeritageWakeWord", "Capture loop crashed: ${e.javaClass.simpleName}: ${e.message}", e)
                isRunning = false
                updateNotification(stalled = true, text = "Stopped unexpectedly — reopen Settings to restart")
            }
        }
    }

    /** Short, quiet confirmation tone — audible proof the service actually reached a running state. */
    private fun playStartChime() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 150)
            scope.launch {
                delay(200)
                toneGen.release()
            }
        } catch (_: Exception) {
            // Non-critical — a missing chime shouldn't affect the actual feature.
        }
    }

    /** Called when a read fails — escalates from a log warning to a visible notification if it's been stuck a while. */
    private fun checkForStall() {
        if (!stalledNotificationShown && System.currentTimeMillis() - lastGoodReadTime > STALL_THRESHOLD_MS) {
            stalledNotificationShown = true
            Log.e("HeritageWakeWord", "STALLED — no successful mic read in over 5 minutes")
            updateNotification(stalled = true, text = "Not receiving audio — mic may be blocked or in use elsewhere")
        }
    }

    private fun updateNotification(stalled: Boolean, text: String? = null) {
        val notification = if (stalled) buildNotification(warningText = text) else buildNotification()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification)
    }

    private fun onWakeWordDetected() {
        val intent = Intent(ACTION_WAKE_WORD_DETECTED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)

        val openApp = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("auto_start_voice", true)
        }
        startActivity(openApp)
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Wake Word Detection", NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = "Listening for 'Hey Heritage' in the background"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(warningText: String? = null): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentIntent(pending)
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)

        return if (warningText != null) {
            builder
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle("Heritage AI — Wake word issue")
                .setContentText(warningText)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT) // stalls deserve more visibility than the normal quiet listening state
                .build()
        } else {
            builder
                .setSmallIcon(R.drawable.ic_heritage_logo)
                .setContentTitle("Heritage AI — Ambient Mode")
                .setContentText("Say 'Hey Heritage' to activate")
                .build()
        }
    }

    override fun onDestroy() {
        isRunning = false
        listenJob?.cancel()
        try {
            audioRecord?.stop()
        } catch (_: Exception) {}
        audioRecord?.release()
        audioRecord = null
        featureExtractor?.close()
        detector?.close()
        super.onDestroy()
    }
}
