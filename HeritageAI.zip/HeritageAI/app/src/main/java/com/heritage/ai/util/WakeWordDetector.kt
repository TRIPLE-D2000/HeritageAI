package com.heritage.ai.util

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import java.nio.FloatBuffer

/**
 * Wraps the custom-trained wake-word classifier (hey_heritage.onnx,
 * trained via Outspoken). Takes the [1, 16, 96] feature window produced by
 * [AudioFeatureExtractor] and returns a 0-1 confidence score.
 *
 * Input/output names and shapes were confirmed directly via onnxruntime
 * inspection of the actual file (input "onnx::Flatten_0" shape [1,16,96],
 * output "39" shape [1,1]) rather than assumed from the architecture alone
 * — but the exact name is still looked up at runtime below rather than
 * hardcoded, since that inspection is a point-in-time fact about one file,
 * not a guarantee for every export.
 */
class WakeWordDetector(context: Context, modelAssetName: String = "hey_heritage.onnx") {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String

    init {
        val modelBytes = context.assets.open(modelAssetName).use { it.readBytes() }
        session = env.createSession(modelBytes, OrtSession.SessionOptions())
        inputName = session.inputNames.iterator().next()
    }

    /** [features] must be shape [16][96], as returned by AudioFeatureExtractor.getFeatures(16). */
    fun predict(features: Array<FloatArray>): Float {
        val inputData = FloatArray(16 * 96)
        features.forEachIndexed { fi, frame -> frame.forEachIndexed { bi, v -> inputData[fi * 96 + bi] = v } }

        val inputTensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(inputData), longArrayOf(1, 16, 96))

        return inputTensor.use { tensor ->
            session.run(mapOf(inputName to tensor)).use { results ->
                val outputTensor = results.iterator().next().value as OnnxTensor
                outputTensor.floatBuffer.get(0)
            }
        }
    }

    fun close() = session.close()
}
