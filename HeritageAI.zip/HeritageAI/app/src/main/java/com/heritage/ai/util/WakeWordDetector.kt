package com.heritage.ai.util

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Wraps the custom-trained wake-word classifier (hey_heritage.tflite,
 * trained via Outspoken). Takes the [1, 16, 96] feature window produced by
 * [AudioFeatureExtractor] and returns a 0-1 confidence score.
 */
class WakeWordDetector(context: Context, modelAssetName: String = "hey_heritage.tflite") {

    private val interpreter: Interpreter = Interpreter(loadModelFile(context, modelAssetName))

    private fun loadModelFile(context: Context, assetName: String): MappedByteBuffer {
        val afd = context.assets.openFd(assetName)
        FileInputStream(afd.fileDescriptor).use { input ->
            return input.channel.map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.declaredLength)
        }
    }

    /** [features] must be shape [16][96], as returned by AudioFeatureExtractor.getFeatures(16). */
    fun predict(features: Array<FloatArray>): Float {
        val inputBuffer = ByteBuffer.allocateDirect(16 * 96 * 4).order(ByteOrder.nativeOrder())
        features.forEach { frame -> frame.forEach { inputBuffer.putFloat(it) } }
        inputBuffer.rewind()

        val outputBuffer = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
        interpreter.run(inputBuffer, outputBuffer)
        outputBuffer.rewind()
        return outputBuffer.float
    }

    fun close() = interpreter.close()
}
