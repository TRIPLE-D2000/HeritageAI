package com.heritage.ai.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import com.heritage.ai.MainActivity
import com.heritage.ai.R
import dagger.hilt.android.AndroidEntryPoint
import kotlin.math.abs

/**
 * FloatingBubbleService — draws a persistent floating circle over all apps.
 *
 * The bubble:
 * - Supports drag-to-reposition with snap-to-edges animation
 * - Single tap → opens Heritage AI main activity
 * - Long press → dismisses the bubble until next session
 *
 * Requires SYSTEM_ALERT_WINDOW permission (granted by user via Settings).
 */
@AndroidEntryPoint
class FloatingBubbleService : Service() {

    companion object {
        const val CHANNEL_ID = "heritage_bubble_channel"
        const val NOTIF_ID = 1003
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var params: WindowManager.LayoutParams? = null

    // Drag state
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var lastTouchTime = 0L
    private var isDragging = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(NOTIF_ID,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_heritage_logo)
                .setContentTitle("Heritage AI")
                .setContentText("Bubble active — tap to open")
                .setSilent(true)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build()
        )
        createBubble()
    }

    private fun createBubble() {
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val bubbleSize = (56 * resources.displayMetrics.density).toInt()

        params = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth - bubbleSize - 16
            y = (screenHeight * 0.4).toInt()
        }

        bubbleView = ImageView(this).apply {
            setImageResource(R.drawable.ic_heritage_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.9f
            elevation = 12f
        }

        bubbleView?.setOnTouchListener(bubbleTouchListener())
        windowManager.addView(bubbleView, params)
    }

    private fun bubbleTouchListener() = View.OnTouchListener { _, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = params?.x ?: 0
                initialY = params?.y ?: 0
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                lastTouchTime = System.currentTimeMillis()
                isDragging = false
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY
                if (abs(dx) > 8 || abs(dy) > 8) isDragging = true
                if (isDragging) {
                    params?.x = initialX + dx.toInt()
                    params?.y = initialY + dy.toInt()
                    windowManager.updateViewLayout(bubbleView, params)
                }
                true
            }
            MotionEvent.ACTION_UP -> {
                if (!isDragging) {
                    val elapsed = System.currentTimeMillis() - lastTouchTime
                    if (elapsed > 500) {
                        // Long press — dismiss
                        stopSelf()
                    } else {
                        // Tap — open Heritage AI
                        val intent = Intent(this, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        }
                        startActivity(intent)
                    }
                } else {
                    snapToEdge()
                }
                true
            }
            else -> false
        }
    }

    /** Snaps the bubble to the nearest screen edge for a clean look. */
    private fun snapToEdge() {
        val screenWidth = resources.displayMetrics.widthPixels
        val bubbleSize = (56 * resources.displayMetrics.density).toInt()
        val currentX = params?.x ?: 0

        val targetX = if (currentX < screenWidth / 2) 16
        else screenWidth - bubbleSize - 16

        params?.x = targetX
        windowManager.updateViewLayout(bubbleView, params)
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Floating Bubble", NotificationManager.IMPORTANCE_MIN
        ).apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        bubbleView?.let { windowManager.removeView(it) }
        bubbleView = null
        super.onDestroy()
    }
}
