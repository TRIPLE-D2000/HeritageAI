package com.heritage.ai.util

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.view.WindowManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DeviceControlManager — executes parsed device commands.
 *
 * Handles: flashlight, Wi-Fi, Bluetooth, volume, brightness,
 *          alarms, app launching, Do-Not-Disturb.
 */
@Singleton
class DeviceControlManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var flashlightOn = false
    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }
    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    private val notificationManager by lazy {
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    /** Execute a parsed [DeviceCommand]. Returns a human-readable result. */
    suspend fun executeCommand(command: DeviceCommand): String = withContext(Dispatchers.IO) {
        runCatching {
            when (command.action) {
                CommandAction.TOGGLE_FLASHLIGHT -> toggleFlashlight(command.params)
                CommandAction.SET_VOLUME -> setVolume(command.params)
                CommandAction.SET_BRIGHTNESS -> setBrightness(command.params)
                CommandAction.TOGGLE_WIFI -> toggleWifi(command.params)
                CommandAction.TOGGLE_BLUETOOTH -> toggleBluetooth(command.params)
                CommandAction.OPEN_APP -> openApp(command.params)
                CommandAction.SET_ALARM -> setAlarm(command.params)
                CommandAction.SET_DND -> setDoNotDisturb(command.params)
                CommandAction.TAKE_SCREENSHOT -> "Screenshot: use MediaProjection API (requires user permission each time)"
                CommandAction.SEND_SMS -> "SMS sending: use an explicit Intent to the SMS app for safety"
                CommandAction.READ_NOTIFICATIONS -> {
                    val svc = com.heritage.ai.service.HeritageNotificationListenerService.instance
                    svc?.getActiveNotificationsSummary() ?: "Notification listener is not enabled. Please grant access in Settings."
                }
                CommandAction.UNKNOWN -> "Unknown command"
            }
        }.getOrElse { "Command failed: ${it.message}" }
    }

    // ── Flashlight ─────────────────────────────────
    private fun toggleFlashlight(params: Map<String, String>): String {
        val state = params["state"]?.lowercase()
        val targetOn = when (state) {
            "on", "true", "1" -> true
            "off", "false", "0" -> false
            else -> !flashlightOn  // Toggle if no explicit state
        }
        val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flash available on this device"

        cameraManager.setTorchMode(cameraId, targetOn)
        flashlightOn = targetOn
        return if (targetOn) "Flashlight turned on" else "Flashlight turned off"
    }

    // ── Volume ─────────────────────────────────────
    private fun setVolume(params: Map<String, String>): String {
        val level = params["level"]?.toIntOrNull()?.coerceIn(0, 100)
            ?: return "Please specify a volume level (0-100)"
        val stream = when (params["stream"]?.lowercase()) {
            "media", "music" -> AudioManager.STREAM_MUSIC
            "ring", "ringtone" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "notification" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        val max = audioManager.getStreamMaxVolume(stream)
        val scaled = (level / 100.0 * max).toInt()
        audioManager.setStreamVolume(stream, scaled, AudioManager.FLAG_SHOW_UI)
        return "Volume set to $level%"
    }

    // ── Brightness ─────────────────────────────────
    private fun setBrightness(params: Map<String, String>): String {
        val level = params["level"]?.toIntOrNull()?.coerceIn(0, 100)
            ?: return "Please specify brightness level (0-100)"
        if (!Settings.System.canWrite(context)) {
            return "Brightness control requires 'Modify System Settings' permission. Please grant it in Settings."
        }
        val scaled = (level / 100.0 * 255).toInt()
        Settings.System.putInt(
            context.contentResolver,
            Settings.System.SCREEN_BRIGHTNESS,
            scaled
        )
        Settings.System.putInt(
            context.contentResolver,
            Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        return "Brightness set to $level%"
    }

    // ── Wi-Fi ──────────────────────────────────────
    private fun toggleWifi(params: Map<String, String>): String {
        // On Android 10+ apps can't toggle Wi-Fi directly — open the panel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val panelIntent = Intent(Settings.Panel.ACTION_WIFI).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(panelIntent)
            return "Opening Wi-Fi settings panel"
        }
        @Suppress("DEPRECATION")
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        val enable = params["state"]?.lowercase() == "on"
        @Suppress("DEPRECATION")
        wifiManager.isWifiEnabled = enable
        return if (enable) "Wi-Fi turned on" else "Wi-Fi turned off"
    }

    // ── Bluetooth ──────────────────────────────────
    private fun toggleBluetooth(params: Map<String, String>): String {
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val btAdapter: BluetoothAdapter? = btManager.adapter
            ?: return "Bluetooth is not supported on this device"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ — must use settings panel
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return "Opening Bluetooth settings"
        }

        val enable = params["state"]?.lowercase() == "on"
        if (enable) {
            @Suppress("DEPRECATION")
            btAdapter?.enable()
        } else {
            @Suppress("DEPRECATION")
            btAdapter?.disable()
        }
        return if (enable) "Bluetooth turning on" else "Bluetooth turning off"
    }

    // ── App Launcher (improved fuzzy matching) ────
    private fun openApp(params: Map<String, String>): String {
        val appName = (params["name"] ?: params["package"] ?: return "Please specify an app name")
            .trim()

        // 1. Try exact package name first (fastest)
        context.packageManager.getLaunchIntentForPackage(appName)?.let { intent ->
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Opened $appName"
        }

        val installed = context.packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val query = appName.lowercase().trim()

        // 2. Exact label match (case-insensitive)
        installed.firstOrNull { app ->
            context.packageManager.getApplicationLabel(app).toString()
                .lowercase() == query
        }?.let { return launchApp(it) }

        // 3. Label starts-with match  
        installed.firstOrNull { app ->
            context.packageManager.getApplicationLabel(app).toString()
                .lowercase().startsWith(query)
        }?.let { return launchApp(it) }

        // 4. Label contains match (broadest — catches "WhatsApp" when user says "whats app")
        installed.firstOrNull { app ->
            val label = context.packageManager.getApplicationLabel(app).toString().lowercase()
            label.contains(query) || query.contains(label)
        }?.let { return launchApp(it) }

        // 5. Word-by-word partial match (catches "Spotify" when user says "music")
        val words = query.split(" ").filter { it.length > 2 }
        if (words.isNotEmpty()) {
            installed.firstOrNull { app ->
                val label = context.packageManager.getApplicationLabel(app).toString().lowercase()
                words.any { word -> label.contains(word) }
            }?.let { return launchApp(it) }
        }

        return "I couldn't find an app called '$appName' on your phone. " +
               "Try using the exact app name as it appears on your home screen."
    }

    private fun launchApp(app: android.content.pm.ApplicationInfo): String {
        val intent = context.packageManager
            .getLaunchIntentForPackage(app.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return "Found the app but it has no launch screen."
        context.startActivity(intent)
        return "Opening ${context.packageManager.getApplicationLabel(app)}"
    }

    // ── Alarms ─────────────────────────────────────
    private fun setAlarm(params: Map<String, String>): String {
        val hour = params["hour"]?.toIntOrNull() ?: return "Please specify an hour"
        val minute = params["minute"]?.toIntOrNull() ?: 0
        val message = params["message"] ?: params["label"] ?: "Heritage AI Alarm"

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        context.startActivity(intent)

        val period = if (hour < 12) "AM" else "PM"
        val displayHour = if (hour % 12 == 0) 12 else hour % 12
        val displayMin = minute.toString().padStart(2, '0')
        return "Alarm set for $displayHour:$displayMin $period — \"$message\""
    }

    // ── Do Not Disturb ─────────────────────────────
    private fun setDoNotDisturb(params: Map<String, String>): String {
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return "Please grant Do Not Disturb access in settings"
        }
        val enable = params["state"]?.lowercase() != "off"
        notificationManager.setInterruptionFilter(
            if (enable) NotificationManager.INTERRUPTION_FILTER_NONE
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return if (enable) "Do Not Disturb enabled" else "Do Not Disturb disabled"
    }

    /** Returns list of installed app names (for autocomplete/display). */
    fun getInstalledApps(): List<Pair<String, String>> {
        return context.packageManager
            .getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { app ->
                context.packageManager.getLaunchIntentForPackage(app.packageName) != null
            }
            .map { app ->
                val label = context.packageManager.getApplicationLabel(app).toString()
                label to app.packageName
            }
            .sortedBy { it.first }
    }
}
