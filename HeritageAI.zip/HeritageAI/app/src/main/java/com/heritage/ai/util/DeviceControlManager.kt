package com.heritage.ai.util

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DeviceControlManager — executes parsed device commands.
 *
 * App launching uses a 6-level fuzzy matching system so that
 * "Open TikTok", "Open Facebook", "Open Camera" etc all work
 * reliably regardless of the app's internal package name.
 */
@Singleton
class DeviceControlManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var flashlightOn = false

    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }
    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    private val notificationManager by lazy {
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    suspend fun executeCommand(command: DeviceCommand): String = withContext(Dispatchers.IO) {
        runCatching {
            when (command.action) {
                CommandAction.TOGGLE_FLASHLIGHT -> toggleFlashlight(command.params)
                CommandAction.SET_VOLUME        -> setVolume(command.params)
                CommandAction.SET_BRIGHTNESS    -> setBrightness(command.params)
                CommandAction.TOGGLE_WIFI       -> toggleWifi(command.params)
                CommandAction.TOGGLE_BLUETOOTH  -> toggleBluetooth(command.params)
                CommandAction.OPEN_APP          -> openApp(command.params)
                CommandAction.SET_ALARM         -> setAlarm(command.params)
                CommandAction.SET_DND           -> setDoNotDisturb(command.params)
                CommandAction.TAKE_SCREENSHOT   ->
                    "Screenshots require a system permission dialog each time. Use Power + Volume Down for now."
                CommandAction.SEND_SMS          -> sendSms(command.params)
                CommandAction.RUN_ROUTINE -> {
                    val routineName = command.params["name"] ?: ""
                    "Routine '$routineName' triggered. Check the Routines screen via the ☰ menu."
                }
                CommandAction.READ_NOTIFICATIONS -> {
                    val svc = com.heritage.ai.service.HeritageNotificationListenerService.instance
                    svc?.getActiveNotificationsSummary()
                        ?: "Notification listener is not enabled. Grant access in Settings."
                }
                CommandAction.UNKNOWN -> "Unknown command."
            }
        }.getOrElse { "Command failed: ${it.message}" }
    }

    // ── Flashlight ─────────────────────────────────
    private fun toggleFlashlight(params: Map<String, String>): String {
        val state = params["state"]?.lowercase()
        val targetOn = when (state) {
            "on", "true", "1"   -> true
            "off", "false", "0" -> false
            else                -> !flashlightOn
        }
        val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flashlight available on this device."
        cameraManager.setTorchMode(cameraId, targetOn)
        flashlightOn = targetOn
        return if (targetOn) "Flashlight turned on." else "Flashlight turned off."
    }

    // ── Volume ─────────────────────────────────────
    private fun setVolume(params: Map<String, String>): String {
        val level = params["level"]?.toIntOrNull()?.coerceIn(0, 100)
            ?: return "Please specify a volume level (0–100)."
        val stream = when (params["stream"]?.lowercase()) {
            "media", "music"      -> AudioManager.STREAM_MUSIC
            "ring", "ringtone"    -> AudioManager.STREAM_RING
            "alarm"               -> AudioManager.STREAM_ALARM
            "notification"        -> AudioManager.STREAM_NOTIFICATION
            else                  -> AudioManager.STREAM_MUSIC
        }
        val max    = audioManager.getStreamMaxVolume(stream)
        val scaled = (level / 100.0 * max).toInt()
        audioManager.setStreamVolume(stream, scaled, AudioManager.FLAG_SHOW_UI)
        return "Volume set to $level%."
    }

    // ── Brightness ─────────────────────────────────
    private fun setBrightness(params: Map<String, String>): String {
        val level = params["level"]?.toIntOrNull()?.coerceIn(0, 100)
            ?: return "Please specify brightness level (0–100)."
        if (!Settings.System.canWrite(context)) {
            return "Brightness control requires 'Modify System Settings' permission. " +
                   "Go to Settings → Apps → Heritage AI → Modify system settings → Allow."
        }
        val scaled = (level / 100.0 * 255).toInt()
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, scaled)
        Settings.System.putInt(context.contentResolver,
            Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        return "Brightness set to $level%."
    }

    // ── Wi-Fi ──────────────────────────────────────
    private fun toggleWifi(params: Map<String, String>): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.startActivity(
                Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Opening Wi-Fi settings panel."
        }
        @Suppress("DEPRECATION")
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val enable = params["state"]?.lowercase() == "on"
        @Suppress("DEPRECATION")
        wm.isWifiEnabled = enable
        return if (enable) "Wi-Fi turned on." else "Wi-Fi turned off."
    }

    // ── Bluetooth ──────────────────────────────────
    private fun toggleBluetooth(params: Map<String, String>): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.startActivity(
                Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Opening Bluetooth settings."
        }
        val btAdapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
            .adapter ?: return "Bluetooth not supported on this device."
        val enable = params["state"]?.lowercase() == "on"
        @Suppress("DEPRECATION")
        if (enable) btAdapter.enable() else btAdapter.disable()
        return if (enable) "Bluetooth turning on." else "Bluetooth turning off."
    }

    // ── App Launcher — 6-level fuzzy matching ──────
    private fun openApp(params: Map<String, String>): String {
        val appName = (params["name"] ?: params["package"] ?: return "Please specify an app name.")
            .trim()

        // Level 0 — exact package name
        context.packageManager.getLaunchIntentForPackage(appName)?.let { intent ->
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Opening $appName."
        }

        // Get all launchable apps once
        val pm = context.packageManager
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }

        // Normalize common shorthand before matching
        val normalized = appName.trim()
            .replace(Regex("^the ", RegexOption.IGNORE_CASE), "")
            .replace(Regex(" app$", RegexOption.IGNORE_CASE), "")
            .replace(Regex(" application$", RegexOption.IGNORE_CASE), "")
            .trim()
        val query = normalized.lowercase()

        // Level 1 — EXACT display name match
        // This is the primary path now that the LLM knows exact installed app names
        installed.firstOrNull { pm.getApplicationLabel(it).toString().lowercase() == query }
            ?.let { return launchApp(it) }

        // Level 2 — display name starts with query
        installed.firstOrNull { pm.getApplicationLabel(it).toString().lowercase().startsWith(query) }
            ?.let { return launchApp(it) }

        // Level 3 — display name contains query
        installed.firstOrNull { pm.getApplicationLabel(it).toString().lowercase().contains(query) }
            ?.let { return launchApp(it) }

        // Level 4 — package name contains query
        // e.g. "tiktok" matches "com.zhiliaoapp.musically" because TikTok's
        // package used to be musically but its label is "TikTok"
        // This catches apps where the label doesn't match but package does
        installed.firstOrNull { it.packageName.lowercase().contains(query) }
            ?.let { return launchApp(it) }

        // Level 5 — common alias mapping
        // Maps what users say → what the app is actually called
        val aliases = mapOf(
            "whatsapp"        to "com.whatsapp",
            "facebook"        to listOf("com.facebook.katana", "com.facebook.lite"),
            "fb"              to listOf("com.facebook.katana", "com.facebook.lite"),
            "fb lite"         to "com.facebook.lite",
            "facebook lite"   to "com.facebook.lite",
            "instagram"       to "com.instagram.android",
            "ig"              to "com.instagram.android",
            "twitter"         to listOf("com.twitter.android", "com.x.android"),
            "x"               to listOf("com.twitter.android", "com.x.android"),
            // Nigerian apps common on Itel devices
            "minipay"         to "com.onafriq.minipay",
            "kik"             to "kik.android",
            "palmchat"        to "com.palmchat.android",
            "opay"            to "team.opay.pay",
            "palmpay"         to "com.palmpay.app",
            "tiktok"          to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
            "youtube"         to "com.google.android.youtube",
            "yt"              to "com.google.android.youtube",
            "chrome"          to "com.android.chrome",
            "gmail"           to "com.google.android.gm",
            "maps"            to "com.google.android.apps.maps",
            "google maps"     to "com.google.android.apps.maps",
            "play store"      to "com.android.vending",
            "playstore"       to "com.android.vending",
            "telegram"        to "org.telegram.messenger",
            "snapchat"        to "com.snapchat.android",
            "spotify"         to "com.spotify.music",
            "netflix"         to "com.netflix.mediaclient",
            "camera"          to listOf(
                "com.android.camera2",
                "com.itel.camera",
                "com.mediatek.camera",
                "com.google.android.GoogleCamera"
            ),
            "gallery"         to listOf(
                "com.android.gallery3d",
                "com.itel.gallery",
                "com.google.android.apps.photos"
            ),
            "calculator"      to listOf("com.android.calculator2", "com.itel.calculator"),
            "clock"           to listOf("com.android.deskclock", "com.itel.deskclock"),
            "settings"        to "com.android.settings",
            "contacts"        to listOf("com.android.contacts", "com.google.android.contacts"),
            "phone"           to listOf("com.android.dialer", "com.google.android.dialer"),
            "messages"        to listOf(
                "com.android.mms",
                "com.google.android.apps.messaging",
                "com.samsung.android.messaging"
            ),
            "sms"             to listOf("com.android.mms", "com.google.android.apps.messaging"),
            "files"           to listOf(
                "com.android.documentsui",
                "com.google.android.apps.nbu.files",
                "com.itel.filemanager"
            ),
            "file manager"    to listOf(
                "com.android.documentsui",
                "com.google.android.apps.nbu.files"
            ),
            "music"           to listOf(
                "com.android.music",
                "com.google.android.music",
                "com.spotify.music"
            ),
            "browser"         to listOf("com.android.browser", "com.android.chrome"),
            "opera"           to listOf("com.opera.browser", "com.opera.mini.native"),
            "opera mini"      to "com.opera.mini.native",
            "uc browser"      to "com.UCMobile.intl",
            "capcut"          to "com.lemon.lvoverseas",
            "lite"            to listOf("com.facebook.lite", "com.messenger.lite"),
        )

        val aliasPackages = aliases[query]
        if (aliasPackages != null) {
            val packages = if (aliasPackages is String)
                listOf(aliasPackages)
            else
                @Suppress("UNCHECKED_CAST") (aliasPackages as List<String>)

            for (pkg in packages) {
                pm.getLaunchIntentForPackage(pkg)?.let { intent ->
                    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    val label = runCatching {
                        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                    }.getOrDefault(pkg)
                    return "Opening $label."
                }
            }
        }

        // Level 6 — word-by-word partial match
        // Only run if query is at least 4 chars — prevents 'x', 'fb' etc
        // from matching random apps via substring
        val queryWords = query.split(" ").filter { it.length >= 4 }
        if (queryWords.isNotEmpty()) {
            installed.firstOrNull { app ->
                val label = pm.getApplicationLabel(app).toString().lowercase()
                val pkg   = app.packageName.lowercase()
                queryWords.any { word -> label.contains(word) || pkg.contains(word) }
            }?.let { return launchApp(it) }
        }

        return "I couldn't find '$appName' on your phone. " +
               "Make sure the app is installed and try using its exact name " +
               "as it appears on your home screen."
    }

    private fun launchApp(app: ApplicationInfo): String {
        val pm     = context.packageManager
        val intent = pm.getLaunchIntentForPackage(app.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return "Found the app but it has no launch screen."
        context.startActivity(intent)
        val label = pm.getApplicationLabel(app).toString()
        return "Opening $label."
    }

    // ── Alarms ─────────────────────────────────────
    private fun setAlarm(params: Map<String, String>): String {
        val hour    = params["hour"]?.toIntOrNull()   ?: return "Please specify an hour."
        val minute  = params["minute"]?.toIntOrNull() ?: 0
        val message = params["message"] ?: params["label"] ?: "Heritage AI Alarm"

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        context.startActivity(intent)

        val period      = if (hour < 12) "AM" else "PM"
        val displayHour = if (hour % 12 == 0) 12 else hour % 12
        val displayMin  = minute.toString().padStart(2, '0')
        return "Alarm set for $displayHour:$displayMin $period — \"$message\"."
    }

    // ── Do Not Disturb ─────────────────────────────
    private fun setDoNotDisturb(params: Map<String, String>): String {
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Please grant Do Not Disturb access in settings."
        }
        val enable = params["state"]?.lowercase() != "off"
        notificationManager.setInterruptionFilter(
            if (enable) NotificationManager.INTERRUPTION_FILTER_NONE
            else        NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return if (enable) "Do Not Disturb enabled." else "Do Not Disturb disabled."
    }

    // ── SMS ────────────────────────────────────────
    private fun sendSms(params: Map<String, String>): String {
        val number = params["number"] ?: params["to"] ?: params["phone"]
            ?: return "Please specify a phone number to send the message to."
        val message = params["message"] ?: params["text"] ?: params["body"]
            ?: return "Please specify the message to send."

        // Open SMS app pre-filled — safer than sending programmatically
        // (no SEND_SMS dangerous permission needed, user confirms before sending)
        val uri = android.net.Uri.parse("smsto:$number")
        val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", message)
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Opening SMS app — message to $number is pre-filled. Just tap Send."
        } catch (e: Exception) {
            "Could not open SMS app. Make sure a messaging app is installed."
        }
    }

    fun getInstalledApps(): List<Pair<String, String>> {
        val pm = context.packageManager
        return pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { pm.getApplicationLabel(it).toString() to it.packageName }
            .sortedBy { it.first }
    }
}
