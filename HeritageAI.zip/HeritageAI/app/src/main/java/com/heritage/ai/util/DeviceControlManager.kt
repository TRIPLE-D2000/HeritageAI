package com.heritage.ai.util

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DeviceControlManager — executes parsed device commands.
 *
 * App launching uses a 6-level fuzzy matching system so that
 * "Open TikTok", "Open Facebook", "Open Camera" etc all work
 * reliably regardless of the app's internal package name.
 */
@Singleton
class DeviceControlManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val contactManager: ContactManager
) {
    private var flashlightOn = false

    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }
    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    private val notificationManager by lazy {
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    suspend fun executeCommand(command: DeviceCommand): String = withContext(Dispatchers.IO) {
        runCatching {
            when (command.action) {
                CommandAction.TOGGLE_FLASHLIGHT -> toggleFlashlight(command.params)
                CommandAction.SET_VOLUME        -> setVolume(command.params)
                CommandAction.SET_BRIGHTNESS    -> setBrightness(command.params)
                CommandAction.TOGGLE_WIFI       -> toggleWifi(command.params)
                CommandAction.TOGGLE_BLUETOOTH  -> toggleBluetooth(command.params)
                CommandAction.TOGGLE_HOTSPOT    -> toggleHotspot()
                CommandAction.OPEN_APP          -> openApp(command.params)
                CommandAction.SET_ALARM         -> setAlarm(command.params)
                CommandAction.CANCEL_ALARM      -> cancelAlarm()
                CommandAction.SET_DND           -> setDoNotDisturb(command.params)
                CommandAction.TAKE_SCREENSHOT   ->
                    "Screenshots require a system permission dialog each time. Use Power + Volume Down for now."
                CommandAction.SEND_SMS          -> sendSms(command.params)
                CommandAction.CALL              -> callPerson(command.params)
                CommandAction.FIND_CONTACT      -> findContact(command.params)
                CommandAction.RUN_ROUTINE -> {
                    val routineName = command.params["name"] ?: ""
                    "Routine '$routineName' triggered. Check the Routines screen via the ☰ menu."
                }
                CommandAction.READ_NOTIFICATIONS -> {
                    val svc = com.heritage.ai.service.HeritageNotificationListenerService.instance
                    svc?.getActiveNotificationsSummary()
                        ?: "Notification listener is not enabled. Grant access in Settings."
                }
                CommandAction.UNKNOWN -> "Unknown command."
            }
        }.getOrElse { "Command failed: ${it.message}" }
    }

    // ── Flashlight ─────────────────────────────────
    private fun toggleFlashlight(params: Map<String, String>): String {
        val state = params["state"]?.lowercase()
        val targetOn = when (state) {
            "on", "true", "1"   -> true
            "off", "false", "0" -> false
            else                -> !flashlightOn
        }
        val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flashlight available on this device."
        cameraManager.setTorchMode(cameraId, targetOn)
        flashlightOn = targetOn
        return if (targetOn) "Flashlight turned on." else "Flashlight turned off."
    }

    // ── Volume ─────────────────────────────────────
    private fun setVolume(params: Map<String, String>): String {
        val level = params["level"]?.toIntOrNull()?.coerceIn(0, 100)
            ?: return "Please specify a volume level (0–100)."
        val stream = when (params["stream"]?.lowercase()) {
            "media", "music"      -> AudioManager.STREAM_MUSIC
            "ring", "ringtone"    -> AudioManager.STREAM_RING
            "alarm"               -> AudioManager.STREAM_ALARM
            "notification"        -> AudioManager.STREAM_NOTIFICATION
            else                  -> AudioManager.STREAM_MUSIC
        }
        val max    = audioManager.getStreamMaxVolume(stream)
        val scaled = (level / 100.0 * max).toInt()
        audioManager.setStreamVolume(stream, scaled, AudioManager.FLAG_SHOW_UI)
        return "Volume set to $level%."
    }

    // ── Brightness ─────────────────────────────────
    private fun setBrightness(params: Map<String, String>): String {
        val level = params["level"]?.toIntOrNull()?.coerceIn(0, 100)
            ?: return "Please specify brightness level (0–100)."
        if (!Settings.System.canWrite(context)) {
            return "⚠ Brightness control requires 'Modify System Settings' permission. " +
                   "Go to Settings → Apps → Heritage AI → Modify system settings → Allow."
        }
        val scaled = (level / 100.0 * 255).toInt()
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, scaled)
        Settings.System.putInt(context.contentResolver,
            Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        return "Brightness set to $level%."
    }

    // ── Wi-Fi ──────────────────────────────────────
    private fun toggleWifi(params: Map<String, String>): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.startActivity(
                Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Opening Wi-Fi settings panel."
        }
        @Suppress("DEPRECATION")
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val enable = params["state"]?.lowercase() == "on"
        @Suppress("DEPRECATION")
        wm.isWifiEnabled = enable
        return if (enable) "Wi-Fi turned on." else "Wi-Fi turned off."
    }

    // ── Bluetooth ──────────────────────────────────
    private fun toggleBluetooth(params: Map<String, String>): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.startActivity(
                Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Opening Bluetooth settings."
        }
        val btAdapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
            .adapter ?: return "Bluetooth not supported on this device."
        val enable = params["state"]?.lowercase() == "on"
        @Suppress("DEPRECATION")
        if (enable) btAdapter.enable() else btAdapter.disable()
        return if (enable) "Bluetooth turning on." else "Bluetooth turning off."
    }

    // ── Hotspot ────────────────────────────────────
    // Android has not allowed regular (non-system) apps to switch on Wi-Fi
    // tethering directly since API 26 — there is no public API for it, the
    // same restriction that already forces toggleWifi()/toggleBluetooth()
    // above to open a settings screen rather than flip the radio directly.
    // Best available option: deep-link straight to the tethering screen.
    private fun toggleHotspot(): String {
        return try {
            context.startActivity(
                Intent("android.settings.TETHER_SETTINGS")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Android doesn't let apps switch on the hotspot directly, so I've opened " +
                "the tethering screen — just tap the switch there."
        } catch (e: Exception) {
            // Some OEM skins don't expose the direct tethering intent — fall back
            // to general wireless settings, which always leads to it in 1-2 taps.
            context.startActivity(
                Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Opening wireless settings — look for Hotspot & Tethering there."
        }
    }

    // ── App Launcher ──────────────────────────────
    private fun openApp(params: Map<String, String>): String {
        val rawName = (params["name"] ?: params["package"]
            ?: return "Please specify an app name.").trim()

        val pm = context.packageManager

        // Level 0 — extract package name if LLM sent "AppName (com.package.name)" format
        // This is the primary path now that the LLM knows exact package names
        val packageRegex = Regex("""\(([a-z][a-z0-9_.]+)\)$""")
        val packageFromParens = packageRegex.find(rawName)?.groupValues?.get(1)
        val appName = if (packageFromParens != null)
            rawName.substringBeforeLast("(").trim() else rawName

        if (packageFromParens != null) {
            pm.getLaunchIntentForPackage(packageFromParens)?.let { intent ->
                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return "Opening $appName."
            }
        }

        // Level 1 — try as direct package name
        pm.getLaunchIntentForPackage(appName)?.let { intent ->
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Opening $appName."
        }

        // Get full installed app list for fuzzy matching
        val installedPairs = getInstalledApps()
        val normalized = appName.trim()
            .replace(Regex("^the ", RegexOption.IGNORE_CASE), "")
            .replace(Regex(" app$", RegexOption.IGNORE_CASE), "")
            .replace(Regex(" application$", RegexOption.IGNORE_CASE), "")
            .trim()
        val query = normalized.lowercase()

        // Level 2 — exact display name match
        installedPairs.firstOrNull { it.first.lowercase() == query }
            ?.let { return launchByPackage(it.second, it.first) }

        // Level 3 — display name starts with query
        installedPairs.firstOrNull { it.first.lowercase().startsWith(query) }
            ?.let { return launchByPackage(it.second, it.first) }

        // Level 4 — display name contains query
        installedPairs.firstOrNull { it.first.lowercase().contains(query) }
            ?.let { return launchByPackage(it.second, it.first) }

        // Level 5 — package name contains query
        installedPairs.firstOrNull { it.second.lowercase().contains(query) }
            ?.let { return launchByPackage(it.second, it.first) }

        // Level 6 — known alias table
        val aliases = mapOf(
            "whatsapp"      to listOf("com.whatsapp"),
            "telegram"      to listOf("org.telegram.messenger"),
            "instagram"     to listOf("com.instagram.android"),
            "tiktok"        to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
            "youtube"       to listOf("com.google.android.youtube"),
            "chrome"        to listOf("com.android.chrome"),
            "gmail"         to listOf("com.google.android.gm"),
            "facebook"      to listOf("com.facebook.katana", "com.facebook.lite"),
            "fb"            to listOf("com.facebook.katana", "com.facebook.lite"),
            "maps"          to listOf("com.google.android.apps.maps"),
            "play store"    to listOf("com.android.vending"),
            "playstore"     to listOf("com.android.vending"),
            "twitter"       to listOf("com.twitter.android", "com.x.android"),
            "snapchat"      to listOf("com.snapchat.android"),
            "spotify"       to listOf("com.spotify.music"),
            "netflix"       to listOf("com.netflix.mediaclient"),
            "camera"        to listOf("com.itel.camera", "com.android.camera2", "com.mediatek.camera"),
            "gallery"       to listOf("com.itel.gallery", "com.android.gallery3d"),
            "calculator"    to listOf("com.itel.calculator", "com.android.calculator2"),
            "clock"         to listOf("com.itel.deskclock", "com.android.deskclock"),
            "settings"      to listOf("com.android.settings"),
            "contacts"      to listOf("com.android.contacts", "com.google.android.contacts"),
            "phone"         to listOf("com.android.dialer", "com.google.android.dialer"),
            "messages"      to listOf("com.android.mms", "com.google.android.apps.messaging"),
            "files"         to listOf("com.google.android.apps.nbu.files", "com.android.documentsui"),
            "opay"          to listOf("team.opay.pay"),
            "palmpay"       to listOf("com.palmpay.app"),
            "minipay"       to listOf("com.onafriq.minipay"),
            "kik"           to listOf("kik.android"),
            "discord"       to listOf("com.discord"),
            "capcut"        to listOf("com.lemon.lvoverseas"),
            "opera mini"    to listOf("com.opera.mini.native"),
            "uc browser"    to listOf("com.UCMobile.intl")
        )
        aliases[query]?.forEach { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let { intent ->
                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                val label = runCatching {
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                }.getOrDefault(pkg)
                return "Opening $label."
            }
        }

        // Level 7 — word-by-word match (last resort)
        val queryWords = query.split(" ").filter { it.length >= 4 }
        if (queryWords.isNotEmpty()) {
            installedPairs.firstOrNull { (label, pkg) ->
                val l = label.lowercase()
                val p = pkg.lowercase()
                queryWords.any { word -> l.contains(word) || p.contains(word) }
            }?.let { return launchByPackage(it.second, it.first) }
        }

        return "I couldn't find '$appName' on your phone. " +
               "Say 'what apps do you see' to check the full list."
    }

    private fun launchByPackage(packageName: String, displayName: String): String {
        val intent = context.packageManager
            .getLaunchIntentForPackage(packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return "Found '$displayName' but it has no launch screen."
        context.startActivity(intent)
        return "Opening $displayName."
    }

    // ── Contacts: call / text / look up BY NAME ────

    private sealed class Target {
        data class Ok(val label: String, val number: String, val exact: Boolean) : Target()
        data class Problem(val message: String) : Target()
    }

    private fun looksLikeNumber(s: String): Boolean =
        s.count { it.isDigit() } >= 3 && s.all { it.isDigit() || it in "+ ()-.#*" }

    private fun contactName(params: Map<String, String>): String? =
        (params["name"] ?: params["contact"] ?: params["person"] ?: params["who"]
            ?: params["to"] ?: params["number"] ?: params["phone"])?.trim()

    /** Turns "Mum" (or a raw number) into something we can dial or text. */
    private suspend fun resolveTarget(params: Map<String, String>): Target {
        val raw = (params["number"] ?: params["phone"])?.trim()?.takeIf { looksLikeNumber(it) }
            ?: contactName(params)
        if (raw.isNullOrBlank()) return Target.Problem("⚠ Who should I contact? Tell me a name.")
        if (looksLikeNumber(raw)) return Target.Ok(raw, raw, true)
        return when (val r = contactManager.lookup(raw)) {
            is ContactLookup.Found ->
                Target.Ok(r.contact.name, r.contact.phoneNumber, r.contact.score >= 70)
            is ContactLookup.Ambiguous ->
                Target.Problem("⚠ I found more than one match for \"$raw\": " +
                    r.options.joinToString(", ") { it.name } + ". Which one do you mean?")
            ContactLookup.NotFound ->
                Target.Problem("⚠ I couldn't find \"$raw\" in your contacts. " +
                    "Check the spelling, or give me their number.")
            ContactLookup.NoPermission ->
                Target.Problem("⚠ I need Contacts permission to find people by name. " +
                    "Open Heritage AI → Settings → Permissions → Contacts & Calling.")
        }
    }

    private suspend fun callPerson(params: Map<String, String>): String {
        val t = resolveTarget(params)
        val ok = (t as? Target.Ok) ?: return (t as Target.Problem).message

        // Only place the call straight away when the name matched confidently;
        // a fuzzy match opens the dialer so a mis-heard name can't ring a stranger.
        val canCallDirectly = ok.exact && androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.CALL_PHONE
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        val uri = android.net.Uri.fromParts("tel", ok.number, null)
        fun launch(action: String) = context.startActivity(
            Intent(action, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return try {
            if (canCallDirectly) {
                launch(Intent.ACTION_CALL)
                "Calling ${ok.label}…"
            } else {
                launch(Intent.ACTION_DIAL)
                if (ok.exact) "Opening the dialer for ${ok.label} — tap the call button."
                else "I wasn't sure that was exactly who you meant, so I opened the dialer for " +
                     "${ok.label} — tap call if that's right."
            }
        } catch (e: SecurityException) {
            launch(Intent.ACTION_DIAL)
            "Opening the dialer for ${ok.label} — tap the call button."
        } catch (e: Exception) {
            "⚠ Couldn't start the call: ${e.message}"
        }
    }

    private suspend fun findContact(params: Map<String, String>): String {
        val raw = contactName(params)
        if (raw.isNullOrBlank()) return "⚠ Whose contact info should I look up?"
        return when (val r = contactManager.lookup(raw)) {
            is ContactLookup.Found ->
                "${r.contact.name}: ${r.contact.numbers.ifEmpty { listOf(r.contact.phoneNumber) }.joinToString(", ")}"
            is ContactLookup.Ambiguous ->
                "I found a few matches:\n" + r.options.joinToString("\n") {
                    "${it.name}: ${it.numbers.ifEmpty { listOf(it.phoneNumber) }.joinToString(", ")}"
                }
            ContactLookup.NotFound -> "⚠ I couldn't find \"$raw\" in your contacts."
            ContactLookup.NoPermission ->
                "⚠ I need Contacts permission. Open Heritage AI → Settings → Permissions → Contacts & Calling."
        }
    }

    // ── SMS ────────────────────────────────────────
    private suspend fun sendSms(params: Map<String, String>): String {
        val message = params["message"] ?: params["text"] ?: params["body"]
            ?: return "⚠ What should the message say?"
        val t = resolveTarget(params)
        val ok = (t as? Target.Ok) ?: return (t as Target.Problem).message

        // Open the SMS app pre-filled: the user confirms with one tap on Send.
        // (Sending silently would need the restricted SEND_SMS permission.)
        val intent = Intent(Intent.ACTION_SENDTO, android.net.Uri.fromParts("smsto", ok.number, null)).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Opening your messages — the text to ${ok.label} is ready. Just tap Send."
        } catch (e: Exception) {
            "⚠ Could not open the SMS app. Make sure a messaging app is installed."
        }
    }


    // ── Alarms ─────────────────────────────────────
    private fun setAlarm(params: Map<String, String>): String {
        val hour    = params["hour"]?.toIntOrNull()   ?: return "Please specify an hour."
        val minute  = params["minute"]?.toIntOrNull() ?: 0
        val message = params["message"] ?: params["label"] ?: "Heritage AI Alarm"
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        context.startActivity(intent)
        val period      = if (hour < 12) "AM" else "PM"
        val displayHour = if (hour % 12 == 0) 12 else hour % 12
        val displayMin  = minute.toString().padStart(2, '0')
        return "Alarm set for $displayHour:$displayMin $period."
    }

    /**
     * Android's AlarmClock intent API (ACTION_SET_ALARM) can CREATE an alarm,
     * but there is no public, documented way to delete a specific
     * previously-set one — each OEM's Clock app owns its own alarm list
     * privately, with no cross-app "delete alarm #x" API. Without this
     * action, the model had nothing better to reach for than SET_ALARM
     * again, which is why "cancel the alarm" was silently re-creating it.
     * Best available option: jump straight to the alarms list so removing
     * it is one tap instead of a hunt through the Clock app.
     */
    private fun cancelAlarm(): String {
        return try {
            context.startActivity(
                Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Android doesn't let me delete a specific alarm directly, so I've opened " +
                "your alarms list — just tap the one you want to remove."
        } catch (e: Exception) {
            "I couldn't open your alarms list. Try opening your Clock app directly to remove it."
        }
    }


    // ── Do Not Disturb ─────────────────────────────
    private fun setDoNotDisturb(params: Map<String, String>): String {
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Please grant Do Not Disturb access in settings."
        }
        val enable = params["state"]?.lowercase() != "off"
        notificationManager.setInterruptionFilter(
            if (enable) NotificationManager.INTERRUPTION_FILTER_NONE
            else        NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return if (enable) "Do Not Disturb enabled." else "Do Not Disturb disabled."
    }

    fun getInstalledApps(): List<Pair<String, String>> {
        val pm = context.packageManager

        // Method 1: Standard launcher intent
        val method1 = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { pm.getApplicationLabel(it).toString() to it.packageName }

        // Method 2: Query MAIN+LAUNCHER activities directly
        // This catches apps that Method 1 misses on some Android Go devices
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val method2 = pm.queryIntentActivities(launcherIntent, PackageManager.GET_META_DATA)
            .map { resolveInfo ->
                val label = resolveInfo.loadLabel(pm).toString()
                label to resolveInfo.activityInfo.packageName
            }

        // Merge both lists, deduplicate by package name
        return (method1 + method2)
            .distinctBy { it.second }
            .filter { it.first.isNotBlank() }
            .sortedBy { it.first }
    }
}
