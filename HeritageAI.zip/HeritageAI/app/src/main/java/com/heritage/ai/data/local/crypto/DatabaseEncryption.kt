package com.heritage.ai.data.local.crypto

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * DatabaseEncryption — Android Keystore-backed encryption for the Room database passphrase.
 *
 * The database passphrase is generated once, encrypted with an AES-256-GCM key
 * stored in the Android hardware-backed Keystore, and persisted in SharedPreferences
 * in its encrypted form. On each app launch, it is decrypted in memory and passed to
 * SQLCipher, then immediately zeroed out.
 *
 * Key properties:
 * - Algorithm: AES-256-GCM
 * - Key storage: Android Keystore (hardware-backed when available)
 * - Authentication: None (passphrase-based auth handled by the app)
 * - Invalidation: Keys are invalidated if the user adds a new fingerprint
 */
class DatabaseEncryption(private val context: Context) {

    companion object {
        private const val KEYSTORE_ALIAS = "heritage_ai_db_key"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_SIZE = 12
        private const val TAG_SIZE = 128
        private const val PREFS_NAME = "heritage_crypto_prefs"
        private const val PREFS_KEY_ENCRYPTED_DB_KEY = "encrypted_db_passphrase"
        private const val DB_PASSPHRASE_SIZE = 32  // 256-bit
    }

    private val prefs by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Returns the database passphrase as a byte array.
     * CALLER MUST zero the array immediately after use.
     */
    fun getDatabasePassphrase(): ByteArray {
        val stored = prefs.getString(PREFS_KEY_ENCRYPTED_DB_KEY, null)
        return if (stored != null) {
            decryptPassphrase(Base64.decode(stored, Base64.DEFAULT))
        } else {
            generateAndStorePassphrase()
        }
    }

    private fun generateAndStorePassphrase(): ByteArray {
        ensureKeyExists()
        val passphrase = java.security.SecureRandom().generateSeed(DB_PASSPHRASE_SIZE)
        val encrypted = encryptPassphrase(passphrase)
        prefs.edit()
            .putString(PREFS_KEY_ENCRYPTED_DB_KEY, Base64.encodeToString(encrypted, Base64.DEFAULT))
            .apply()
        return passphrase
    }

    private fun ensureKeyExists() {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(KEYSTORE_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                ANDROID_KEYSTORE
            )
            keyGenerator.init(
                KeyGenParameterSpec.Builder(
                    KEYSTORE_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setRandomizedEncryptionRequired(true)
                    .build()
            )
            keyGenerator.generateKey()
        }
    }

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        return (keyStore.getEntry(KEYSTORE_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    private fun encryptPassphrase(passphrase: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(passphrase)
        // Prepend IV to the encrypted data: [IV (12 bytes)][ciphertext]
        return iv + encrypted
    }

    private fun decryptPassphrase(data: ByteArray): ByteArray {
        val iv = data.copyOfRange(0, IV_SIZE)
        val ciphertext = data.copyOfRange(IV_SIZE, data.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), GCMParameterSpec(TAG_SIZE, iv))
        return cipher.doFinal(ciphertext)
    }

    /**
     * Deletes the encryption key and encrypted passphrase.
     * Called only when the user explicitly chooses to wipe all data.
     */
    fun destroyKey() {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            keyStore.deleteEntry(KEYSTORE_ALIAS)
            prefs.edit().remove(PREFS_KEY_ENCRYPTED_DB_KEY).apply()
        } catch (_: Exception) { /* swallow — key may already be gone */ }
    }
}
