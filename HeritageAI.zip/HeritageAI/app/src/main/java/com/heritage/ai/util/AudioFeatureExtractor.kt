package com.heritage.ai.util

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import java.nio.FloatBuffer

/**
 * ────────────────────────────────────────────────────────────
 * AudioFeatureExtractor
 * ────────────────────────────────────────────────────────────
 * Ported from openWakeWord's AudioFeatures class (utils.py,
 * dscripka/openWakeWord, Apache 2.0). The streaming/windowing logic
 * (buffer sizes, the 76-frame/stride-8 embedding windowing, the
 * melspectrogram transform) is unchanged from the original port —
 * that logic was never the source of the crash. Only the model
 * runtime changed, from TFLite to ONNX Runtime.
 *
 * WHY ONNX, NOT TFLITE: Android's TFLite Interpreter auto-allocates
 * tensors using a model's raw default shape immediately at
 * construction time, before any resize call is possible. This
 * specific model's exported default shape is invalid for that
 * auto-allocation (confirmed via an identical, unresolved issue on
 * openWakeWord's own GitHub — dscripka/openWakeWord#223 — reported
 * by another developer hitting this exact error on this exact
 * model). Python's TFLite bindings avoid this because allocation is
 * a separate, explicit step you control; Android's Java/Kotlin API
 * does not expose that same control. ONNX Runtime builds the input
 * tensor with an explicit shape you provide, sidestepping the bug
 * entirely — this is also the approach other Android ports of
 * openWakeWord actually use.
 *
 * Converts a continuous stream of raw 16kHz mono PCM audio into the
 * 96-dim "speech embedding" features a wake-word classifier model
 * (like hey_heritage.onnx) expects as its [1, 16, 96] input.
 */
class AudioFeatureExtractor(context: Context) {

    companion object {
        private const val CHUNK_SAMPLES = 1280          // 80ms @ 16kHz — the streaming unit
        private const val MELSPEC_CONTEXT_SAMPLES = 160 * 3 // trailing context for STFT edge effects
        private const val MEL_BINS = 32
        private const val EMBEDDING_WINDOW = 76          // melspec frames per embedding window
        private const val EMBEDDING_STRIDE = 8
        private const val EMBEDDING_DIM = 96
        private const val RAW_BUFFER_MAX_SAMPLES = 16000 * 10  // 10s
        private const val MELSPEC_BUFFER_MAX_FRAMES = 10 * 97  // ~10s of frames
        private const val FEATURE_BUFFER_MAX_FRAMES = 120      // ~10s of feature history
    }

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val melspecSession: OrtSession
    private val embeddingSession: OrtSession
    private val melspecInputName: String
    private val embeddingInputName: String

    // Raw audio ring buffer (simple growable list; audio chunks are small
    // and this runs at ~12.5 Hz, so this isn't a hot enough path to need a
    // hand-rolled circular buffer for correctness's sake).
    private val rawBuffer = ArrayDeque<Short>()
    private var rawRemainder: ShortArray = ShortArray(0)
    private var accumulatedSamples = 0

    // melspectrogramBuffer: list of 32-float frames. Starts pre-filled with
    // 76 frames of 1.0f, matching the reference's np.ones((76,32)) seed —
    // this avoids a below-minimum-length edge case on the very first calls.
    private val melspecBuffer = ArrayDeque<FloatArray>().apply {
        repeat(EMBEDDING_WINDOW) { add(FloatArray(MEL_BINS) { 1.0f }) }
    }

    // featureBuffer: list of 96-float embeddings. Seeded with 16 rows of
    // zeros rather than the reference's 4-seconds-of-random-noise seed —
    // both are discarded from the live window within ~1.3s of real audio,
    // so zeros are a simpler, equally-safe placeholder for that brief
    // startup period (and won't risk an accidental high score from noise).
    private val featureBuffer = ArrayDeque<FloatArray>().apply {
        repeat(16) { add(FloatArray(EMBEDDING_DIM)) }
    }

    init {
        val melspecBytes = context.assets.open("melspectrogram.onnx").use { it.readBytes() }
        val embeddingBytes = context.assets.open("embedding_model.onnx").use { it.readBytes() }
        melspecSession = env.createSession(melspecBytes, OrtSession.SessionOptions())
        embeddingSession = env.createSession(embeddingBytes, OrtSession.SessionOptions())
        // Read the actual input name from the model rather than guessing —
        // ONNX exports commonly use auto-generated, non-obvious names
        // (confirmed on hey_heritage.onnx: "onnx::Flatten_0", not anything
        // human-chosen), so hardcoding a guessed name would be fragile.
        melspecInputName = melspecSession.inputNames.iterator().next()
        embeddingInputName = embeddingSession.inputNames.iterator().next()
    }

    /**
     * Feeds a chunk of raw 16-bit PCM audio into the pipeline. Call this
     * continuously as audio arrives from AudioRecord — chunk size doesn't
     * need to be exactly 1280 samples; leftover samples are carried over
     * to the next call, same as the reference implementation.
     */
    fun processAudio(samples: ShortArray) {
        var input = samples
        if (rawRemainder.isNotEmpty()) {
            input = rawRemainder + samples
            rawRemainder = ShortArray(0)
        }

        if (accumulatedSamples + input.size >= CHUNK_SAMPLES) {
            val remainder = (accumulatedSamples + input.size) % CHUNK_SAMPLES
            if (remainder != 0) {
                val evenPart = input.copyOfRange(0, input.size - remainder)
                bufferRaw(evenPart)
                accumulatedSamples += evenPart.size
                rawRemainder = input.copyOfRange(input.size - remainder, input.size)
            } else {
                bufferRaw(input)
                accumulatedSamples += input.size
            }
        } else {
            accumulatedSamples += input.size
            bufferRaw(input)
        }

        if (accumulatedSamples >= CHUNK_SAMPLES && accumulatedSamples % CHUNK_SAMPLES == 0) {
            updateMelspectrogram(accumulatedSamples)
            updateEmbeddings(accumulatedSamples)
            accumulatedSamples = 0
        }
    }

    private fun bufferRaw(samples: ShortArray) {
        for (s in samples) {
            rawBuffer.addLast(s)
            if (rawBuffer.size > RAW_BUFFER_MAX_SAMPLES) rawBuffer.removeFirst()
        }
    }

    private fun updateMelspectrogram(nSamples: Int) {
        val windowSize = nSamples + MELSPEC_CONTEXT_SAMPLES
        val window = ShortArray(minOf(windowSize, rawBuffer.size))
        val startIdx = maxOf(0, rawBuffer.size - windowSize)
        for (i in window.indices) window[i] = rawBuffer.elementAt(startIdx + i)

        val newFrames = runMelspectrogram(window)
        newFrames.forEach { melspecBuffer.addLast(it) }
        while (melspecBuffer.size > MELSPEC_BUFFER_MAX_FRAMES) melspecBuffer.removeFirst()
    }

    /** Runs the melspec model and applies the same transform the reference uses to match Google's original. */
    private fun runMelspectrogram(samples: ShortArray): List<FloatArray> {
        val inputData = FloatArray(samples.size) { samples[it].toFloat() }
        val inputTensor = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(inputData), longArrayOf(1, samples.size.toLong())
        )

        val flat: FloatArray = inputTensor.use { tensor ->
            melspecSession.run(mapOf(melspecInputName to tensor)).use { results ->
                val outputTensor = results.iterator().next().value as OnnxTensor
                val buf = outputTensor.floatBuffer
                FloatArray(buf.remaining()).also { buf.get(it) }
            }
        }

        val nFrames = flat.size / MEL_BINS
        val frames = mutableListOf<FloatArray>()
        for (f in 0 until nFrames) {
            val frame = FloatArray(MEL_BINS) { b -> flat[f * MEL_BINS + b] / 10f + 2f } // reference transform
            frames.add(frame)
        }
        return frames
    }

    private fun updateEmbeddings(processedSamples: Int) {
        val chunksProcessed = processedSamples / CHUNK_SAMPLES
        val bufSize = melspecBuffer.size
        for (i in (chunksProcessed - 1) downTo 0) {
            // Python reference uses negative indexing (buffer[-76+ndx:ndx]) as
            // a from-the-end shorthand. Translated to explicit absolute
            // positions: the most recent window (i=0) is the last 76 frames;
            // each step back in i moves the window 8 frames earlier.
            val end = bufSize - EMBEDDING_STRIDE * i
            val start = end - EMBEDDING_WINDOW
            if (start < 0 || end > bufSize) continue

            val window = Array(EMBEDDING_WINDOW) { idx -> melspecBuffer.elementAt(start + idx) }
            featureBuffer.addLast(runEmbedding(window))
        }
        while (featureBuffer.size > FEATURE_BUFFER_MAX_FRAMES) featureBuffer.removeFirst()
    }

    private fun runEmbedding(window: Array<FloatArray>): FloatArray {
        val inputData = FloatArray(EMBEDDING_WINDOW * MEL_BINS)
        window.forEachIndexed { fi, frame -> frame.forEachIndexed { bi, v -> inputData[fi * MEL_BINS + bi] = v } }

        val inputTensor = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(inputData), longArrayOf(1, EMBEDDING_WINDOW.toLong(), MEL_BINS.toLong(), 1)
        )

        return inputTensor.use { tensor ->
            embeddingSession.run(mapOf(embeddingInputName to tensor)).use { results ->
                val outputTensor = results.iterator().next().value as OnnxTensor
                val buf = outputTensor.floatBuffer
                FloatArray(EMBEDDING_DIM).also { buf.get(it) }
            }
        }
    }

    /**
     * Returns the most recent [n] feature frames as a flat [1, n, 96]
     * buffer, ready to feed directly into a wake-word classifier model.
     */
    fun getFeatures(n: Int = 16): Array<FloatArray> {
        val size = featureBuffer.size
        return Array(n) { i ->
            val idx = size - n + i
            if (idx in 0 until size) featureBuffer.elementAt(idx) else FloatArray(EMBEDDING_DIM)
        }
    }

    fun close() {
        melspecSession.close()
        embeddingSession.close()
    }
}
