package com.heritage.ai.util

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * ────────────────────────────────────────────────────────────
 * AudioFeatureExtractor
 * ────────────────────────────────────────────────────────────
 * Ported from openWakeWord's AudioFeatures class (utils.py,
 * dscripka/openWakeWord, Apache 2.0) — this is a faithful port of
 * the actual reference streaming logic, not a reconstruction from
 * the architecture description. Exact buffer sizes, the 76-frame/
 * stride-8 embedding windowing, and the melspectrogram transform
 * (raw/10 + 2, needed to match Google's original TF implementation)
 * all come directly from that source.
 *
 * Converts a continuous stream of raw 16kHz mono PCM audio into the
 * 96-dim "speech embedding" features that a wake-word classifier
 * model (like hey_heritage.tflite) expects as its [1, 16, 96] input.
 *
 * Two shared, generic TFLite models do the heavy lifting — these are
 * NOT specific to any one wake word, they're the same two files used
 * by every openWakeWord-family model:
 *   - melspectrogram.tflite: raw audio -> mel-spectrogram frames
 *   - embedding_model.tflite: mel-spectrogram window -> 96-dim vector
 */
class AudioFeatureExtractor(context: Context) {

    companion object {
        private const val CHUNK_SAMPLES = 1280          // 80ms @ 16kHz — the streaming unit
        private const val MELSPEC_CONTEXT_SAMPLES = 160 * 3 // trailing context for STFT edge effects
        private const val MEL_BINS = 32
        private const val EMBEDDING_WINDOW = 76          // melspec frames per embedding window
        private const val EMBEDDING_STRIDE = 8
        private const val EMBEDDING_DIM = 96
        private const val RAW_BUFFER_MAX_SAMPLES = 16000 * 10  // 10s
        private const val MELSPEC_BUFFER_MAX_FRAMES = 10 * 97  // ~10s of frames
        private const val FEATURE_BUFFER_MAX_FRAMES = 120      // ~10s of feature history
    }

    private val melspecInterpreter: Interpreter
    private val embeddingInterpreter: Interpreter

    // Raw audio ring buffer (simple growable list; audio chunks are small
    // and this runs at ~12.5 Hz, so this isn't a hot enough path to need a
    // hand-rolled circular buffer for correctness's sake).
    private val rawBuffer = ArrayDeque<Short>()
    private var rawRemainder: ShortArray = ShortArray(0)
    private var accumulatedSamples = 0

    // melspectrogramBuffer: list of 32-float frames. Starts pre-filled with
    // 76 frames of 1.0f, matching the reference's np.ones((76,32)) seed —
    // this avoids a below-minimum-length edge case on the very first calls.
    private val melspecBuffer = ArrayDeque<FloatArray>().apply {
        repeat(EMBEDDING_WINDOW) { add(FloatArray(MEL_BINS) { 1.0f }) }
    }

    // featureBuffer: list of 96-float embeddings. Seeded with 16 rows of
    // zeros rather than the reference's 4-seconds-of-random-noise seed —
    // both are discarded from the live window within ~1.3s of real audio,
    // so zeros are a simpler, equally-safe placeholder for that brief
    // startup period (and won't risk an accidental high score from noise).
    private val featureBuffer = ArrayDeque<FloatArray>().apply {
        repeat(16) { add(FloatArray(EMBEDDING_DIM)) }
    }

    // Last melspec frame count fed to the tensor, so we only call
    // resizeInput when the size actually changes (matches the reference's
    // guard against redundant reallocation).
    private var lastMelspecInputSize = -1

    init {
        // useXNNPACK=false specifically for the melspec model: it has a
        // dynamic input size (resized per audio chunk), and the error log
        // showed XNNPACK explicitly failing to prepare its tensor
        // allocations ("Failed to apply the default TensorFlow Lite
        // delegate") — a known category of XNNPACK/dynamic-shape
        // incompatibility. Falling back to standard CPU kernels avoids it.
        val melspecOptions = Interpreter.Options().apply { setUseXNNPACK(false) }
        melspecInterpreter = Interpreter(loadModelFile(context, "melspectrogram.tflite"), melspecOptions)
        embeddingInterpreter = Interpreter(loadModelFile(context, "embedding_model.tflite"))
    }

    private fun loadModelFile(context: Context, assetName: String): MappedByteBuffer {
        val afd = context.assets.openFd(assetName)
        FileInputStream(afd.fileDescriptor).use { input ->
            return input.channel.map(
                FileChannel.MapMode.READ_ONLY,
                afd.startOffset,
                afd.declaredLength
            )
        }
    }

    /**
     * Feeds a chunk of raw 16-bit PCM audio into the pipeline. Call this
     * continuously as audio arrives from AudioRecord — chunk size doesn't
     * need to be exactly 1280 samples; leftover samples are carried over
     * to the next call, same as the reference implementation.
     */
    fun processAudio(samples: ShortArray) {
        var input = samples
        if (rawRemainder.isNotEmpty()) {
            input = rawRemainder + samples
            rawRemainder = ShortArray(0)
        }

        if (accumulatedSamples + input.size >= CHUNK_SAMPLES) {
            val remainder = (accumulatedSamples + input.size) % CHUNK_SAMPLES
            if (remainder != 0) {
                val evenPart = input.copyOfRange(0, input.size - remainder)
                bufferRaw(evenPart)
                accumulatedSamples += evenPart.size
                rawRemainder = input.copyOfRange(input.size - remainder, input.size)
            } else {
                bufferRaw(input)
                accumulatedSamples += input.size
            }
        } else {
            accumulatedSamples += input.size
            bufferRaw(input)
        }

        if (accumulatedSamples >= CHUNK_SAMPLES && accumulatedSamples % CHUNK_SAMPLES == 0) {
            updateMelspectrogram(accumulatedSamples)
            updateEmbeddings(accumulatedSamples)
            accumulatedSamples = 0
        }
    }

    private fun bufferRaw(samples: ShortArray) {
        for (s in samples) {
            rawBuffer.addLast(s)
            if (rawBuffer.size > RAW_BUFFER_MAX_SAMPLES) rawBuffer.removeFirst()
        }
    }

    private fun updateMelspectrogram(nSamples: Int) {
        val windowSize = nSamples + MELSPEC_CONTEXT_SAMPLES
        val window = ShortArray(minOf(windowSize, rawBuffer.size))
        val startIdx = maxOf(0, rawBuffer.size - windowSize)
        for (i in window.indices) window[i] = rawBuffer.elementAt(startIdx + i)

        val newFrames = runMelspectrogram(window)
        newFrames.forEach { melspecBuffer.addLast(it) }
        while (melspecBuffer.size > MELSPEC_BUFFER_MAX_FRAMES) melspecBuffer.removeFirst()
    }

    /** Runs the melspec model and applies the same transform the reference uses to match Google's original. */
    private fun runMelspectrogram(samples: ShortArray): List<FloatArray> {
        if (lastMelspecInputSize != samples.size) {
            melspecInterpreter.resizeInput(0, intArrayOf(1, samples.size))
            melspecInterpreter.allocateTensors()
            lastMelspecInputSize = samples.size
        }

        val inputBuffer = ByteBuffer.allocateDirect(samples.size * 4).order(ByteOrder.nativeOrder())
        samples.forEach { inputBuffer.putFloat(it.toFloat()) }
        inputBuffer.rewind()

        // Output frame count follows the reference's n_frames formula.
        val nFrames = maxOf(1, Math.ceil(samples.size / 160.0 - 3).toInt())
        val outputBuffer = ByteBuffer.allocateDirect(nFrames * MEL_BINS * 4).order(ByteOrder.nativeOrder())

        melspecInterpreter.run(inputBuffer, outputBuffer)
        outputBuffer.rewind()

        val frames = mutableListOf<FloatArray>()
        repeat(nFrames) {
            val frame = FloatArray(MEL_BINS) { outputBuffer.float / 10f + 2f } // reference transform
            frames.add(frame)
        }
        return frames
    }

    private fun updateEmbeddings(processedSamples: Int) {
        val chunksProcessed = processedSamples / CHUNK_SAMPLES
        val bufSize = melspecBuffer.size
        for (i in (chunksProcessed - 1) downTo 0) {
            // Python reference uses negative indexing (buffer[-76+ndx:ndx]) as
            // a from-the-end shorthand. Translated to explicit absolute
            // positions: the most recent window (i=0) is the last 76 frames;
            // each step back in i moves the window 8 frames earlier.
            val end = bufSize - EMBEDDING_STRIDE * i
            val start = end - EMBEDDING_WINDOW
            if (start < 0 || end > bufSize) continue

            val window = Array(EMBEDDING_WINDOW) { idx -> melspecBuffer.elementAt(start + idx) }
            val embedding = runEmbedding(window)
            featureBuffer.addLast(embedding)
        }
        while (featureBuffer.size > FEATURE_BUFFER_MAX_FRAMES) featureBuffer.removeFirst()
    }

    private fun runEmbedding(window: Array<FloatArray>): FloatArray {
        val inputBuffer = ByteBuffer.allocateDirect(EMBEDDING_WINDOW * MEL_BINS * 4).order(ByteOrder.nativeOrder())
        window.forEach { frame -> frame.forEach { inputBuffer.putFloat(it) } }
        inputBuffer.rewind()

        val outputBuffer = ByteBuffer.allocateDirect(EMBEDDING_DIM * 4).order(ByteOrder.nativeOrder())
        embeddingInterpreter.run(inputBuffer, outputBuffer)
        outputBuffer.rewind()

        return FloatArray(EMBEDDING_DIM) { outputBuffer.float }
    }

    /**
     * Returns the most recent [n] feature frames as a flat [1, n, 96]
     * buffer, ready to feed directly into a wake-word classifier model.
     */
    fun getFeatures(n: Int = 16): Array<FloatArray> {
        val size = featureBuffer.size
        return Array(n) { i ->
            val idx = size - n + i
            if (idx in 0 until size) featureBuffer.elementAt(idx) else FloatArray(EMBEDDING_DIM)
        }
    }

    fun close() {
        melspecInterpreter.close()
        embeddingInterpreter.close()
    }
}
