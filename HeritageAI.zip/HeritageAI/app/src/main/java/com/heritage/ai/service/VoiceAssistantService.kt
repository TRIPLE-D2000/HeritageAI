package com.heritage.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.heritage.ai.MainActivity
import com.heritage.ai.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * VoiceAssistantService — foreground service managing Android SpeechRecognizer.
 *
 * KEY FIX for budget devices (Itel A50, Android Go Edition):
 * SpeechRecognizer gets permanently stuck after the first session on many
 * budget devices. The fix is to DESTROY and RECREATE it completely before
 * every new listening session instead of reusing the same instance.
 *
 * Also enforces main-thread usage — SpeechRecognizer is not thread-safe
 * and will silently fail or crash if touched from a background thread.
 */
@AndroidEntryPoint
class VoiceAssistantService : Service() {

    companion object {
        const val CHANNEL_ID = "heritage_voice_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_LISTENING = "com.heritage.ai.START_LISTENING"
        const val ACTION_STOP_LISTENING  = "com.heritage.ai.STOP_LISTENING"
    }

    inner class VoiceBinder : Binder() {
        fun getService(): VoiceAssistantService = this@VoiceAssistantService
    }

    private val binder = VoiceBinder()

    // ── Public state flows ─────────────────────────
    private val _recognizedText = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val recognizedText = _recognizedText.asSharedFlow()

    private val _partialText = MutableStateFlow("")
    val partialText = _partialText.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude = _amplitude.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening = _isListening.asStateFlow()

    private val _errorMessage = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val errorMessage = _errorMessage.asSharedFlow()

    // ── SpeechRecognizer (recreated every session) ─
    private var speechRecognizer: SpeechRecognizer? = null

    // All SpeechRecognizer calls MUST happen on the main thread
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Ready to listen"))
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_LISTENING -> startListening()
            ACTION_STOP_LISTENING  -> stopListening()
        }
        return START_STICKY
    }

    // ── Core fix: destroy → recreate → start ──────
    fun startListening() {
        mainHandler.post {
            // Step 1: Always fully destroy the previous instance first.
            // Skipping this is what caused the "2 seconds then dies" bug
            // on the Itel A50 and similar budget devices.
            destroyRecognizer()

            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                _errorMessage.tryEmit("Speech recognition is not available on this device")
                return@post
            }

            // Step 2: Create a completely fresh instance
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(buildListener())

            // Step 3: Start listening with a small delay so the new
            // instance fully initialises before receiving commands —
            // especially important on slower CPUs like Unisoc T603
            mainHandler.postDelayed({
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    // Try English explicitly — more reliable than device locale on budget devices
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "en-US")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    // Longer timeouts for slower budget devices
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                }
                speechRecognizer?.startListening(intent)
            }, 150L) // 150 ms warm-up delay
        }
    }

    fun stopListening() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            _isListening.value = false
            _amplitude.value  = 0f
            _partialText.value = ""
            updateNotification("Ready to listen")
        }
    }

    private fun destroyRecognizer() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) { /* ignore — may already be dead */ }
        speechRecognizer = null
        _isListening.value = false
        _amplitude.value   = 0f
        _partialText.value = ""
    }

    // ── RecognitionListener ───────────────────────
    private fun buildListener() = object : RecognitionListener {

        override fun onReadyForSpeech(params: Bundle?) {
            _isListening.value = true
            updateNotification("Listening…")
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _amplitude.value = normalized
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            _amplitude.value = 0f
        }

        override fun onError(error: Int) {
            _isListening.value = false
            _amplitude.value   = 0f
            updateNotification("Ready to listen")

            // Always destroy after an error — leaving a failed recognizer
            // alive is what caused the repeated 2-second-then-die behaviour
            destroyRecognizer()

            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH          -> null // Silent — user just didn't speak
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT    -> null // Silent — user tapped but didn't speak
                SpeechRecognizer.ERROR_CLIENT            -> null // Internal reset — silent retry is fine
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY  -> "Microphone busy — please try again"
                SpeechRecognizer.ERROR_NETWORK           -> "Network error during recognition"
                SpeechRecognizer.ERROR_AUDIO             -> "Audio recording error — check mic permission"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "Microphone permission required — please grant it in Settings"
                SpeechRecognizer.ERROR_SERVER            -> "Recognition server error — try again"
                else -> null
            }
            msg?.let { _errorMessage.tryEmit(it) }
        }

        override fun onResults(results: Bundle?) {
            _isListening.value = false
            _amplitude.value   = 0f
            updateNotification("Ready to listen")

            val best = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()

            if (!best.isNullOrBlank()) {
                _recognizedText.tryEmit(best)
                _partialText.value = ""
            }

            // Destroy after a successful result too — ensures the next
            // tap always gets a clean fresh instance
            destroyRecognizer()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: return
            _partialText.value = partial
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ── Notification ──────────────────────────────
    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Heritage AI Voice Assistant", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Heritage AI voice recognition service"; setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_heritage_logo)
            .setContentTitle("Heritage AI")
            .setContentText(text)
            .setContentIntent(pending)
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        super.onDestroy()
    }
}
