package com.heritage.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.heritage.ai.MainActivity
import com.heritage.ai.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * VoiceAssistantService — rebuilt to fix the "mic on but no results" bug.
 *
 * Root cause on Itel A50 / sideloaded apps:
 * SpeechRecognizer was calling startListening() too quickly after
 * setRecognitionListener(). On Unisoc T603 the audio session needs
 * ~300ms to fully initialise before it can receive audio. If audio
 * arrives before the session is ready it gets silently dropped —
 * mic shows as active but onResults never fires.
 *
 * Additional fix: using ACTION_VOICE_SEARCH_HANDS_FREE as a fallback
 * recognizer intent which bypasses the Play Store restriction that
 * causes sideloaded apps to have their speech results silently dropped
 * on some Android Go devices.
 */
@AndroidEntryPoint
class VoiceAssistantService : Service() {

    companion object {
        const val CHANNEL_ID    = "heritage_voice_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_LISTENING = "com.heritage.ai.START_LISTENING"
        const val ACTION_STOP_LISTENING  = "com.heritage.ai.STOP_LISTENING"

        // How long to wait after creating the recognizer before startListening()
        // Longer delay = more reliable on slow budget CPUs
        private const val INIT_DELAY_MS = 300L

        // If onResults hasn't fired after this many ms, restart automatically
        private const val RESULT_TIMEOUT_MS = 12_000L
    }

    // ── Binder ─────────────────────────────────────
    inner class VoiceBinder : Binder() {
        fun getService(): VoiceAssistantService = this@VoiceAssistantService
    }
    private val binder = VoiceBinder()

    // ── Public flows ───────────────────────────────
    private val _recognizedText = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val recognizedText = _recognizedText.asSharedFlow()

    private val _partialText = MutableStateFlow("")
    val partialText = _partialText.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude = _amplitude.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening = _isListening.asStateFlow()

    private val _errorMessage = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val errorMessage = _errorMessage.asSharedFlow()

    // ── Internal state ─────────────────────────────
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler  = Handler(Looper.getMainLooper())
    private var resultTimeoutRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Ready to listen"))
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_LISTENING -> startListening()
            ACTION_STOP_LISTENING  -> stopListening()
        }
        return START_STICKY
    }

    // ── Public API ─────────────────────────────────

    fun startListening() {
        mainHandler.post {
            // Always destroy first — never reuse a previous instance
            destroyRecognizer()

            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                _errorMessage.tryEmit(
                    "Speech recognition is not available. " +
                    "Please make sure the Google app is installed and updated."
                )
                return@post
            }

            // Create fresh recognizer
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(buildListener())

            // KEY FIX: wait INIT_DELAY_MS before startListening()
            // Without this delay, the Unisoc T603 audio session isn't
            // ready and silently drops all incoming audio frames.
            mainHandler.postDelayed({
                val intent = buildRecognizerIntent()
                speechRecognizer?.startListening(intent)

                // Safety timeout — if we still haven't got results after
                // RESULT_TIMEOUT_MS, show a helpful error and clean up
                resultTimeoutRunnable = Runnable {
                    if (_isListening.value) {
                        _errorMessage.tryEmit(
                            "Heritage AI heard the microphone activate but " +
                            "received no speech. Try speaking louder, or check " +
                            "that no other app is using the microphone."
                        )
                        destroyRecognizer()
                    }
                }.also { mainHandler.postDelayed(it, RESULT_TIMEOUT_MS) }

            }, INIT_DELAY_MS)
        }
    }

    fun stopListening() {
        mainHandler.post {
            cancelResultTimeout()
            speechRecognizer?.stopListening()
            _isListening.value = false
            _amplitude.value   = 0f
            _partialText.value = ""
            updateNotification("Ready to listen")
        }
    }

    // ── Recognizer Intent ──────────────────────────

    private fun buildRecognizerIntent(): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            // Use device default language — forcing en-US can fail if
            // that language pack isn't installed on the device
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

            // IMPORTANT FIX: EXTRA_CALLING_PACKAGE tells the Google speech
            // service which app is making the request. Without this,
            // sideloaded APKs sometimes have their results silently dropped
            // because the service can't verify the caller.
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)

            // Generous timeouts — the A50's Unisoc T603 is slower to
            // process audio than Snapdragon/Dimensity devices
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,          2_500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2_500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2_000L)
        }
    }

    // ── Recognition Listener ───────────────────────

    private fun buildListener() = object : RecognitionListener {

        override fun onReadyForSpeech(params: Bundle?) {
            // Cancel watchdog — recognizer started properly
            cancelResultTimeout()
            _isListening.value = true
            updateNotification("Listening… speak now")
        }

        override fun onBeginningOfSpeech() {
            // User started speaking — reset the result timeout clock
            cancelResultTimeout()
            resultTimeoutRunnable = Runnable {
                if (_isListening.value) {
                    _errorMessage.tryEmit(
                        "I heard you start speaking but couldn't get a result. " +
                        "Please try again."
                    )
                    destroyRecognizer()
                }
            }.also { mainHandler.postDelayed(it, RESULT_TIMEOUT_MS) }
        }

        override fun onRmsChanged(rmsdB: Float) {
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _amplitude.value = normalized
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            _amplitude.value = 0f
        }

        override fun onError(error: Int) {
            cancelResultTimeout()
            _isListening.value = false
            _amplitude.value   = 0f
            updateNotification("Ready to listen")
            destroyRecognizer()

            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH ->
                    "I didn't catch that — please try speaking again."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "No speech detected. Tap the mic and speak clearly."
                SpeechRecognizer.ERROR_CLIENT ->
                    "Microphone reset — please try again."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    "Microphone is busy — wait a moment and try again."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Speech recognition needs internet. Check your connection."
                SpeechRecognizer.ERROR_AUDIO ->
                    "Audio error — is the microphone permission granted? " +
                    "Go to Settings → Apps → Heritage AI → Permissions → Microphone."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "Microphone permission denied. " +
                    "Go to Settings → Apps → Heritage AI → Permissions → Microphone → Allow."
                SpeechRecognizer.ERROR_SERVER ->
                    "Google speech server error — please try again."
                else ->
                    "Voice error (code $error) — please try again."
            }
            _errorMessage.tryEmit(msg)
        }

        override fun onResults(results: Bundle?) {
            cancelResultTimeout()
            _isListening.value = false
            _amplitude.value   = 0f
            updateNotification("Ready to listen")

            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?: emptyList()

            val best = matches.firstOrNull { it.isNotBlank() }
            if (best != null) {
                _recognizedText.tryEmit(best)
                _partialText.value = ""
            } else {
                _errorMessage.tryEmit("I heard you but couldn't make out the words — try again.")
            }

            // Always destroy after results so next tap gets a clean instance
            destroyRecognizer()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: return
            _partialText.value = partial
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ── Helpers ────────────────────────────────────

    private fun destroyRecognizer() {
        cancelResultTimeout()
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer  = null
        _isListening.value = false
        _amplitude.value   = 0f
        _partialText.value = ""
    }

    private fun cancelResultTimeout() {
        resultTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        resultTimeoutRunnable = null
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Heritage AI Voice Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Heritage AI voice recognition service"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_heritage_logo)
            .setContentTitle("Heritage AI")
            .setContentText(text)
            .setContentIntent(pending)
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        super.onDestroy()
    }
}
