package com.heritage.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.heritage.ai.MainActivity
import com.heritage.ai.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * VoiceAssistantService — foreground service that manages
 * Android SpeechRecognizer for continuous STT.
 *
 * Clients bind to this service and observe:
 * - [recognizedText] for final speech results
 * - [partialText] for real-time partial transcription
 * - [amplitude] for live microphone amplitude (0–1)
 * - [isListening] for current recording state
 */
@AndroidEntryPoint
class VoiceAssistantService : Service() {

    companion object {
        const val CHANNEL_ID = "heritage_voice_channel"
        const val NOTIFICATION_ID = 1001

        // Intent actions
        const val ACTION_START_LISTENING = "com.heritage.ai.START_LISTENING"
        const val ACTION_STOP_LISTENING = "com.heritage.ai.STOP_LISTENING"
    }

    // ── Binder ─────────────────────────────────────
    inner class VoiceBinder : Binder() {
        fun getService(): VoiceAssistantService = this@VoiceAssistantService
    }

    private val binder = VoiceBinder()

    // ── Public state flows (observed by UI/ViewModel) ──
    private val _recognizedText = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val recognizedText = _recognizedText.asSharedFlow()

    private val _partialText = MutableStateFlow("")
    val partialText = _partialText.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude = _amplitude.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening = _isListening.asStateFlow()

    private val _errorMessage = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val errorMessage = _errorMessage.asSharedFlow()

    // ── SpeechRecognizer ───────────────────────────
    private var speechRecognizer: SpeechRecognizer? = null
    private var isBound = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Ready to listen"))
        initSpeechRecognizer()
    }

    override fun onBind(intent: Intent?): IBinder {
        isBound = true
        return binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isBound = false
        return true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_LISTENING -> startListening()
            ACTION_STOP_LISTENING -> stopListening()
        }
        return START_STICKY
    }

    // ── SpeechRecognizer setup ─────────────────────
    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
                updateNotification("Listening…")
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                // Normalize RMS to 0–1 for the visualizer
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                _amplitude.value = normalized
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _amplitude.value = 0f
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _amplitude.value = 0f
                updateNotification("Ready to listen")

                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that — try again"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
                    SpeechRecognizer.ERROR_NETWORK -> "Network error during recognition"
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                    else -> null
                }
                msg?.let { _errorMessage.tryEmit(it) }
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                _amplitude.value = 0f
                updateNotification("Ready to listen")

                val matches = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val best = matches?.firstOrNull()
                if (!best.isNullOrBlank()) {
                    _recognizedText.tryEmit(best)
                    _partialText.value = ""
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: return
                _partialText.value = partial
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    // ── Public API ─────────────────────────────────
    fun startListening() {
        if (_isListening.value) return
        speechRecognizer ?: initSpeechRecognizer()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 500)
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        _isListening.value = false
        _amplitude.value = 0f
        _partialText.value = ""
    }

    // ── Notification ───────────────────────────────
    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Heritage AI Voice Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Heritage AI voice recognition service"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val mainIntent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingMain = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_heritage_logo)
            .setContentTitle("Heritage AI")
            .setContentText(text)
            .setContentIntent(pendingMain)
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }
}
