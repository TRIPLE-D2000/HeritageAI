package com.heritage.ai.util

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ButtonTriggerManager — detects physical button presses to activate
 * Heritage AI hands-free without a wake word.
 *
 * Default trigger: Volume DOWN long-press (600ms).
 * This is the same pattern used by Samsung's Bixby button and many
 * Android voice assistant triggers. It does not interfere with normal
 * volume adjustment (short press still works as expected).
 *
 * The actual key event interception happens in MainActivity.onKeyDown().
 * This manager holds the timing state and emits the trigger event.
 */
@Singleton
class ButtonTriggerManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        // How long the button must be held to trigger voice (ms)
        const val LONG_PRESS_DURATION_MS = 600L
    }

    private val _voiceTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val voiceTrigger = _voiceTrigger.asSharedFlow()

    private val handler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null
    private var isEnabled = true

    /**
     * Call from MainActivity.onKeyDown() for volume-down key events.
     * Returns true if the event was consumed (long press handled),
     * false if it should be passed through to the system.
     */
    fun onKeyDown(keyCode: Int): Boolean {
        if (!isEnabled) return false
        if (keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        // Schedule the long-press trigger
        longPressRunnable = Runnable {
            _voiceTrigger.tryEmit(Unit)
        }
        handler.postDelayed(longPressRunnable!!, LONG_PRESS_DURATION_MS)

        // Don't consume the event yet — let the system handle it normally
        // If the user releases before LONG_PRESS_DURATION_MS, we cancel below
        return false
    }

    /**
     * Call from MainActivity.onKeyUp() for volume-down key events.
     * Cancels the long-press if the button was released too soon.
     */
    fun onKeyUp(keyCode: Int): Boolean {
        if (keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        longPressRunnable?.let {
            handler.removeCallbacks(it)
            longPressRunnable = null
        }
        return false
    }

    fun isEnabled(): Boolean = isEnabled

    fun setEnabled(enabled: Boolean) {
        isEnabled = enabled
        if (!enabled) {
            longPressRunnable?.let { handler.removeCallbacks(it) }
            longPressRunnable = null
        }
    }

    fun destroy() {
        handler.removeCallbacksAndMessages(null)
    }
}
