package com.heritage.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.heritage.ai.util.ButtonTriggerManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject

/**
 * HeritageAccessibilityService — UI automation + physical button trigger.
 *
 * The volume-button trigger lives here because the Accessibility Service
 * is the ONLY way to intercept key events from the background on a
 * non-rooted Android device. Activity.onKeyDown() only fires when the
 * app is in the foreground — this service catches it from anywhere.
 *
 * Requires: android:canRequestFilterKeyEvents="true" in service config
 * and flagRequestFilterKeyEvents in accessibilityFlags.
 */
@AndroidEntryPoint
class HeritageAccessibilityService : AccessibilityService() {

    companion object {
        var instance: HeritageAccessibilityService? = null
            private set

        private val _events = MutableSharedFlow<AccessibilityEvent>(extraBufferCapacity = 16)
        val events = _events.asSharedFlow()

        // How long volume-down must be held to trigger voice (ms)
        private const val LONG_PRESS_MS = 600L
    }

    @Inject
    lateinit var buttonTriggerManager: ButtonTriggerManager

    private val handler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null
    private var volumeDownPressTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        _events.tryEmit(event)
    }

    /**
     * Intercepts key events from anywhere on the device.
     * Detects volume-down long-press and triggers Heritage AI voice.
     * Returns false so the system also handles normal volume changes.
     */
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        event ?: return false

        // Only handle volume down
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        // Check if button trigger is enabled
        if (!buttonTriggerManager.isEnabled()) return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                // First press only — ignore system repeat events
                if (event.repeatCount == 0) {
                    volumeDownPressTime = System.currentTimeMillis()
                    // Schedule the long-press action
                    longPressRunnable = Runnable {
                        onVolumeLongPress()
                    }
                    handler.postDelayed(longPressRunnable!!, LONG_PRESS_MS)
                }
            }
            KeyEvent.ACTION_UP -> {
                val heldMs = System.currentTimeMillis() - volumeDownPressTime
                // Cancel scheduled long press
                longPressRunnable?.let { handler.removeCallbacks(it) }
                longPressRunnable = null

                // If released before long-press threshold — let system handle
                // volume change normally by returning false
                if (heldMs >= LONG_PRESS_MS) {
                    // Long press was handled — consume this UP event
                    return true
                }
            }
        }

        // Return false = system still adjusts volume on short press ✅
        return false
    }

    private fun onVolumeLongPress() {
        // Open Heritage AI and start voice immediately
        val intent = Intent(this, com.heritage.ai.MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("auto_start_voice", true)
        }
        startActivity(intent)

        // Also broadcast so VoiceOrchestrator starts listening
        val broadcast = Intent("com.heritage.ai.START_VOICE_FROM_WAKE").apply {
            setPackage(packageName)
        }
        sendBroadcast(broadcast)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ── Public Automation API ──────────────────────

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putString(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findByText(root, label) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root) ?: return false
        val action = if (forward)
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable.performAction(action)
    }

    fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 50L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collectText(root, sb)
        return sb.toString().trim()
    }

    fun pressBack()    = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome()    = performGlobalAction(GLOBAL_ACTION_HOME)
    fun pressRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    private fun findByText(node: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        if ((text.contains(label, ignoreCase = true) || desc.contains(label, ignoreCase = true))
            && node.isClickable) return node
        for (i in 0 until node.childCount) {
            findByText(node.getChild(i) ?: continue, label)?.let { return it }
        }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            findScrollable(node.getChild(i) ?: continue)?.let { return it }
        }
        return null
    }

    private fun collectText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.appendLine(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i) ?: return, sb)
    }
}
