package com.heritage.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * HeritageAccessibilityService — user-approved UI automation.
 *
 * This service is ONLY active after the user explicitly enables it in
 * Accessibility Settings. It can:
 *   - Type text into focused fields
 *   - Click buttons and UI elements by content description / text
 *   - Scroll views
 *   - Perform global gestures (swipe, tap by coordinates)
 *   - Read on-screen text (for context-aware responses)
 *
 * All actions require the user's explicit voice command or confirmation.
 * Heritage AI never autonomously acts on this service without user intent.
 */
class HeritageAccessibilityService : AccessibilityService() {

    companion object {
        /** Singleton reference — safe because only one instance exists at a time. */
        var instance: HeritageAccessibilityService? = null
            private set

        private val _events = MutableSharedFlow<AccessibilityEvent>(extraBufferCapacity = 16)
        val events = _events.asSharedFlow()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        _events.tryEmit(event)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ── Public Automation API ──────────────────────

    /**
     * Types [text] into the currently focused input field.
     */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putString(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /**
     * Clicks a UI element whose text or content description contains [label].
     */
    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findByText(root, label) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * Scrolls a scrollable view down ([forward] = true) or up (false).
     */
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root) ?: return false
        val action = if (forward)
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable.performAction(action)
    }

    /**
     * Performs a tap at screen coordinates [x], [y].
     */
    fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 50L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Performs a swipe from ([x1],[y1]) to ([x2],[y2]) over [durationMs].
     */
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Returns all visible text on the current screen, joined by newlines.
     */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collectText(root, sb)
        return sb.toString().trim()
    }

    /**
     * Presses the system Back button.
     */
    fun pressBack() = performGlobalAction(GLOBAL_ACTION_BACK)

    /**
     * Opens the Home screen.
     */
    fun pressHome() = performGlobalAction(GLOBAL_ACTION_HOME)

    /**
     * Opens the Recents screen.
     */
    fun pressRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    // ── Private helpers ────────────────────────────

    private fun findByText(node: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString() ?: ""
        val nodeDesc = node.contentDescription?.toString() ?: ""
        if (nodeText.contains(label, ignoreCase = true) ||
            nodeDesc.contains(label, ignoreCase = true)) {
            if (node.isClickable) return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findByText(child, label)
            if (found != null) return found
        }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollable(child)
            if (found != null) return found
        }
        return null
    }

    private fun collectText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        val text = node.text?.toString()
        if (!text.isNullOrBlank()) sb.appendLine(text)
        for (i in 0 until node.childCount) {
            collectText(node.getChild(i) ?: continue, sb)
        }
    }
}
