package com.heritage.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.heritage.ai.util.ButtonTriggerManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject

/**
 * HeritageAccessibilityService — UI automation + physical button trigger.
 *
 * The volume-button trigger lives here because the Accessibility Service
 * is the ONLY way to intercept key events from the background on a
 * non-rooted Android device. Activity.onKeyDown() only fires when the
 * app is in the foreground — this service catches it from anywhere.
 *
 * Requires: android:canRequestFilterKeyEvents="true" in service config
 * and flagRequestFilterKeyEvents in accessibilityFlags.
 */
@AndroidEntryPoint
class HeritageAccessibilityService : AccessibilityService() {

    companion object {
        var instance: HeritageAccessibilityService? = null
            private set

        private val _events = MutableSharedFlow<AccessibilityEvent>(extraBufferCapacity = 16)
        val events = _events.asSharedFlow()

        // How long volume-down must be held to trigger voice (ms)
        const val MULTI_PRESS_WINDOW_MS = 500L
        const val REQUIRED_PRESSES = 3
    }

    @Inject
    lateinit var buttonTriggerManager: ButtonTriggerManager

    private val handler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null
    private var pressCount = 0
    private var lastPressTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        _events.tryEmit(event)
    }

    /**
     * Intercepts key events from anywhere on the device.
     * Detects 3 quick volume-down presses to trigger Heritage AI.
     *
     * Triple-press logic:
     * - Each press must happen within 500ms of the previous one
     * - After 3 presses: show the Siri-style overlay, do NOT open full app
     * - Normal single/double presses still adjust volume normally
     * - Returns false so system handles volume on non-trigger presses
     */
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        event ?: return false
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!buttonTriggerManager.isEnabled()) return false

        // Only count fresh presses, not system key-repeat events
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false

        val now = System.currentTimeMillis()

        // Reset counter if too much time has passed since last press
        if (now - lastPressTime > MULTI_PRESS_WINDOW_MS) {
            pressCount = 0
        }

        pressCount++
        lastPressTime = now

        if (pressCount >= REQUIRED_PRESSES) {
            pressCount = 0
            // Cancel any pending reset
            longPressRunnable?.let { handler.removeCallbacks(it) }
            // Launch the floating overlay — do NOT open the full app
            onTriplePressDetected()
            return true // Consume this event — don't let system change volume
        }

        // Schedule a reset in case user stops pressing
        longPressRunnable?.let { handler.removeCallbacks(it) }
        longPressRunnable = Runnable { pressCount = 0 }
        handler.postDelayed(longPressRunnable!!, MULTI_PRESS_WINDOW_MS)

        return false // Let system handle volume normally for non-trigger presses
    }

    private fun onTriplePressDetected() {
        // Launch the lightweight floating overlay — no full app open needed
        // This is the Siri-style experience: small popup, listens, dismisses
        val intent = Intent(this, QuickVoiceOverlayService::class.java)
        startForegroundService(intent)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ── Public Automation API ──────────────────────

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putString(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findByText(root, label) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollable(root) ?: return false
        val action = if (forward)
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable.performAction(action)
    }

    fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 50L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collectText(root, sb)
        return sb.toString().trim()
    }

    fun pressBack()    = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome()    = performGlobalAction(GLOBAL_ACTION_HOME)
    fun pressRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    private fun findByText(node: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        if ((text.contains(label, ignoreCase = true) || desc.contains(label, ignoreCase = true))
            && node.isClickable) return node
        for (i in 0 until node.childCount) {
            findByText(node.getChild(i) ?: continue, label)?.let { return it }
        }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            findScrollable(node.getChild(i) ?: continue)?.let { return it }
        }
        return null
    }

    private fun collectText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.appendLine(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i) ?: return, sb)
    }
}
