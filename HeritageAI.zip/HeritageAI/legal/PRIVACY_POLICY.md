HERITAGE AI PRIVACY POLICY
Version: 2026-11-22

1. WHO WE ARE
Heritage AI is an Android voice and chat assistant built by Daniel Damilare, an independent developer in Nigeria ("we", "us"). We are the data controller for the personal data described in this policy. Contact: dandamdad2000@gmail.com

2. THE SHORT VERSION
• Your chats, memories and settings are stored on your phone, in an encrypted database.
• To answer you, your message and some context (listed in section 4) is sent over the internet to AI services.
• We do not sell your data and we do not show ads.
• You can delete everything at any time: Settings > Legal & Privacy > Delete all my data.

3. WHAT WE COLLECT AND WHY
• What you give us: messages you type or speak, your name and "about yourself" text if you add them, your settings, photos you choose to share with the assistant (taken with the camera or picked from your gallery), and an API key if you choose to use your own AI provider.
• What the app creates on your phone: conversation history, summaries, and "memories" (facts the assistant saves so it can help you better).
• Device information the app uses only when needed: the list of apps installed on your phone (so it can open them), your notifications (only when you ask about them), your contacts (so you can call or text people by name), and the Android features you switch on (see section 6).
We use this to answer you, carry out device actions you ask for, remember useful context, and keep the app working and secure.

4. WHAT LEAVES YOUR PHONE
When you send a message, the app sends it to our server (hosted on Cloudflare), which forwards it to AI providers: Groq (the language model) and, for web lookups, Tavily (search). A request can include:
• your message and recent conversation;
• a photo, only when you attach one: it is shrunk first and sent with that one message to an AI vision model run by Groq (earlier photos are never re-sent);
• your name, "about yourself" text and saved memories;
• the current date and time;
• the names of apps installed on your phone;
• your notifications, only when your message asks about notifications, alerts or messages, with numeric codes hidden.
Contacts: your contact list is never uploaded. Name matching happens on your phone. If you ask the assistant to look up a contact, the result is shown in the chat and becomes part of the conversation, so it may be sent with later messages. Delete the conversation if you do not want that.
Voice: speech-to-text uses Android's speech recognition service, which may process audio on your phone or send it to Google under Google's terms. Wake-word detection runs on your phone; that audio is not recorded or sent.
Reporting a reply: if you tap the flag on an AI reply and send a report, that reply text and the reason you chose are sent to us so we can review it. Nothing else from your chat is included.
Your own AI provider: if you add your own key, requests go to that provider (for example OpenAI) under its terms and privacy policy.
International transfers: these providers operate outside Nigeria (for example in the United States), so your data is transferred internationally. By accepting this policy you agree to that transfer.
We do not intentionally store the content of your messages on our own server. Cloudflare keeps technical logs for each request (such as time, your IP address, approximate location such as city, your network provider, device type and request size), but not the text of your message, and AI providers may keep data under their own policies.

5. LEGAL BASIS
We process your data on the basis of your consent, given when you accept this policy, and to provide the service you ask for. You can withdraw consent at any time by deleting your data in Settings or uninstalling the app. Withdrawing consent does not affect processing already done.

6. PERMISSIONS
Every permission is optional, is used only for the feature it belongs to, and can be turned off in your phone settings.
• Microphone: voice questions and wake word.
• Camera (optional): taking a photo to ask about. Choosing a photo from your gallery uses Android's photo picker, which only shares the pictures you select.
• Contacts and Phone: calling and texting people by name.
• Notification access: reading notifications when you ask.
• Accessibility service: only to notice three presses of the volume-down button so the assistant can open from any screen. It ignores other keys and does not read or store what is on your screen.
• Display over other apps: the quick-answer window.
• Modify system settings: brightness control.
We do not use these permissions to collect data for any other purpose.

7. SECURITY AND STORAGE
Your conversations are stored in a database encrypted with a key kept in the Android Keystore, and photos you share are stored encrypted on your phone the same way. A personal API key you add is encrypted on your phone. Traffic to our server and to AI providers uses HTTPS. No system is perfectly secure, so please keep your phone locked and updated.

8. RETENTION
Data, including photos you shared, stays on your phone until you delete the chat, use Delete all my data, or uninstall the app. We keep no account for you on our servers.

9. YOUR RIGHTS
Under the Nigeria Data Protection Act 2023 you have the right to access, correct, delete and restrict the use of your personal data, to object to processing, to data portability, and to withdraw consent. Most of this you can do inside the app. For anything else, email dandamdad2000@gmail.com. You also have the right to complain to the Nigeria Data Protection Commission (www.ndpc.gov.ng).

10. CHILDREN
Heritage AI is not for people under 18, and we do not knowingly collect data from them. If you believe a child has used the app, contact us and we will help delete the data.

11. CHANGES
If we change this policy in a meaningful way, the app will ask you to review and accept it again.

12. CONTACT
Daniel Damilare, Nigeria. Email: dandamdad2000@gmail.com
