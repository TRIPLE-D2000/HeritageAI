HERITAGE AI TERMS OF SERVICE
Version: 2026-11-22

1. ACCEPTING THESE TERMS
By tapping "Accept and continue" or using Heritage AI you agree to these Terms and to the Privacy Policy. You must be 18 or older. If you do not agree, do not use the app.

2. THE SERVICE
Heritage AI is an AI assistant for Android that answers questions and can act on your phone when you ask. It is early-stage software provided by Daniel Damilare ("we", "us"). Features may change, break or be removed. Future paid features, if any, may have extra terms.

3. AI CAN BE WRONG
AI answers can be incorrect, incomplete or out of date. Check anything important before you rely on it. Heritage AI does not give professional medical, legal, financial or safety advice. Do not use it for emergencies: to reach emergency services, use your phone's normal dialer.

4. ACTIONS ON YOUR PHONE
When you ask, the assistant can open apps, change settings, call numbers, and prepare text messages. You authorise these actions. Voice recognition and AI can mishear or misunderstand, so check the dialer or message before you confirm. You are responsible for calls and messages made from your phone, including airtime or other charges. We are not responsible for a wrong contact, wrong number or unintended action.

5. YOUR CONTENT AND OTHER PEOPLE'S INFORMATION
You keep ownership of what you type, say or store. You allow us to process it to provide the service as described in the Privacy Policy. If you use contacts, you are responsible for using other people's information lawfully and respectfully. Do not use the app to harass, spam, deceive or threaten anyone. Only share photos you have the right to share, and do not share illegal or abusive images.

6. ACCEPTABLE USE
You agree not to: break the law; use the app to harm others; try to break, overload or misuse our server or the AI services behind it; copy or reverse-engineer the app except where the law allows; or use automated means to get around any limits.

7. THIRD-PARTY SERVICES
The app depends on services we do not control, including Cloudflare, Groq, Tavily and Google speech recognition. They may change, fail or stop working, and their own terms apply to their part of the service.

8. OUR RIGHTS
The app, its name and its design belong to Daniel Damilare. We give you a personal, non-exclusive, non-transferable licence to use the app. Open-source components remain under their own licences.

9. SUSPENSION AND ENDING
You can stop using the app at any time. We may suspend or end access if these Terms are broken or to protect the service or other people.

10. NO WARRANTY
To the extent allowed by law, the app is provided "as is" and "as available", without promises that it will be accurate, uninterrupted or error-free.

11. LIMIT OF LIABILITY
To the extent allowed by law, we are not liable for indirect or consequential loss, lost data, lost profit, or loss caused by AI answers or by actions you confirm. Our total liability for any claim is limited to the amount you paid us for the app in the previous 12 months, which is nothing if the app is free. Nothing in these Terms limits liability that cannot be limited under Nigerian law.

12. GOVERNING LAW
These Terms are governed by the laws of the Federal Republic of Nigeria, and the courts of Nigeria have jurisdiction, subject to any mandatory consumer rights you have.

13. CHANGES AND CONTACT
We may update these Terms. If the change is meaningful, the app will ask you to accept the new version. Questions: dandamdad2000@gmail.com
