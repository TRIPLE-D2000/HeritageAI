# Heritage AI — Android AI Assistant

<p align="center">
  <img src="docs/banner.png" alt="Heritage AI banner" width="600"/>
</p>

> **Heritage AI** is a production-ready, privacy-first AI assistant for Android — built with Kotlin, Jetpack Compose, and MVVM architecture. It rivals Siri and Google Assistant in capability while keeping your conversations encrypted locally and your data under your control.

---

## Table of Contents

1. [Features](#features)
2. [Architecture](#architecture)
3. [Tech Stack](#tech-stack)
4. [Project Structure](#project-structure)
5. [Getting Started](#getting-started)
6. [Configuration](#configuration)
7. [Device Compatibility](#device-compatibility)
8. [Permissions Guide](#permissions-guide)
9. [Plugin System](#plugin-system)
10. [Security & Privacy](#security--privacy)
11. [Known Limitations](#known-limitations)
12. [Roadmap](#roadmap)

---

## Features

### 🎙️ Voice & Conversation
| Feature | Status | Notes |
|---|---|---|
| Speech-to-Text (STT) | ✅ | Android SpeechRecognizer, real-time partial transcript |
| Text-to-Speech (TTS) | ✅ | Android TTS engine, adjustable speed & pitch |
| Wake word "Hey Heritage" | ⚠️ Skeleton | Audio capture loop ready; needs Porcupine/openWakeWord engine integration |
| Continuous voice recognition | ✅ | Foreground service with binder + VoiceOrchestrator bridge |
| Offline basic commands | ✅ | Pattern-matched locally; no network needed |
| Natural conversation + memory | ✅ | Long-term memory via LLM extraction, injected into every prompt |

### 🤖 AI / LLM
| Feature | Status |
|---|---|
| OpenAI (GPT-4o, GPT-4o-mini, etc.) | ✅ |
| Groq (Llama 3.3, Mixtral) | ✅ |
| Together AI | ✅ |
| Ollama (local LLM) | ✅ |
| Dynamic provider switching | ✅ |
| Adjustable temperature / max tokens | ✅ |
| Long-term memory extraction | ✅ |

### 📱 Device Control
- ✅ Flashlight (on/off/toggle)
- ✅ Volume (media, ring, alarm, notification)
- ✅ Screen brightness
- ✅ Wi-Fi toggle (panel on Android 10+)
- ✅ Bluetooth toggle
- ✅ Alarm creation via system clock
- ✅ Do Not Disturb
- ✅ App launcher (by name or package)

### 🔧 System Integration
- ✅ Floating assistant bubble (overlay, drag-to-reposition, snap-to-edge)
- ✅ Accessibility service (type text, tap, scroll, swipe, read screen)
- ✅ Notification listener (read & summarise active notifications)
- ✅ Contact search
- ✅ Calendar read & event creation
- ✅ File search via MediaStore
- ✅ Camera intent launch
- ✅ Screenshot capture (MediaProjection — requires per-session user consent)
- ✅ Boot receiver (auto-restart wake-word & bubble after reboot)

### 🎭 Automation Routines
Five built-in routines, all fully editable:
- 📚 **Study Mode** — mute ring, max brightness, DND on
- 🎮 **Gaming Mode** — max media volume, DND, full brightness
- ☀️ **Good Morning** — soft brightness, gentle volume, greeting
- 🌙 **Sleep Mode** — total silence, min brightness, DND
- 💪 **Workout Mode** — max music volume, DND, open music app

### 🎨 UI / UX
- ✅ Material 3 with Heritage brand palette (violet → teal gradient)
- ✅ Dark and light themes, system-theme follow
- ✅ Animated voice orb with amplitude-reactive pulse
- ✅ Typing indicator (three-dot wave animation)
- ✅ Message bubbles with timestamps
- ✅ Conversation history with search
- ✅ Quick-suggestion chips on empty state
- ✅ Offline indicator badge
- ✅ Adaptive performance mode for low-RAM/Go Edition devices

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│                   PRESENTATION                   │
│  ChatScreen  SettingsScreen  HistoryScreen        │
│  RoutinesScreen                                   │
│  ↕ StateFlow / SharedFlow (unidirectional)       │
│  ChatViewModel  SettingsViewModel  ...            │
└────────────────────┬────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────┐
│                    DOMAIN                        │
│  ChatRepository  MemoryRepository               │
│  RoutineRepository  (interfaces only)            │
│  Models: Message, Conversation, Memory, Routine  │
└────────────────────┬────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────┐
│                     DATA                         │
│  ChatRepositoryImpl — LLM API + Room             │
│  MemoryRepositoryImpl — Room + LLM extraction    │
│  RoutineRepositoryImpl — Room                    │
│  AppPreferences — DataStore                      │
│  DatabaseEncryption — Android Keystore           │
└──────────┬───────────────────┬──────────────────┘
           │                   │
    ┌──────▼──────┐    ┌───────▼──────┐
    │  Room DB    │    │  Retrofit +  │
    │  SQLCipher  │    │  OkHttp LLM  │
    │  (AES-256)  │    │  API client  │
    └─────────────┘    └──────────────┘
```

**Pattern**: MVVM + Repository + single-activity Compose navigation. The ViewModel never holds Android framework types; Services communicate via the `VoiceOrchestrator` singleton (binder bridge → StateFlow). All state flows downward; all events flow upward as sealed `ChatEvent` objects.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Kotlin 2.0 |
| UI | Jetpack Compose + Material 3 |
| Architecture | MVVM + Clean Architecture |
| DI | Hilt (Dagger) |
| Database | Room + SQLCipher (AES-256 encrypted) |
| Key storage | Android Keystore |
| Preferences | Jetpack DataStore |
| Networking | Retrofit 2 + OkHttp 4 |
| Background | WorkManager (Hilt-Worker) |
| Navigation | Compose Navigation |
| Voice (STT) | Android SpeechRecognizer |
| Voice (TTS) | Android TextToSpeech |
| Permissions | Accompanist Permissions |
| Images | Coil |

---

## Project Structure

```
HeritageAI/
├── app/src/main/java/com/heritage/ai/
│   ├── HeritageApplication.kt       # @HiltAndroidApp, notification channels, WorkManager
│   ├── MainActivity.kt              # Single activity, theme, edge-to-edge
│   ├── data/
│   │   ├── local/
│   │   │   ├── dao/         Daos.kt           # ConversationDao, MessageDao, MemoryDao, RoutineDao
│   │   │   ├── database/    HeritageDatabase.kt   # Room + SQLCipher encrypted DB
│   │   │   ├── entity/      Entities.kt       # Room entities + mappers
│   │   │   └── crypto/      DatabaseEncryption.kt # Keystore-backed passphrase management
│   │   ├── preferences/     AppPreferences.kt # DataStore settings
│   │   ├── remote/
│   │   │   ├── api/         LLMApi.kt         # Retrofit OpenAI-compatible interface
│   │   │   ├── interceptor/ Interceptors.kt   # Auth + dynamic base URL
│   │   │   └── model/       ApiModels.kt      # Request/response + system prompt builder
│   │   └── repository/      *RepositoryImpl.kt # Concrete repository implementations
│   ├── di/
│   │   ├── DiModules.kt     # Database, Network, Repository Hilt modules
│   │   └── PluginModule.kt  # Plugin registry wiring
│   ├── domain/
│   │   ├── model/           Models.kt         # Message, Conversation, Memory, Routine, etc.
│   │   └── repository/      Repositories.kt   # Repository interfaces (pure Kotlin)
│   ├── plugin/
│   │   ├── HeritagePlugin.kt         # Plugin interface + PluginRegistry + PluginResult
│   │   └── plugins/
│   │       └── BuiltInPlugins.kt     # Flashlight, AppLauncher, Volume, Alarm, Connectivity
│   ├── presentation/
│   │   ├── chat/
│   │   │   ├── ChatScreen.kt         # Main assistant UI
│   │   │   └── ChatViewModel.kt      # Core logic: voice, LLM, offline routing
│   │   ├── history/    HistoryScreen.kt   # Conversation history + search
│   │   ├── routines/   RoutinesScreen.kt  # Automation routines management
│   │   ├── settings/   SettingsScreen.kt  # LLM config, voice, theme, permissions
│   │   ├── components/
│   │   │   ├── Components.kt         # MessageBubble, VoiceOrb, TypingIndicator, etc.
│   │   │   └── VoiceOverlay.kt       # Full-screen voice recognition modal
│   │   ├── navigation/  NavGraph.kt   # Compose Navigation + route constants
│   │   └── theme/
│   │       ├── Color.kt              # Brand color palette
│   │       ├── Theme.kt              # Material 3 dark/light color schemes
│   │       ├── Type.kt               # Typography + Shapes
│   │       └── PerformanceLocals.kt  # LocalIsLowRamDevice composition local
│   ├── service/
│   │   ├── VoiceAssistantService.kt          # SpeechRecognizer foreground service
│   │   ├── WakeWordService.kt                # Always-on mic listener (skeleton)
│   │   ├── FloatingBubbleService.kt          # Overlay bubble
│   │   ├── HeritageAccessibilityService.kt   # UI automation
│   │   └── HeritageNotificationListenerService.kt
│   ├── util/
│   │   ├── VoiceOrchestrator.kt      # Service binder bridge → ViewModel flows
│   │   ├── DeviceControlManager.kt   # Flashlight, volume, brightness, Wi-Fi, BT, alarm, app
│   │   ├── CommandParser.kt          # LLM JSON command extraction + offline pattern matcher
│   │   ├── TextToSpeechManager.kt    # TTS coroutine wrapper
│   │   ├── NetworkConnectivityObserver.kt    # Online/offline reactive state
│   │   ├── DeviceCapabilities.kt     # Low-RAM / Go Edition detection
│   │   ├── PermissionHelper.kt       # Centralised permission status queries
│   │   ├── FileSearchManager.kt      # MediaStore file search
│   │   ├── ContactManager.kt         # Contacts content provider
│   │   ├── CalendarManager.kt        # Calendar events read + create
│   │   ├── CameraScreenshotManagers.kt # Camera intent + MediaProjection screenshot
│   │   └── BootReceiver.kt           # Restart services after reboot
│   └── worker/
│       └── Workers.kt  # MemoryMaintenanceWorker, ReminderWorker, RoutineExecutionWorker
└── app/src/main/res/
    ├── drawable/       # ic_heritage_logo.xml, adaptive icon layers
    ├── mipmap-anydpi-v26/  # Adaptive launcher icons (minSdk 26)
    ├── values/         # colors.xml, strings.xml, themes.xml
    └── xml/            # accessibility config, backup rules, network security, file paths
```

---

## Getting Started

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or later
- JDK 17
- Android SDK 35
- An API key from at least one of: [OpenAI](https://platform.openai.com), [Groq](https://console.groq.com), [Together AI](https://api.together.xyz)

### 1. Clone and open
```bash
git clone https://github.com/yourname/HeritageAI.git
cd HeritageAI
# Open in Android Studio via File → Open
```

### 2. Set SDK path
Android Studio creates `local.properties` automatically. If building from CLI:
```
# local.properties
sdk.dir=/path/to/Android/Sdk
```

### 3. Build
```bash
./gradlew assembleDebug
```
Or press **▶ Run** in Android Studio.

### 4. First launch — enter your API key
1. Open Heritage AI → tap the **⚙️** icon → **Settings**
2. Under **AI Model**: select your provider (OpenAI, Groq, etc.)
3. Paste your API key — it's stored encrypted on-device using the Android Keystore
4. Hit **Save**
5. Start chatting!

---

## Configuration

### Switching LLM providers
In Settings → AI Model, choose any supported provider. The base URL and default model are set automatically; you can override the model from the dropdown.

| Provider | Free tier? | Speed | Best for |
|---|---|---|---|
| OpenAI (GPT-4o) | No | Medium | Best quality |
| Groq (Llama 3.3 70B) | Yes (rate-limited) | Very fast | Daily use |
| Together AI | Yes (credits) | Fast | Open models |
| Ollama (local) | Free (your hardware) | Depends on your machine | Maximum privacy |

### Ollama setup (fully local, zero data leaves device)
1. Install [Ollama](https://ollama.ai) on your PC/Mac
2. Run: `ollama pull llama3.2 && ollama serve`
3. Connect PC and phone to the same Wi-Fi, find PC's local IP (e.g. `192.168.1.10`)
4. In Heritage AI Settings → Provider: **Ollama (Local)**
5. Change the base URL to `http://192.168.1.10:11434/v1/`
6. No API key needed

### Wake Word (advanced)
The wake-word audio capture loop is production-ready but the actual keyword detection needs a model engine:

1. Sign up free at [console.picovoice.ai](https://console.picovoice.ai)
2. Add to `build.gradle.kts`: `implementation("ai.picovoice:porcupine-android:3.x.x")`
3. In `WakeWordService.kt`, replace the `detectWakeWord()` stub with the Porcupine SDK callback

---

## Device Compatibility

| Spec | Minimum | Recommended |
|---|---|---|
| Android | 8.0 (API 26) | 12+ (API 31) |
| RAM | 2GB | 4GB+ |
| Storage (app) | ~30MB | — |
| Internet | Required for LLM | Not required for device commands |

### Itel A50 / Android Go Edition
Heritage AI detects Go Edition devices automatically using `ActivityManager.isLowRamDevice()` and activates **Performance Mode**:
- Skips multi-layer GPU glow effects in the voice orb
- Skips the backdrop blur in the voice overlay modal
- Reduces simultaneous animation count

All core features (voice, chat, device control, routines) work exactly the same — only the visual extras are simplified to prevent jank on the Unisoc T603 / PowerVR GE8322 GPU. You'll still get the full gradient orb, animated typing indicator, and smooth screen transitions.

---

## Permissions Guide

Heritage AI requests permissions only when a feature is first used and explains why.

| Permission | Feature | When asked |
|---|---|---|
| `RECORD_AUDIO` | Voice input | First mic tap |
| `CAMERA` | Flashlight + camera | Flashlight command |
| `READ_CONTACTS` | Contact search | "Call / text [name]" |
| `READ_CALENDAR` | Calendar queries | "What's on my calendar?" |
| `WRITE_CALENDAR` | Create events | "Add event to calendar" |
| `POST_NOTIFICATIONS` | Reminders | First reminder set |
| Overlay (Settings) | Floating bubble | Enabling bubble in Settings |
| Accessibility (Settings) | Automation (type, tap) | Enabling in Settings |
| Notification Listener (Settings) | Read notifications | Enabling in Settings |
| Modify System Settings | Brightness control | Brightness command |

**Special permissions** (Accessibility, Notification Listener, Overlay) open the system Settings page directly — Android requires explicit user navigation, not a dialog.

---

## Plugin System

Add capabilities to Heritage AI without touching the core pipeline:

```kotlin
// 1. Implement HeritagePlugin
@Singleton
class SpotifyPlugin @Inject constructor(
    private val spotifyApi: SpotifyApi
) : HeritagePlugin {

    override val id = "spotify"
    override val displayName = "Spotify"
    override val description = "Controls Spotify playback"
    override val requiresNetwork = true

    override fun canHandle(input: String) =
        input.lowercase().contains("spotify") ||
        input.lowercase().contains("play ")

    override suspend fun execute(context: PluginContext): PluginResult {
        val track = context.parameters["track"] ?: return PluginResult.Failure("No track specified")
        spotifyApi.play(track)
        return PluginResult.Success("Now playing: $track")
    }

    override fun commandSchema() =
        """{"action": "SPOTIFY_PLAY", "params": {"track": "<song name>"}} — Plays a Spotify track"""
}

// 2. Register in your own Hilt module
@Module @InstallIn(SingletonComponent::class)
object MyPluginModule {
    @Provides @IntoSet
    fun provideSpotifyPlugin(plugin: SpotifyPlugin): HeritagePlugin = plugin
}

// 3. Register at runtime (for dynamically loaded plugins)
pluginRegistry.register(SpotifyPlugin(spotifyApi))
```

The `PluginRegistry.buildSystemPromptSchema()` automatically includes your plugin's `commandSchema()` in every LLM request, so the AI knows how to invoke it from natural language.

---

## Security & Privacy

- **Database encryption**: Room database encrypted with AES-256 via SQLCipher. The passphrase is generated once, wrapped with a key in the Android hardware-backed Keystore, and never written to disk in plaintext.
- **API key storage**: Stored in DataStore preferences, which are in the app's private directory (not accessible to other apps without root). No API keys are ever sent to any Heritage server — they go directly from your device to your chosen LLM provider.
- **No analytics, no ads**: Heritage AI contains zero tracking SDKs and no ad networks.
- **Backup exclusions**: `backup_rules.xml` and `data_extraction_rules.xml` explicitly exclude the database and encrypted preferences from Google cloud backup and device-to-device transfers.
- **Accessibility transparency**: The accessibility service description is honest about what it does. Heritage AI never acts autonomously on the accessibility service — only in direct response to a voice/text command.
- **Network security**: `network_security_config.xml` enforces HTTPS for all remote LLM calls. HTTP is only permitted for `localhost` / `10.0.2.2` (Ollama local server use case).

---

## Known Limitations

1. **Wake word**: The keyword detection stub always returns `false`. You need to integrate a real on-device wake-word engine (Porcupine recommended — free tier covers one custom keyword).
2. **Screenshot**: Requires per-session user consent via the system MediaProjection dialog (Android security requirement — cannot be bypassed).
3. **Wi-Fi toggle**: Android 10+ apps cannot toggle Wi-Fi programmatically. Heritage AI opens the system Wi-Fi panel instead.
4. **Bluetooth toggle**: Android 13+ apps cannot toggle Bluetooth without user interaction. Heritage AI opens the system Bluetooth panel.
5. **Streaming responses**: The LLM integration uses standard (non-streaming) responses. Real-time token streaming can be added via OkHttp's `EventSource` + SSE parsing.
6. **No real-time web search**: The LLM responds from training data only. Tool-calling with a web search API (e.g., Tavily, Serper) would add this capability.

---

## Roadmap

- [ ] Porcupine wake-word integration (1-click setup)
- [ ] Streaming LLM responses (SSE / EventSource)
- [ ] Conversation export (PDF / text)
- [ ] Multiple voice profiles
- [ ] Tasker / Shortcuts integration
- [ ] Widget (home screen conversation input)
- [ ] Smart home (Home Assistant via MCP)
- [ ] On-device LLM (Gemma via MediaPipe LLM Inference API)

---

## License

```
Copyright 2024-2025 Heritage AI

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0
```

---

<p align="center">Built with ❤️ in Kotlin · Powered by Material 3 · Privacy first</p>
